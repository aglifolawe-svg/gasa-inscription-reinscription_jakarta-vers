<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.*" %>
<%@ page import="com.gasaformation.model.*" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<%
    String idParam = request.getParameter("id");
    int dossierId = (idParam != null) ? Integer.parseInt(idParam) : -1;

    InscriptionDAO idao = new InscriptionDAO();
    UtilisateurDAO udao = new UtilisateurDAO();
    JustificatifRepository jrepo = new JustificatifRepository();
    NoteBacRepository nrepo = new NoteBacRepository();
    BacSerieRepository bdao = new BacSerieRepository();

    Inscription dossier = null;
    Utilisateur etudiant = null;
    List<Justificatif> docs = new ArrayList<>();
    List<NoteBac> notes = new ArrayList<>();
    List<MatierePrincipale> matieres = new ArrayList<>();

    try {
        dossier = idao.findById(dossierId);
        if (dossier != null) {
            etudiant = udao.findById(dossier.getEtudiantId());
            docs = jrepo.findByInscription(dossier.getId());
            notes = nrepo.findByInscription(dossier.getId());
            if (dossier.getSerieBac() != null) {
                BacSerie serie = bdao.findByCode(dossier.getSerieBac());
                if (serie != null) {
                    matieres = bdao.findMatieresBySerieId(serie.getId());
                }
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    request.setAttribute("dossier", dossier);
    request.setAttribute("etudiant", etudiant);
    request.setAttribute("docs", docs);
    request.setAttribute("notes", notes);
    request.setAttribute("matieres", matieres);
%>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Dossier d'inscription</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    @media print { .no-print { display: none; } }
    .section-title {
      background-color: #f8f9fa;
      padding: 8px;
      font-weight: bold;
      margin-top: 20px;
      border-bottom: 1px solid #dee2e6;
    }
  </style>
</head>
<body class="bg-white container py-4">

  <div class="no-print mb-4 text-end">
    <button onclick="window.print()" class="btn btn-outline-primary">🖨️ Imprimer le dossier</button>
    <a href="inscriptions.jsp" class="btn btn-outline-secondary">Retour</a>
  </div>

  <h2 class="mb-4">📄 Dossier d'inscription</h2>

  <c:if test="${dossier != null && etudiant != null}">
    <!-- Infos personnelles -->
    <div class="section-title">Informations personnelles</div>
    <table class="table table-bordered">
      <tr><th>Nom</th><td>${etudiant.nom}</td></tr>
      <tr><th>Prénom</th><td>${etudiant.prenom}</td></tr>
      <tr><th>Sexe</th><td>${etudiant.sexe}</td></tr>
      <tr><th>Identifiant</th><td>${etudiant.id}</td></tr>
      <tr><th>Nom d'utilisateur</th><td>${etudiant.username}</td></tr>
      <tr><th>Statut</th><td>${etudiant.statut}</td></tr>
    </table>

    <!-- Infos académiques -->
    <div class="section-title">Informations académiques</div>
    <table class="table table-bordered">
      <tr><th>Date de demande</th><td><fmt:formatDate value="${dossier.dateInscription}" pattern="dd/MM/yyyy"/></td></tr>
      <tr><th>Filière demandée</th><td>${dossier.filiere}</td></tr>
      <tr><th>Niveau</th><td>${dossier.niveau}</td></tr>
      <tr><th>Type d'inscription</th><td>${dossier.type}</td></tr>
      <tr><th>Série du BAC</th><td>${dossier.serieBac}</td></tr>
      <tr><th>Diplôme présenté</th><td>${dossier.diplome}</td></tr>
      <tr><th>Année d'obtention</th><td>${dossier.anneeObtention}</td></tr>
      <tr><th>Établissement d'origine</th><td>${dossier.etablissementOrigine}</td></tr>
      <tr><th>Statut du dossier</th>
        <td>
          <c:choose>
            <c:when test="${dossier.statut eq 'validé'}"><span class="badge bg-success">Validé</span></c:when>
            <c:when test="${dossier.statut eq 'rejete'}"><span class="badge bg-danger">Rejeté</span></c:when>
            <c:otherwise><span class="badge bg-warning text-dark">En attente</span></c:otherwise>
          </c:choose>
        </td>
      </tr>
    </table>

    <!-- Pièces justificatives -->
    <div class="section-title">Pièces justificatives</div>
    <c:if test="${empty docs}">
      <div class="alert alert-warning">Aucune pièce jointe fournie.</div>
    </c:if>
    <c:if test="${not empty docs}">
      <ul class="list-group mb-3">
        <c:forEach var="doc" items="${docs}">
          <li class="list-group-item d-flex justify-content-between align-items-center">
            ${doc.type} - ${doc.filename}
            <span class="badge bg-secondary">${doc.statut}</span>
          </li>
        </c:forEach>
      </ul>
    </c:if>

    <!-- Notes du BAC -->
    <div class="section-title">Notes du BAC</div>
    <c:if test="${empty notes}">
      <div class="alert alert-info">Aucune note enregistrée.</div>
    </c:if>
    <c:if test="${not empty notes}">
      <table class="table table-bordered">
        <thead class="table-light">
          <tr><th>Matière</th><th>Note</th><th>Coefficient</th></tr>
        </thead>
        <tbody>
          <c:forEach var="note" items="${notes}">
            <c:set var="matiereLibelle" value=""/>
            <c:set var="coef" value=""/>
            <c:forEach var="m" items="${matieres}">
              <c:if test="${m.id == note.matierePrincipaleId}">
                <c:set var="matiereLibelle" value="${m.libelle}"/>
                <c:set var="coef" value="${m.coefficient}"/>
              </c:if>
            </c:forEach>
            <tr>
              <td>${matiereLibelle}</td>
              <td>${note.note}</td>
              <td>${coef}</td>
            </tr>
          </c:forEach>
        </tbody>
      </table>
    </c:if>
  </c:if>

  <c:if test="${dossier == null || etudiant == null}">
    <div class="alert alert-danger">Dossier introuvable ou invalide.</div>
  </c:if>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

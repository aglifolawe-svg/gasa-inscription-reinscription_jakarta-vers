<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.InscriptionDAO" %>
<%@ page import="com.gasaformation.dao.NotificationDAO" %>
<%@ page import="com.gasaformation.model.Inscription" %>
<%@ page import="com.gasaformation.model.Notification" %>
<%@ page import="java.security.Principal" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<%
  // RBAC: secrétaires only; adjust if admins share this page
  Principal user = request.getUserPrincipal();
  if (user == null || !(request.isUserInRole("secretaire") || request.isUserInRole("admin"))) {
    response.sendRedirect(request.getContextPath() + "/login.jsp?error=forbidden");
    return;
  }

  // Data access
  InscriptionDAO idao = new InscriptionDAO();

  List<Inscription> pending = idao.findByStatut("en attente");
  List<Inscription> valides = idao.findByStatut("validé");
  List<Inscription> rejetes = idao.findByStatut("rejete");

  int countPending = pending != null ? pending.size() : 0;
  int countValides = valides != null ? valides.size() : 0;
  int countRejetes = rejetes != null ? rejetes.size() : 0;

  // Chart data: count validated per month
  int[] byMonth = new int[12];
  Calendar cal = Calendar.getInstance();
  if (valides != null) {
    for (Inscription ins : valides) {
      if (ins.getDateInscription() != null) {
        cal.setTime(ins.getDateInscription());
        int m = cal.get(Calendar.MONTH); // 0..11
        byMonth[m]++;
      }
    }
  }

  // Greeting and time
  Calendar now = Calendar.getInstance();
  int hour = now.get(Calendar.HOUR_OF_DAY);
  String greeting = (hour < 12) ? "Bonjour" : (hour < 18 ? "Bon après-midi" : "Bonsoir");

  String currentDate = new java.text.SimpleDateFormat("dd/MM/yyyy").format(new java.util.Date());
  String currentTime = new java.text.SimpleDateFormat("HH:mm").format(new java.util.Date());

  // Notifications badge: count unread for current user (if userId available in session)
  int notifCount = 0;
  Integer currentUserId = (Integer) session.getAttribute("currentUserId");
  if (currentUserId != null) {
    try {
      NotificationDAO ndao = new NotificationDAO();
      List<Notification> notifs = ndao.findByUser(currentUserId);
      for (Notification n : notifs) {
        if (!n.isLu()) notifCount++;
      }
    } catch (Exception ignore) { /* keep badge 0 if issue */ }
  }

  // Expose to JSP
  request.setAttribute("pending", pending);
  request.setAttribute("greeting", greeting);
  request.setAttribute("currentDate", currentDate);
  request.setAttribute("currentTime", currentTime);
  request.setAttribute("notifCount", notifCount);
%>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Secrétaire - GASA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link href="${pageContext.request.contextPath}/css/theme.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light">

  <jsp:include page="/WEB-INF/includes/header.jsp"/>

  <div class="container my-4">
    <!-- Header with greeting, time and notifications -->
    <div class="d-flex justify-content-between align-items-center pb-2 mb-3 border-bottom">
      <div>
        <h1 class="h4 mb-1">${greeting}, Secrétariat</h1>
        <small class="text-muted">Nous sommes le ${currentDate} — ${currentTime}</small>
      </div>
      <div>
        <a href="${pageContext.request.contextPath}/secretaire/notifications.jsp"
           class="btn btn-light position-relative">
          <i class="bi bi-bell"></i> Notifications
          <c:if test="${notifCount > 0}">
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
              ${notifCount}
            </span>
          </c:if>
        </a>
      </div>
    </div>

    <!-- Actions -->
    <div class="mb-4 d-flex justify-content-end">
      <a href="${pageContext.request.contextPath}/secretaire/inscriptions.jsp" class="btn btn-primary">
        <i class="bi bi-journal-check"></i> Gérer les inscriptions
      </a>
    </div>

    <!-- Stats -->
    <div class="row g-3 mb-4">
      <div class="col-md-4">
        <div class="card text-bg-warning shadow-sm">
          <div class="card-body text-center">
            <h6><i class="bi bi-hourglass-split me-2"></i>En attente</h6>
            <p class="fs-3 mb-0"><%= countPending %></p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card text-bg-success shadow-sm">
          <div class="card-body text-center">
            <h6><i class="bi bi-check-circle me-2"></i>Validées</h6>
            <p class="fs-3 mb-0"><%= countValides %></p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card text-bg-danger shadow-sm">
          <div class="card-body text-center">
            <h6><i class="bi bi-x-circle me-2"></i>Rejetées</h6>
            <p class="fs-3 mb-0"><%= countRejetes %></p>
          </div>
        </div>
      </div>
    </div>

    <!-- Chart: validated per month -->
    <div class="card mb-5 shadow-sm">
      <div class="card-header">Inscriptions validées — par mois</div>
      <div class="card-body">
        <canvas id="chartInscByMonth" height="100"></canvas>
      </div>
    </div>

    <!-- Pending dossiers -->
    <div class="card mb-5 shadow-sm">
      <div class="card-header">Dossiers en attente</div>
      <div class="card-body">
        <c:choose>
          <c:when test="${empty pending}">
            <div class="alert alert-info">Aucun dossier en attente.</div>
          </c:when>
          <c:otherwise>
            <table class="table table-bordered table-hover align-middle">
              <thead class="table-light">
                <tr>
                  <th>Date</th>
                  <th>Étudiant</th>
                  <th>Filière</th>
                  <th>Niveau</th>
                  <th>Type</th>
                  <th>Série BAC</th>
                  <th>Diplôme</th>
                  <th>Année</th>
                  <th>Établissement</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <c:forEach var="insc" items="${pending}">
                  <tr>
                    <td><fmt:formatDate value="${insc.dateInscription}" pattern="dd/MM/yyyy"/></td>
                    <td>Utilisateur #${insc.etudiantId}</td>
                    <td>${insc.filiere}</td>
                    <td>${insc.niveau}</td>
                    <td>${insc.type}</td>
                    <td>${insc.serieBac}</td>
                    <td>${insc.diplome}</td>
                    <td>${insc.anneeObtention}</td>
                    <td>${insc.etablissementOrigine}</td>
                    <td>
                      <form action="inscriptionsValidation.jsp" method="post" class="d-inline">
                        <input type="hidden" name="inscriptionId" value="${insc.id}">
                        <input type="hidden" name="etudiantId" value="${insc.etudiantId}">
                        <button type="submit" name="action" value="valider" class="btn btn-outline-success btn-sm">
                          <i class="bi bi-check2-circle"></i> Valider
                        </button>
                      </form>
                      <form action="inscriptionsValidation.jsp" method="post" class="d-inline ms-2">
                        <input type="hidden" name="inscriptionId" value="${insc.id}">
                        <button type="submit" name="action" value="rejeter" class="btn btn-outline-danger btn-sm">
                          <i class="bi bi-x-circle"></i> Rejeter
                        </button>
                      </form>
                      <a href="inscriptionsDetails.jsp?id=${insc.id}" class="btn btn-outline-secondary btn-sm ms-2">
                        <i class="bi bi-eye"></i> Détails
                      </a>
                    </td>
                  </tr>
                </c:forEach>
              </tbody>
            </table>
          </c:otherwise>
        </c:choose>
      </div>
    </div>

    <!-- Audit quick access -->
    <div class="mb-5 d-flex justify-content-end">
      <a href="${pageContext.request.contextPath}/secretaire/auditTrail.jsp" class="btn btn-outline-secondary">
        <i class="bi bi-clock-history"></i> Historique des actions
      </a>
    </div>

    <!-- Footer reuse -->
    <footer class="bg-dark text-white text-center py-3 mt-auto">
      <p class="mb-0">&copy; 2025 GASA Formation - Tous droits réservés</p>
    </footer>
  </div>

  <!-- Chart -->
  <script>
    const labels = ["Jan","Fév","Mar","Avr","Mai","Juin","Juil","Août","Sep","Oct","Nov","Déc"];
    const dataVals = [
      <%= byMonth[0] %>,<%= byMonth[1] %>,<%= byMonth[2] %>,<%= byMonth[3] %>,<%= byMonth[4] %>,<%= byMonth[5] %>,
      <%= byMonth[6] %>,<%= byMonth[7] %>,<%= byMonth[8] %>,<%= byMonth[9] %>,<%= byMonth[10] %>,<%= byMonth[11] %>
    ];
    new Chart(document.getElementById('chartInscByMonth'), {
      type: 'bar',
      data: { 
        labels: labels, 
        datasets: [{
          label: 'Validées',
          data: dataVals,
          backgroundColor: '#0f4c81'
        }]
      },
      options: { 
        responsive: true, 
        scales: { y: { beginAtZero: true } }
      }
    });
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html
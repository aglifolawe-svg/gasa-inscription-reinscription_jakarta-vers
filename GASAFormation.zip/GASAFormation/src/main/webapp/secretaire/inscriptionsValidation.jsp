<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.InscriptionDAO" %>

<%
  request.setCharacterEncoding("UTF-8");
  String action = request.getParameter("action");
  String inscIdStr = request.getParameter("inscriptionId");
  String etuIdStr  = request.getParameter("etudiantId");

  if (action == null || inscIdStr == null) {
      response.sendRedirect("inscriptions.jsp?error=invalid");
      return;
  }

  int inscriptionId = Integer.parseInt(inscIdStr);
  Integer etudiantId = (etuIdStr != null && !etuIdStr.isEmpty()) ? Integer.parseInt(etuIdStr) : null;

  try {
      InscriptionDAO idao = new InscriptionDAO();

      if ("valider".equalsIgnoreCase(action)) {
          if (etudiantId != null) {
              idao.validateInscriptionAndUser(inscriptionId, etudiantId);
          } else {
              idao.validateOnlyInscription(inscriptionId);
          }
          response.sendRedirect("inscriptions.jsp?ok=valide");

      } else if ("rejeter".equalsIgnoreCase(action)) {
          idao.rejectInscription(inscriptionId);
          response.sendRedirect("inscriptions.jsp?ok=rejete");

      } else {
          response.sendRedirect("inscriptions.jsp?error=action");
      }
  } catch (Exception e) {
      e.printStackTrace();
      response.sendRedirect("inscriptions.jsp?error=server");
  }
%>

<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.InscriptionDAO" %>
<%@ page import="com.gasaformation.dao.JustificatifRepository" %>
<%@ page import="com.gasaformation.model.Inscription" %>
<%@ page import="com.gasaformation.model.Justificatif" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>

<%
  InscriptionDAO idao = new InscriptionDAO();
  List<Inscription> pending = idao.findByStatut("en attente");
  List<Inscription> valides = idao.findByStatut("validé");
  List<Inscription> rejetes = idao.findByStatut("rejete");

  // Charger les justificatifs pour chaque inscription
  JustificatifRepository jrepo = new JustificatifRepository();
  Map<Integer, List<Justificatif>> justificatifsMap = new HashMap<>();
  for (Inscription ins : pending) {
      justificatifsMap.put(ins.getId(), jrepo.findByInscription(ins.getId()));
  }
  for (Inscription ins : valides) {
      justificatifsMap.put(ins.getId(), jrepo.findByInscription(ins.getId()));
  }
  for (Inscription ins : rejetes) {
      justificatifsMap.put(ins.getId(), jrepo.findByInscription(ins.getId()));
  }

  String q = request.getParameter("q");
  String tab = request.getParameter("tab"); // pending | valides | rejetes
  if (tab == null) tab = "pending";

  request.setAttribute("q", q);
  request.setAttribute("tab", tab);
  request.setAttribute("pending", pending);
  request.setAttribute("valides", valides);
  request.setAttribute("rejetes", rejetes);
  request.setAttribute("justificatifsMap", justificatifsMap);
%>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Inscriptions - Secrétaire | GASA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container-fluid py-4">
    <c:if test="${param.ok eq 'valide'}">
      <div class="alert alert-success">Inscription validée et rôle mis à jour en <strong>etudiant_de_gasa</strong>.</div>
    </c:if>
    <c:if test="${param.ok eq 'rejete'}">
      <div class="alert alert-warning">Inscription rejetée.</div>
    </c:if>
    <c:if test="${param.error ne null}">
      <div class="alert alert-danger">Erreur : ${param.error}</div>
    </c:if>

    <div class="d-flex align-items-center justify-content-between mb-3">
      <h2 class="mb-0">Gestion des inscriptions</h2>
      <form class="d-flex" method="get">
        <input class="form-control me-2" type="search" name="q" value="${q}" placeholder="Rechercher par filière/niveau...">
        <button class="btn btn-outline-primary" type="submit">Rechercher</button>
      </form>
    </div>

    <ul class="nav nav-tabs">
      <li class="nav-item">
        <a class="nav-link ${tab=='pending'?'active':''}" href="?tab=pending">En attente</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${tab=='valides'?'active':''}" href="?tab=valides">Validées</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${tab=='rejetes'?'active':''}" href="?tab=rejetes">Rejetées</a>
      </li>
    </ul>

    <div class="tab-content pt-3">
      <!-- En attente -->
      <div class="tab-pane fade ${tab=='pending'?'show active':''}" id="pending">
        <c:choose>
          <c:when test="${empty pending}">
            <div class="alert alert-info">Aucune inscription en attente.</div>
          </c:when>
          <c:otherwise>
            <div class="table-responsive">
              <table class="table table-hover align-middle">
                <thead class="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Étudiant ID</th>
                    <th>Filière</th>
                    <th>Niveau</th>
                    <th>Type</th>
                    <th>Date</th>
                    <th>Pièces</th>
                    <th class="text-end">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <c:forEach var="ins" items="${pending}">
                    <c:if test="${empty q or (ins.filiere ne null and fn:contains(fn:toLowerCase(ins.filiere), fn:toLowerCase(q))) or (ins.niveau ne null and fn:contains(fn:toLowerCase(ins.niveau), fn:toLowerCase(q)))}">
                      <tr>
                        <td>${ins.id}</td>
                        <td>${ins.etudiantId}</td>
                        <td>${ins.filiere}</td>
                        <td>${ins.niveau}</td>
                        <td>${ins.type}</td>
                        <td>${ins.dateInscription}</td>
                        <td>
                          <c:forEach var="doc" items="${justificatifsMap[ins.id]}">
                            <span class="badge bg-secondary me-1">${doc.type}</span>
                          </c:forEach>
                        </td>
                        <td class="text-end">
                          <form action="inscriptionsValidation.jsp" method="post" class="d-inline">
                            <input type="hidden" name="inscriptionId" value="${ins.id}">
                            <input type="hidden" name="etudiantId" value="${ins.etudiantId}">
                            <button type="submit" name="action" value="valider" class="btn btn-sm btn-success">Valider</button>
                          </form>
                          <form action="inscriptionsValidation.jsp" method="post" class="d-inline ms-2">
                            <input type="hidden" name="inscriptionId" value="${ins.id}">
                            <button type="submit" name="action" value="rejeter" class="btn btn-sm btn-danger">Rejeter</button>
                          </form>
                          <a href="inscriptionDetails.jsp?id=${ins.id}" class="btn btn-sm btn-outline-primary ms-2">Détails</a>
                        </td>
                      </tr>
                    </c:if>
                  </c:forEach>
                </tbody>
              </table>
            </div>
          </c:otherwise>
        </c:choose>
      </div>

      <!-- Validées -->
      <div class="tab-pane fade ${tab=='valides'?'show active':''}" id="valides">
        <c:choose>
          <c:when test="${empty valides}">
            <div class="alert alert-info">Aucune inscription validée.</div>
          </c:when>
          <c:otherwise>
            <div class="table-responsive">
              <table class="table table-striped align-middle">
                <thead class="table-light"><tr><th>ID</th><th>Étudiant ID</th><th>Filière</th><th>Niveau</th><th>Type</th><th>Date</th><th>Pièces</th></tr></thead>
                <tbody>
                  <c:forEach var="ins" items="${valides}">
                    <tr>
                      <td>${ins.id}</td>
                      <td>${ins.etudiantId}</td>
                      <td>${ins.filiere}</td>
                      <td>${ins.niveau}</td>
                      <td>${ins.type}</td>
                      <td>${ins.dateInscription}</td>
                      <td>
                        <c:forEach var="doc" items="${justificatifsMap[ins.id]}">
                          <span class="badge bg-secondary me-1">${doc.type}</span>
                        </c:forEach>
                      </td>
                    </tr>
                  </c:forEach>
                </tbody>
              </table>
            </div>
          </c:otherwise>
        </c:choose>
      </div>

      <!-- Rejetées -->
      <div class="tab-pane fade ${tab=='rejetes'?'show active':''}" id="rejetes">
        <c:choose>
          <c:when test="${empty rejetes}">
            <div class="alert alert-info">Aucune inscription rejetée.</div>
          </c:when>
          <c:otherwise>
            <div class="table-responsive">
              <table class="table table-striped align-middle">
                <thead class="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Étudiant ID</th>
                    <th>Filière</th>
                    <th>Niveau</th>
                    <th>Type</th>
                    <th>Date</th>
                    <th>Pièces</th>
                  </tr>
                </thead>
                <tbody>
                  <c:forEach var="ins" items="${rejetes}">
                    <tr>
                      <td>${ins.id}</td>
                      <td>${ins.etudiantId}</td>
                      <td>${ins.filiere}</td>
                      <td>${ins.niveau}</td>
                      <td>${ins.type}</td>
                      <td>${ins.dateInscription}</td>
                      <td>
                        <c:forEach var="doc" items="${justificatifsMap[ins.id]}">
                          <span class="badge bg-secondary me-1">${doc.type}</span>
                        </c:forEach>
                      </td>
                    </tr>
                  </c:forEach>
                </tbody>
              </table>
            </div>
          </c:otherwise>
        </c:choose>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

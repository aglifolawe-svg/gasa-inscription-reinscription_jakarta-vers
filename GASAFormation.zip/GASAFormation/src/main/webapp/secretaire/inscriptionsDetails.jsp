<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.*" %>
<%@ page import="com.gasaformation.model.*" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<%
    String idParam = request.getParameter("id");
    int dossierId = (idParam != null) ? Integer.parseInt(idParam) : -1;

    InscriptionDAO idao = new InscriptionDAO();
    UtilisateurDAO udao = new UtilisateurDAO();
    JustificatifRepository jrepo = new JustificatifRepository();
    NoteBacRepository nrepo = new NoteBacRepository();
    BacSerieRepository bdao = new BacSerieRepository();

    Inscription dossier = null;
    Utilisateur etudiant = null;
    List<Justificatif> docs = new ArrayList<>();
    List<NoteBac> notes = new ArrayList<>();
    List<MatierePrincipale> matieres = new ArrayList<>();

    try {
        dossier = idao.findById(dossierId);
        if (dossier != null) {
            etudiant = udao.findById(dossier.getEtudiantId());
            docs = jrepo.findByInscription(dossier.getId());
            notes = nrepo.findByInscription(dossier.getId());
            if (dossier.getSerieBac() != null) {
                BacSerie serie = bdao.findByCode(dossier.getSerieBac());
                if (serie != null) {
                    matieres = bdao.findMatieresBySerieId(serie.getId());
                }
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    request.setAttribute("dossier", dossier);
    request.setAttribute("etudiant", etudiant);
    request.setAttribute("docs", docs);
    request.setAttribute("notes", notes);
    request.setAttribute("matieres", matieres);
%>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Détails du dossier</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light container py-4">

  <div class="mb-4 d-flex justify-content-between">
    <h2>📑 Détails du dossier</h2>
    <div>
      <a href="imprimerDossier.jsp?id=${dossier.id}" class="btn btn-outline-primary">🖨️ Imprimer</a>
      <a href="inscriptions.jsp" class="btn btn-outline-secondary">Retour</a>
    </div>
  </div>

  <c:if test="${dossier != null && etudiant != null}">
    <!-- Infos personnelles -->
    <div class="card mb-4">
      <div class="card-header">Informations personnelles</div>
      <div class="card-body">
        <p><strong>Nom :</strong> ${etudiant.nom}</p>
        <p><strong>Prénom :</strong> ${etudiant.prenom}</p>
        <p><strong>Sexe :</strong> ${etudiant.sexe}</p>
        <p><strong>Identifiant :</strong> ${etudiant.id}</p>
        <p><strong>Nom d'utilisateur :</strong> ${etudiant.username}</p>
        <p><strong>Statut :</strong> ${etudiant.statut}</p>
      </div>
    </div>

    <!-- Infos académiques -->
    <div class="card mb-4">
      <div class="card-header">Informations académiques</div>
      <div class="card-body">
        <p><strong>Date de demande :</strong> <fmt:formatDate value="${dossier.dateInscription}" pattern="dd/MM/yyyy"/></p>
        <p><strong>Filière demandée :</strong> ${dossier.filiere}</p>
        <p><strong>Niveau :</strong> ${dossier.niveau}</p>
        <p><strong>Type d'inscription :</strong> ${dossier.type}</p>
        <p><strong>Série du BAC :</strong> ${dossier.serieBac}</p>
        <p><strong>Diplôme présenté :</strong> ${dossier.diplome}</p>
        <p><strong>Année d'obtention :</strong> ${dossier.anneeObtention}</p>
        <p><strong>Établissement d'origine :</strong> ${dossier.etablissementOrigine}</p>
        <p><strong>Statut du dossier :</strong>
          <c:choose>
            <c:when test="${dossier.statut eq 'validé'}"><span class="badge bg-success">Validé</span></c:when>
            <c:when test="${dossier.statut eq 'rejete'}"><span class="badge bg-danger">Rejeté</span></c:when>
            <c:otherwise><span class="badge bg-warning text-dark">En attente</span></c:otherwise>
          </c:choose>
        </p>
        <p><strong>Commentaire :</strong> ${dossier.commentaire}</p>
      </div>
    </div>

    <!-- Pièces justificatives -->
    <div class="card mb-4">
      <div class="card-header">Pièces justificatives</div>
      <div class="card-body">
        <c:if test="${empty docs}">
          <div class="alert alert-warning">Aucune pièce jointe fournie.</div>
        </c:if>
        <c:if test="${not empty docs}">
          <ul class="list-group">
            <c:forEach var="doc" items="${docs}">
              <li class="list-group-item d-flex justify-content-between align-items-center">
                ${doc.type} - ${doc.filename}
                <span class="badge bg-secondary">${doc.statut}</span>
              </li>
            </c:forEach>
          </ul>
        </c:if>
      </div>
    </div>

    <!-- Notes du BAC -->
    <div class="card mb-4">
      <div class="card-header">Notes du BAC</div>
      <div class="card-body">
        <c:if test="${empty notes}">
          <div class="alert alert-info">Aucune note enregistrée.</div>
        </c:if>
        <c:if test="${not empty notes}">
          <table class="table table-bordered">
            <thead class="table-light">
              <tr><th>Matière</th><th>Note</th><th>Coefficient</th></tr>
            </thead>
            <tbody>
              <c:forEach var="note" items="${notes}">
                <c:set var="matiereLibelle" value=""/>
                <c:set var="coef" value=""/>
                <c:forEach var="m" items="${matieres}">
                  <c:if test="${m.id == note.matierePrincipaleId}">
                    <c:set var="matiereLibelle" value="${m.libelle}"/>
                    <c:set var="coef" value="${m.coefficient}"/>
                  </c:if>
                </c:forEach>
                <tr>
                  <td>${matiereLibelle}</td>
                  <td>${note.note}</td>
                  <td>${coef}</td>
                </tr>
              </c:forEach>
            </tbody>
          </table>
        </c:if>
      </div>
    </div>

    <!-- Actions -->
    <div class="d-flex justify-content-end mb-5">
      <form action="inscriptionsValidation.jsp" method="post" class="me-2">
        <input type="hidden" name="inscriptionId" value="${dossier.id}">
        <input type="hidden" name="etudiantId" value="${etudiant.id}">
        <button type="submit" name="action" value="valider" class="btn btn-success">Valider</button>
      </form>
      <form action="inscriptionsValidation.jsp" method="post">
        <input type="hidden" name="inscriptionId" value="${dossier.id}">
        <button type="submit" name="action" value="rejeter" class="btn btn-danger">Rejeter</button>
      </form>
    </div>
  </c:if>

  <c:if test="${dossier == null || etudiant == null}">
    <div class="alert alert-danger">Dossier introuvable ou invalide.</div>
  </c:if>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

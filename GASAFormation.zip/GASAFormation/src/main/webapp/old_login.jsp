<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Connexion - GASA Formation</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

  <div class="container mt-5">
    <div class="row justify-content-center">
      <div class="col-md-5">
        <div class="card shadow-sm">
          <div class="card-header text-center bg-primary text-white">
            <h4>Connexion au Portail GASA Formation</h4>
          </div>
          <div class="card-body">
            
            <!-- Messages -->
            <c:if test="${param.registered eq 'true'}">
              <div class="alert alert-success">Inscription réussie, veuillez vous connecter.</div>
            </c:if>
            <c:if test="${param.logout eq 'true'}">
              <div class="alert alert-info">Vous êtes déconnecté avec succès.</div>
            </c:if>

            <form method="post" action="j_security_check">
              <div class="mb-3">
                <label for="j_username" class="form-label">Nom d'utilisateur</label>
                <input type="text" class="form-control" id="j_username" name="j_username" required>
              </div>
              <div class="mb-3">
                <label for="j_password" class="form-label">Mot de passe</label>
                <input type="password" class="form-control" id="j_password" name="j_password" required>
              </div>
              <button type="submit" class="btn btn-primary w-100">Se connecter</button>
            </form>
          </div>
          <div class="card-footer text-center">
            <a href="register.jsp">Créer un compte</a>
          </div>
        </div>
      </div>
    </div>
  </div>

</body>
</html>

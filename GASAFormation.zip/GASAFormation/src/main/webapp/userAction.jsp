<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%
  // Deprecated: JAAS/Form authentication is now in place via j_security_check.
  // Keep this file only to avoid broken links; redirect to login.
  response.sendRedirect("login.jsp");
%>

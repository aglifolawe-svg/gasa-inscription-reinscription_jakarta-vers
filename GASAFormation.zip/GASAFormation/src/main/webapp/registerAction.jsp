<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.security.MessageDigest" %>
<%@ page import="com.gasaformation.dao.UtilisateurDAO" %>
<%@ page import="com.gasaformation.model.Utilisateur" %>
<%
    request.setCharacterEncoding("UTF-8");
    String username = request.getParameter("username");
    String password = request.getParameter("password");

    try {
        // Hash SHA-256
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(password.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) sb.append(String.format("%02x", b));
        String passwordHash = sb.toString();

        Utilisateur u = new Utilisateur();
        u.setUsername(username);
        u.setPassword(passwordHash);   // aligns to DB column "password"
        u.setRole("etudiant");
        u.setStatut("en attente");
        u.setPoste(null);

        UtilisateurDAO dao = new UtilisateurDAO();
        dao.insert(u);

        // After registration, direct user to login (JAAS will handle).
        response.sendRedirect("login.jsp?registered=true");
    } catch (Exception e) {
        out.println("<div class='alert alert-danger'>Erreur lors de l'inscription : " + e.getMessage() + "</div>");
    }
%>

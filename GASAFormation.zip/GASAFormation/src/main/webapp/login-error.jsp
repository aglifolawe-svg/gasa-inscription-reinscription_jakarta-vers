<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Erreur de connexion</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-5">
    <div class="alert alert-danger">Échec de l'authentification. Veuillez réessayer.</div>
    <a class="btn btn-primary" href="${pageContext.request.contextPath}/login.jsp">Retour</a>
  </div>
</body>
</html>

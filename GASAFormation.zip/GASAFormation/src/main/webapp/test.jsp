<%@ page contentType="text/html; charset=UTF-8" %>
<%
    out.println("Bonjour, UTF‑8 fonctionne !");
%>

<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Connexion - GASA Formation</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="${pageContext.request.contextPath}/css/theme.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-md-4">
        <div class="card shadow-sm">
          <div class="card-header bg-primary text-white text-center">Connexion</div>
          <div class="card-body">
            
            <!-- JAAS FORM authentication -->
            <form method="post" action="j_security_check">
              <div class="mb-3">
                <label class="form-label">Nom d'utilisateur</label>
                <!-- Pré-remplissage si l’utilisateur a déjà saisi un login -->
                <input type="text" class="form-control" name="j_username" 
                       value="${param.j_username}" required>
              </div>
              <div class="mb-3">
                <label class="form-label">Mot de passe</label>
                <input type="password" class="form-control" name="j_password" required>
              </div>
              <button class="btn btn-primary w-100">Se connecter</button>
            </form>

            <!-- Gestion des messages d'erreur -->
            <c:choose>
              <c:when test="${param.error eq '1'}">
                <div class="alert alert-danger mt-3">Identifiants invalides.</div>
              </c:when>
              <c:when test="${param.error eq 'forbidden'}">
                <div class="alert alert-warning mt-3">
                  Accès interdit : vous devez être connecté en tant qu’étudiant pour accéder à cette page.
                </div>
              </c:when>
            </c:choose>

          </div>
          <div class="card-footer text-center">
            <a href="${pageContext.request.contextPath}/register.jsp">Créer un compte étudiant</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>

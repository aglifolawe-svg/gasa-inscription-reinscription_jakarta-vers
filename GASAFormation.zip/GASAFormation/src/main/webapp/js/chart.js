document.addEventListener("DOMContentLoaded", function () {
  // 📊 Inscriptions par mois
  const inscCtx = document.getElementById('inscriptionChart');
  if (inscCtx && typeof inscriptionsLabels !== "undefined" && typeof inscriptionsData !== "undefined") {
    new Chart(inscCtx, {
      type: 'bar',
      data: {
        labels: inscriptionsLabels,
        datasets: [{
          label: 'Inscriptions',
          data: inscriptionsData,
          backgroundColor: '#0d6efd',
          borderRadius: 4
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          title: { display: false }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: { stepSize: 1 }
          }
        }
      }
    });
  }

  // 💰 Paiements validés vs en attente
  const payCtx = document.getElementById('paiementChart');
  if (payCtx && typeof paiementsData !== "undefined") {
    new Chart(payCtx, {
      type: 'doughnut',
      data: {
        labels: ['Validés', 'En attente'],
        datasets: [{
          data: paiementsData,
          backgroundColor: ['#198754', '#ffc107'],
          borderColor: ['#fff', '#fff'],
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              color: '#333',
              font: { size: 14 }
            }
          }
        }
      }
    });
  }

  // 📈 Progression académique (si tu veux l’ajouter plus tard)
  const progCtx = document.getElementById('progressChart');
  if (progCtx && typeof progressionData !== "undefined") {
    new Chart(progCtx, {
      type: 'line',
      data: {
        labels: progressionLabels,
        datasets: [{
          label: 'Progression académique',
          data: progressionData,
          borderColor: '#0d6efd',
          backgroundColor: 'rgba(13,110,253,0.1)',
          tension: 0.3,
          fill: true
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: true }
        },
        scales: {
          y: { beginAtZero: true }
        }
      }
    });
  }
});

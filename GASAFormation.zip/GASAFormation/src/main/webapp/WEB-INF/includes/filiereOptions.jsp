<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<select name="filiere" id="filiere" class="form-select" required>
  <c:choose>
    <c:when test="${not empty filieresGrouped}">
      <c:forEach var="ufr" items="${filieresGrouped.keySet()}">
        <optgroup label="${ufr}">
          <c:forEach var="f" items="${filieresGrouped[ufr]}">
            <option value="${f.nom}">${f.nom}</option>
          </c:forEach>
        </optgroup>
      </c:forEach>
    </c:when>
    <c:otherwise>
      <!-- Liste statique de secours basée sur les filières UATM -->
      <optgroup label="Sciences et Techniques">
        <option value="Informatique & Réseaux">Informatique & Réseaux</option>
        <option value="Cybersécurité">Cybersécurité</option>
        <option value="Génie Électrique & Énergies Renouvelables">Génie Électrique & Énergies Renouvelables</option>
        <option value="Génie Climatique & Froid Industriel">Génie Climatique & Froid Industriel</option>
        <option value="Automatique & Robotique Industrielle">Automatique & Robotique Industrielle</option>
      </optgroup>

      <optgroup label="Sciences Appliquées">
        <option value="Industrie Agroalimentaire (IAA)">Industrie Agroalimentaire (IAA)</option>
        <option value="Chimie & Contrôle Qualité (CCQ)">Chimie & Contrôle Qualité (CCQ)</option>
      </optgroup>

      <optgroup label="Sciences Agronomiques">
        <option value="Production Animale">Production Animale</option>
        <option value="Production Végétale">Production Végétale</option>
        <option value="Économie Rurale & Développement Agricole">Économie Rurale & Développement Agricole</option>
      </optgroup>

      <optgroup label="Économie & Gestion">
        <option value="Comptabilité & Audit">Comptabilité & Audit</option>
        <option value="Banque & Assurance">Banque & Assurance</option>
        <option value="Marketing & Communication">Marketing & Communication</option>
        <option value="Gestion des Ressources Humaines">Gestion des Ressources Humaines</option>
        <option value="Logistique & Transport">Logistique & Transport</option>
        <option value="Entrepreneuriat & Management">Entrepreneuriat & Management</option>
        <option value="Marketing Digital">Marketing Digital</option>
      </optgroup>
    </c:otherwise>
  </c:choose>
</select>

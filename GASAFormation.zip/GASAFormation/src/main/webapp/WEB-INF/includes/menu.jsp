<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
  <div class="position-sticky pt-3">
    <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link" href="${pageContext.request.contextPath}/etudiant/dashboard.jsp">
          <i class="bi bi-speedometer2 me-2"></i> Tableau de bord
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="${pageContext.request.contextPath}/etudiant/mesDemandes.jsp">
          <i class="bi bi-journal-text me-2"></i> Mes demandes d'inscription
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="${pageContext.request.contextPath}/etudiant/mesInscriptions.jsp">
          <i class="bi bi-mortarboard me-2"></i> Mes inscriptions
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="${pageContext.request.contextPath}/etudiant/mesPaiements.jsp">
          <i class="bi bi-cash-coin me-2"></i> Mes paiements
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="${pageContext.request.contextPath}/etudiant/inscriptionForm.jsp">
          <i class="bi bi-pencil-square me-2"></i> Nouvelle demande
        </a>
      </li>
      <li class="nav-item mt-3">
        <a class="nav-link text-danger" href="${pageContext.request.contextPath}/logout.jsp">
          <i class="bi bi-box-arrow-right me-2"></i> Déconnexion
        </a>
      </li>
    </ul>
  </div>
</nav>

<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
  <div class="position-sticky pt-3">
    <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link" href="${pageContext.request.contextPath}/comptable/dashboard.jsp">
          Tableau de bord
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="${pageContext.request.contextPath}/comptable/paiements.jsp">
          Paiements (validation)
        </a>
      </li>
      <li class="nav-item mt-3">
        <a class="nav-link text-danger" href="${pageContext.request.contextPath}/logout.jsp">
          Déconnexion
        </a>
      </li>
    </ul>
  </div>
</nav>

<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:choose>
  <c:when test="${empty inscriptions}">
    <div class="alert alert-info">Aucune inscription trouvée.</div>
  </c:when>
  <c:otherwise>
    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead>
          <tr>
            <th>Filière</th>
            <th>Niveau</th>
            <th>Type</th>
            <th>Statut</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <c:forEach var="ins" items="${inscriptions}">
            <tr>
              <td>${ins.filiere}</td>
              <td>${ins.niveau}</td>
              <td>${ins.type}</td>
              <td>
                <span class="badge ${ins.statut eq 'validé' ? 'bg-success' : (ins.statut eq 'en attente' ? 'bg-warning text-dark' : 'bg-secondary')}">
                  ${ins.statut}
                </span>
              </td>
              <td>${ins.dateCreation}</td>
            </tr>
          </c:forEach>
        </tbody>
      </table>
    </div>
  </c:otherwise>
</c:choose>

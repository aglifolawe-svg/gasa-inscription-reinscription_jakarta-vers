<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:choose>
  <c:when test="${empty paiements}">
    <div class="alert alert-info">Aucun paiement trouvé.</div>
  </c:when>
  <c:otherwise>
    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead>
          <tr>
            <th>Montant</th>
            <th>Statut</th>
            <th>Date</th>
            <th>Reçu</th>
          </tr>
        </thead>
        <tbody>
          <c:forEach var="p" items="${paiements}">
            <tr>
              <td>${p.montant}</td>
              <td>
                <span class="badge ${p.statut eq 'validé' ? 'bg-success' : (p.statut eq 'en attente' ? 'bg-warning text-dark' : 'bg-secondary')}">
                  ${p.statut}
                </span>
              </td>
              <td>${p.datePaiement}</td>
              <td>
                <c:if test="${not empty p.recuUrl}">
                  <a class="btn btn-sm btn-outline-primary" href="${p.recuUrl}" target="_blank">Télécharger</a>
                </c:if>
                <c:if test="${empty p.recuUrl}">
                  <span class="text-muted">Non disponible</span>
                </c:if>
              </td>
            </tr>
          </c:forEach>
        </tbody>
      </table>
    </div>
  </c:otherwise>
</c:choose>

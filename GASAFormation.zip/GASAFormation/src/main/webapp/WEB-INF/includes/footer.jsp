<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<footer class="mt-5 border-top pt-3 pb-4 text-center text-muted">
  <small>&copy; UATM GASA Formation</small>
</footer>

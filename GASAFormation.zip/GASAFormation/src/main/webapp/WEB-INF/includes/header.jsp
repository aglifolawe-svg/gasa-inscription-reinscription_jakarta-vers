<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<link href="${pageContext.request.contextPath}/css/theme.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<!-- Top brand bar: matches index.jsp branding -->
<header class="bg-primary text-white py-3 shadow-sm">
  <div class="container d-flex justify-content-between align-items-center">
    <a class="h4 mb-0 text-white text-decoration-none d-flex align-items-center" href="${pageContext.request.contextPath}/index.jsp">
      <i class="bi bi-mortarboard-fill me-2"></i> GASA Formation
    </a>
    <div class="d-flex align-items-center gap-2">
      <!-- Language toggles (same visual behavior as index) -->
      <button class="btn btn-outline-light btn-sm" onclick="setLang('fr')">FR</button>
      <button class="btn btn-light btn-sm text-primary" onclick="setLang('en')">EN</button>
      <!-- Context links for authenticated users -->
      <a href="${pageContext.request.contextPath}/etudiant/dashboard.jsp" class="btn btn-outline-light btn-sm">Mon Espace</a>
      <a href="${pageContext.request.contextPath}/logout.jsp" class="btn btn-light btn-sm text-primary">Déconnexion</a>
    </div>
  </div>
</header>

<script>
  // Optional: reuse the same language switching behavior as index.jsp
  function setLang(lang) {
    // toggle any .lang-fr / .lang-en elements in downstream pages if present
    document.querySelectorAll('.lang-fr').forEach(el => el.style.display = (lang === 'fr') ? 'inline' : 'none');
    document.querySelectorAll('.lang-en').forEach(el => el.style.display = (lang === 'en') ? 'inline' : 'none');
  }
</script>

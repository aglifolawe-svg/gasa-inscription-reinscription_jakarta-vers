<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:choose>
  <c:when test="${empty events}">
    <div class="alert alert-info">Aucun événement à venir.</div>
  </c:when>
  <c:otherwise>
    <ul class="list-group">
      <c:forEach var="ev" items="${events}">
        <li class="list-group-item d-flex justify-content-between align-items-center">
          <div>
            <strong>${ev.titre}</strong><br/>
            <small class="text-muted">${ev.description}</small>
          </div>
          <span class="badge bg-primary">${ev.dateEvenement}</span>
        </li>
      </c:forEach>
    </ul>
  </c:otherwise>
</c:choose>

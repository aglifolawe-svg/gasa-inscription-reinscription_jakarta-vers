<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.security.Principal" %>
<%
    Principal user = request.getUserPrincipal();
    if (user != null) {
        if (request.isUserInRole("etudiant")) {
            response.sendRedirect("etudiant/dashboard.jsp");
            return;
        } else if (request.isUserInRole("secretaire")) {
            response.sendRedirect("secretaire/dashboard.jsp");
            return;
        } else if (request.isUserInRole("comptable")) {
            response.sendRedirect("comptable/dashboard.jsp");
            return;
        } else if (request.isUserInRole("admin")) {
            response.sendRedirect("admin/dashboard.jsp");
            return;
        } else {
            response.sendRedirect("login.jsp");
            return;
        }
    }
%>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Accueil - GASA Formation</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="css/theme.css">
</head>
<body class="bg-light d-flex flex-column min-vh-100">

  <!-- Header -->
  <header class="bg-primary text-white py-3 shadow-sm">
    <div class="container d-flex justify-content-between align-items-center">
      <h1 class="h4 mb-0"><i class="bi bi-mortarboard-fill me-2"></i> GASA Formation</h1>
      <div>
        <!-- Sélecteur de langue -->
        <button class="btn btn-outline-light btn-sm me-2" onclick="setLang('fr')">FR</button>
        <button class="btn btn-light btn-sm text-primary" onclick="setLang('en')">EN</button>
        <a href="login.jsp" class="btn btn-outline-light btn-sm ms-3 lang-fr">Connexion</a>
        <a href="register.jsp" class="btn btn-light btn-sm text-primary lang-fr">Inscription</a>
        <a href="login.jsp" class="btn btn-outline-light btn-sm ms-3 lang-en" style="display:none;">Login</a>
        <a href="register.jsp" class="btn btn-light btn-sm text-primary lang-en" style="display:none;">Register</a>
      </div>
    </div>
  </header>

  <!-- Hero Section -->
  <main class="flex-fill">
    <div class="container text-center py-5">
      <!-- FR -->
      <div id="hero-fr">
        <h2 class="mb-3">Bienvenue sur le Portail GASA Formation</h2>
        <p class="lead text-muted mb-4">
          Votre espace numérique de gestion académique, conçu pour simplifier et sécuriser
          toutes vos démarches administratives et pédagogiques.
        </p>
      </div>
      <!-- EN -->
      <div id="hero-en" style="display:none;">
        <h2 class="mb-3">Welcome to the GASA Formation Portal</h2>
        <p class="lead text-muted mb-4">
          Your digital academic management space, designed to simplify and secure
          all your administrative and educational processes.
        </p>
      </div>

      <div class="d-flex justify-content-center gap-3">
        <a href="login.jsp" class="btn btn-primary btn-lg">
          <i class="bi bi-box-arrow-in-right me-2"></i> 
          <span class="lang-fr">Se connecter</span>
          <span class="lang-en" style="display:none;">Login</span>
        </a>
        <a href="register.jsp" class="btn btn-outline-primary btn-lg">
          <i class="bi bi-pencil-square me-2"></i> 
          <span class="lang-fr">S'inscrire</span>
          <span class="lang-en" style="display:none;">Register</span>
        </a>
      </div>
    </div>

    <!-- Objectif -->
    <section class="bg-white py-5 border-top">
      <div class="container text-center">
        <!-- FR -->
        <div id="objectif-fr">
          <h3 class="mb-4">Pourquoi ce portail ?</h3>
          <p class="lead text-muted">
            Le portail <strong>GASA Formation</strong> a été mis en place pour moderniser et centraliser
            la gestion académique de l’institution.  
            Il vise à <strong>automatiser les processus</strong>, <strong>réduire les erreurs</strong>,
            <strong>assurer la transparence</strong> et <strong>donner une vision globale</strong> à chaque acteur.
          </p>
        </div>
        <!-- EN -->
        <div id="objectif-en" style="display:none;">
          <h3 class="mb-4">Why this portal?</h3>
          <p class="lead text-muted">
            The <strong>GASA Formation</strong> portal was created to modernize and centralize
            the institution’s academic management.  
            Its goals are to <strong>automate processes</strong>, <strong>reduce errors</strong>,
            <strong>ensure transparency</strong>, and <strong>provide a global vision</strong> for every stakeholder.
          </p>
        </div>
      </div>
    </section>
  </main>
  
  <!-- Accès rapides -->
<section class="container my-5">
  <div class="row g-4 text-center">
    <!-- Étudiant -->
    <div class="col-md-3">
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <i class="bi bi-person-badge display-5 text-primary mb-3"></i>
          <h6 class="lang-fr">Espace Étudiant</h6>
          <h6 class="lang-en" style="display:none;">Student Area</h6>
          <a href="etudiant/dashboard.jsp" class="stretched-link"></a>
        </div>
      </div>
    </div>
    <!-- Secrétaire -->
    <div class="col-md-3">
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <i class="bi bi-journal-check display-5 text-success mb-3"></i>
          <h6 class="lang-fr">Espace Secrétaire</h6>
          <h6 class="lang-en" style="display:none;">Secretary Area</h6>
          <a href="secretaire/dashboard.jsp" class="stretched-link"></a>
        </div>
      </div>
    </div>
    <!-- Comptable -->
    <div class="col-md-3">
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <i class="bi bi-cash-coin display-5 text-warning mb-3"></i>
          <h6 class="lang-fr">Espace Comptable</h6>
          <h6 class="lang-en" style="display:none;">Accounting Area</h6>
          <a href="comptable/dashboard.jsp" class="stretched-link"></a>
        </div>
      </div>
    </div>
    <!-- Admin -->
    <div class="col-md-3">
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <i class="bi bi-people-fill display-5 text-danger mb-3"></i>
          <h6 class="lang-fr">Direction des Études</h6>
          <h6 class="lang-en" style="display:none;">Administration</h6>
          <a href="admin/dashboard.jsp" class="stretched-link"></a>
        </div>
      </div>
    </div>
  </div>
</section>


  <!-- Footer -->
  <footer class="bg-dark text-white text-center py-3 mt-auto">
    <p class="mb-0 lang-fr">&copy; 2025 GASA Formation - Tous droits réservés</p>
    <p class="mb-0 lang-en" style="display:none;">&copy; 2025 GASA Formation - All rights reserved</p>
  </footer>

  <!-- Script de langue -->
  <script>
    function setLang(lang) {
      // Hero
      document.getElementById('hero-fr').style.display = (lang === 'fr') ? 'block' : 'none';
      document.getElementById('hero-en').style.display = (lang === 'en') ? 'block' : 'none';
      // Objectif
      document.getElementById('objectif-fr').style.display = (lang === 'fr') ? 'block' : 'none';
      document.getElementById('objectif-en').style.display = (lang === 'en') ? 'block' : 'none';
      // Textes dynamiques
      document.querySelectorAll('.lang-fr').forEach(el => el.style.display = (lang === 'fr') ? 'inline' : 'none');
      document.querySelectorAll('.lang-en').forEach(el => el.style.display = (lang === 'en') ? 'inline' : 'none');
    }
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

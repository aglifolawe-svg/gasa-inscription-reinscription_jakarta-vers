<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Inscription - GASA Formation</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container mt-5">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card shadow-sm">
          <div class="card-header bg-success text-white text-center">
            <h4>Inscription au Portail GASA Formation</h4>
          </div>
          <div class="card-body">
            <form method="post" action="registerAction.jsp">
              <div class="mb-3">
                <label for="username" class="form-label">Nom d'utilisateur</label>
                <input type="text" class="form-control" id="username" name="username" required>
              </div>
              <div class="mb-3">
                <label for="password" class="form-label">Mot de passe</label>
                <input type="password" class="form-control" id="password" name="password" required>
              </div>
              <input type="hidden" name="role" value="etudiant">
              <button type="submit" class="btn btn-success w-100">S'inscrire</button>
            </form>
          </div>
          <div class="card-footer text-center">
            <a href="login.jsp">Déjà inscrit ? Connectez-vous</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>

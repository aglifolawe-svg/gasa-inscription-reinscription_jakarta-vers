<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.EvenementDAO" %>
<%@ page import="com.gasaformation.model.Evenement" %>
<%@ page import="java.util.*" %>
<%
  EvenementDAO edao = new EvenementDAO();
  List<Evenement> events = edao.findAll();
  request.setAttribute("events", events);
%>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Événements - Admin | GASA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="${pageContext.request.contextPath}/css/theme.css" rel="stylesheet">
</head>
<body class="bg-light">
  <jsp:include page="/WEB-INF/includes/header.jsp"/>
  <div class="container-fluid">
    <div class="row">
      <jsp:include page="/WEB-INF/includes/admin_menu.jsp"/>

      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="pt-3 pb-2 mb-3 border-bottom">
          <h1 class="h2">Événements</h1>
        </div>

        <div class="card mb-4">
          <div class="card-header">Ajouter un événement</div>
          <div class="card-body">
            <form action="evenementsAction.jsp" method="post">
              <div class="row g-3">
                <div class="col-md-6">
                  <label class="form-label">Titre</label>
                  <input type="text" name="titre" class="form-control" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Date</label>
                  <input type="datetime-local" name="date" class="form-control" required>
                </div>
                <div class="col-12">
                  <label class="form-label">Description</label>
                  <textarea name="description" rows="3" class="form-control"></textarea>
                </div>
              </div>
              <div class="text-end mt-3">
                <button class="btn btn-primary">Enregistrer</button>
              </div>
            </form>
          </div>
        </div>

        <div class="card">
          <div class="card-header">Tous les événements</div>
          <div class="card-body">
            <c:choose>
              <c:when test="${empty events}">
                <div class="alert alert-info">Aucun événement enregistré.</div>
              </c:when>
              <c:otherwise>
                <div class="table-responsive">
                  <table class="table table-striped align-middle">
                    <thead class="table-light"><tr><th>ID</th><th>Titre</th><th>Date</th><th>Description</th></tr></thead>
                    <tbody>
                      <c:forEach var="ev" items="${events}">
                        <tr>
                          <td>${ev.id}</td><td>${ev.titre}</td><td>${ev.dateEvenement}</td><td>${ev.description}</td>
                        </tr>
                      </c:forEach>
                    </tbody>
                  </table>
                </div>
              </c:otherwise>
            </c:choose>
          </div>
        </div>

        <jsp:include page="/WEB-INF/includes/footer.jsp"/>
      </main>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.CritereAdmissionDAO" %>
<%@ page import="com.gasaformation.model.CritereAdmission" %>
<%
  request.setCharacterEncoding("UTF-8");
  String titre = request.getParameter("titre");
  String niveau = request.getParameter("niveau");
  String description = request.getParameter("description");

  if (titre == null || niveau == null || description == null) {
      response.sendRedirect("criteres.jsp?error=invalid");
      return;
  }

  try {
      CritereAdmissionDAO cdao = new CritereAdmissionDAO();
      CritereAdmission cr = new CritereAdmission();
      cr.setTitre(titre);
      cr.setNiveau(niveau);
      cr.setDescription(description);
      cdao.insert(cr);
      response.sendRedirect("criteres.jsp?ok=1");
  } catch (Exception e) {
      response.sendRedirect("criteres.jsp?error=server");
  }
%>

<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.InscriptionDAO, com.gasaformation.dao.PaiementDAO, com.gasaformation.dao.EvenementDAO" %>
<%@ page import="java.util.*" %>
<%
  InscriptionDAO idao = new InscriptionDAO();
  PaiementDAO pdao = new PaiementDAO();
  EvenementDAO edao = new EvenementDAO();

  int inscPending = idao.findByStatut("en attente").size();
  int inscValid   = idao.findByStatut("validé").size();
  int payPending  = pdao.findByStatut("en attente").size();
  int payValid    = pdao.findByStatut("validé").size();
%>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Admin (DE) - GASA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container-fluid py-4">
    <h2 class="mb-4">Pilotage — UATM GASA Formation</h2>
    <div class="row g-3">
      <div class="col-md-3"><div class="card text-bg-warning"><div class="card-body"><h6>Inscriptions en attente</h6><p class="fs-3 mb-0"><%= inscPending %></p></div></div></div>
      <div class="col-md-3"><div class="card text-bg-success"><div class="card-body"><h6>Inscriptions validées</h6><p class="fs-3 mb-0"><%= inscValid %></p></div></div></div>
      <div class="col-md-3"><div class="card text-bg-warning"><div class="card-body"><h6>Paiements en attente</h6><p class="fs-3 mb-0"><%= payPending %></p></div></div></div>
      <div class="col-md-3"><div class="card text-bg-success"><div class="card-body"><h6>Paiements validés</h6><p class="fs-3 mb-0"><%= payValid %></p></div></div></div>
    </div>

    <div class="card mt-4">
      <div class="card-header">Modules (mock)</div>
      <div class="card-body">
        <div class="row g-3">
          <div class="col-md-3"><div class="border rounded p-3"><strong>Gestion des filières</strong><p class="text-muted mb-2">Mock</p><a class="btn btn-outline-secondary btn-sm disabled">Ouvrir</a></div></div>
          <div class="col-md-3"><div class="border rounded p-3"><strong>Emploi du temps</strong><p class="text-muted mb-2">Mock</p><a class="btn btn-outline-secondary btn-sm disabled">Ouvrir</a></div></div>
          <div class="col-md-3"><div class="border rounded p-3"><strong>Critères d’admission</strong><p class="text-muted mb-2">Réel (ci-dessous)</p><a class="btn btn-primary btn-sm" href="${pageContext.request.contextPath}/admin/criteres.jsp">Configurer</a></div></div>
          <div class="col-md-3"><div class="border rounded p-3"><strong>Utilisateurs et rôles</strong><p class="text-muted mb-2">Mock</p><a class="btn btn-outline-secondary btn-sm disabled">Ouvrir</a></div></div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>

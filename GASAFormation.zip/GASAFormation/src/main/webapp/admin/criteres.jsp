<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.CritereAdmissionDAO" %>
<%@ page import="com.gasaformation.model.CritereAdmission" %>
<%@ page import="java.util.*" %>
<%
  CritereAdmissionDAO cdao = new CritereAdmissionDAO();
  List<CritereAdmission> criteres = cdao.findAll();
  request.setAttribute("criteres", criteres);
%>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Critères d’admission - Admin | GASA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-4">
    <h2 class="mb-3">Critères d’admission</h2>

    <div class="card mb-4">
      <div class="card-header">Ajouter un critère</div>
      <div class="card-body">
        <form action="criteresAction.jsp" method="post">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Titre</label>
              <input type="text" name="titre" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Niveau</label>
              <input type="text" name="niveau" class="form-control" placeholder="L1, L2, M1..." required>
            </div>
            <div class="col-12">
              <label class="form-label">Description</label>
              <textarea name="description" rows="3" class="form-control" required></textarea>
            </div>
          </div>
          <div class="text-end mt-3">
            <button class="btn btn-primary">Enregistrer</button>
          </div>
        </form>
      </div>
    </div>

    <div class="card">
      <div class="card-header">Critères existants</div>
      <div class="card-body">
        <c:choose>
          <c:when test="${empty criteres}">
            <div class="alert alert-info">Aucun critère enregistré.</div>
          </c:when>
          <c:otherwise>
            <div class="table-responsive">
              <table class="table table-striped align-middle">
                <thead class="table-light"><tr><th>ID</th><th>Titre</th><th>Niveau</th><th>Description</th></tr></thead>
                <tbody>
                  <c:forEach var="cr" items="${criteres}">
                    <tr>
                      <td>${cr.id}</td><td>${cr.titre}</td><td>${cr.niveau}</td><td>${cr.description}</td>
                    </tr>
                  </c:forEach>
                </tbody>
              </table>
            </div>
          </c:otherwise>
        </c:choose>
      </div>
    </div>
  </div>
</body>
</html>

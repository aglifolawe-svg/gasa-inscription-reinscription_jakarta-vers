<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.*" %>
<%@ page import="com.gasaformation.model.*" %>
<%@ page import="java.security.Principal" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<%
  // RBAC: admin only
  Principal principal = request.getUserPrincipal();
  if (principal == null || !request.isUserInRole("admin")) {
      response.sendRedirect(request.getContextPath() + "/login.jsp?error=forbidden");
      return;
  }

  // DAOs
  InscriptionDAO idao = new InscriptionDAO();
  PaiementDAO pdao = new PaiementDAO();
  EvenementDAO edao = new EvenementDAO();
  NotificationDAO ndao = null;
  AuditTrailRepository auditRepo = null;
  try { ndao = new NotificationDAO(); } catch (Exception ignore) {}
  try { auditRepo = new AuditTrailRepository(); } catch (Exception ignore) {}

  // Global stats
  int inscPending = idao.findByStatut("en attente").size();
  int inscValid   = idao.findByStatut("validé").size();
  int inscReject  = idao.findByStatut("rejete").size();

  int payPending = pdao.findByStatut("en attente").size();
  int payValid   = pdao.findByStatut("validé").size();
  int payReject  = pdao.findByStatut("rejete").size();

  List<Evenement> upcomingEvents = edao.findUpcoming();
  int eventsUpcoming = upcomingEvents != null ? upcomingEvents.size() : 0;

  // Greeting and time
  Calendar now = Calendar.getInstance();
  int hour = now.get(Calendar.HOUR_OF_DAY);
  String greeting = (hour < 12) ? "Bonjour" : (hour < 18 ? "Bon après-midi" : "Bonsoir");
  String currentDate = new java.text.SimpleDateFormat("dd/MM/yyyy").format(new java.util.Date());
  String currentTime = new java.text.SimpleDateFormat("HH:mm").format(new java.util.Date());

  // Notifications
  int notifCount = 0;
  Integer adminUserId = (Integer) session.getAttribute("currentUserId");
  List<Notification> recentNotifs = Collections.emptyList();
  if (ndao != null && adminUserId != null) {
    recentNotifs = ndao.findByUser(adminUserId);
    for (Notification n : recentNotifs) {
      if (!n.isLu()) notifCount++;
    }
  }

  // Chart data (validated inscriptions by month)
  int[] inscByMonth = new int[12];
  Calendar cal = Calendar.getInstance();
  List<Inscription> valides = idao.findByStatut("validé");
  for (Inscription ins : valides) {
    if (ins.getDateInscription() != null) {
      cal.setTime(ins.getDateInscription());
      inscByMonth[cal.get(Calendar.MONTH)]++;
    }
  }

  // Recent audit trail (last 10)
  List<AuditTrail> recentAudits = new ArrayList<>();
  if (auditRepo != null) {
    List<AuditTrail> all = auditRepo.findAll();
    for (int i = 0; i < all.size() && i < 10; i++) recentAudits.add(all.get(i));
  }

  // Expose to JSP
  request.setAttribute("greeting", greeting);
  request.setAttribute("currentDate", currentDate);
  request.setAttribute("currentTime", currentTime);
  request.setAttribute("notifCount", notifCount);
  request.setAttribute("recentNotifs", recentNotifs);
  request.setAttribute("upcomingEvents", upcomingEvents);
  request.setAttribute("recentAudits", recentAudits);
%>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Admin (DE) - GASA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link href="${pageContext.request.contextPath}/css/theme.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light">

  <jsp:include page="/WEB-INF/includes/header.jsp"/>

  <div class="container-fluid">
    <div class="row">
      <jsp:include page="/WEB-INF/includes/admin_menu.jsp"/>

      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-3 border-bottom">
          <div>
            <h1 class="h4 mb-1">${greeting}, Direction des Études</h1>
            <small class="text-muted">Nous sommes le ${currentDate} — ${currentTime}</small>
          </div>
          <div>
            <a href="${pageContext.request.contextPath}/admin/notifications.jsp"
               class="btn btn-light position-relative">
              <i class="bi bi-bell"></i> Notifications
              <c:if test="${notifCount > 0}">
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                  ${notifCount}
                </span>
              </c:if>
            </a>
          </div>
        </div>

        <!-- Global stats -->
        <div class="row g-3 mb-4">
          <div class="col-md-3">
            <div class="card text-bg-warning shadow-sm">
              <div class="card-body text-center">
                <h6><i class="bi bi-hourglass-split me-2"></i>Inscriptions en attente</h6>
                <p class="fs-3 mb-0"><%= inscPending %></p>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card text-bg-success shadow-sm">
              <div class="card-body text-center">
                <h6><i class="bi bi-check-circle me-2"></i>Inscriptions validées</h6>
                <p class="fs-3 mb-0"><%= inscValid %></p>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card text-bg-danger shadow-sm">
              <div class="card-body text-center">
                <h6><i class="bi bi-x-circle me-2"></i>Inscriptions rejetées</h6>
                <p class="fs-3 mb-0"><%= inscReject %></p>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card text-bg-info shadow-sm">
              <div class="card-body text-center">
                <h6><i class="bi bi-calendar-event me-2"></i>Événements à venir</h6>
                <p class="fs-3 mb-0"><%= eventsUpcoming %></p>
              </div>
            </div>
          </div>
        </div>

        <!-- Charts -->
        <div class="row g-3">
          <div class="col-lg-6">
            <div class="card shadow-sm">
              <div class="card-header">Répartition des inscriptions</div>
              <div class="card-body"><canvas id="chartInsc" height="100"></canvas></div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="card shadow-sm">
              <div class="card-header">Répartition des paiements</div>
              <div class="card-body"><canvas id="chartPay" height="100"></canvas></div>
            </div>
          </div>
        </div>

        <!-- Quick actions -->
        <div class="my-4 d-flex flex-wrap gap-2">
          <a href="${pageContext.request.contextPath}/secretaire/inscriptions.jsp" class="btn btn-primary">
            <i class="bi bi-journal-check"></i> Gérer les inscriptions
          </a>
          <a href="${pageContext.request.contextPath}/admin/auditTrail.jsp" class="btn btn-outline-secondary">
            <i class="bi bi-clock-history"></i> Historique global
          </a>
          <a href="${pageContext.request.contextPath}/admin/criteres.jsp" class="btn btn-outline-primary">
            <i class="bi bi-sliders"></i> Critères d’admission
          </a>
          <a href="${pageContext.request.contextPath}/admin/evenements.jsp" class="btn btn-outline-secondary">
            <i class="bi bi-calendar2-event"></i> Événements
          </a>
          <a href="${pageContext.request.contextPath}/admin/utilisateurs.jsp" class="btn btn-outline-secondary">
            <i class="bi bi-people"></i> Utilisateurs & rôles
          </a>
          <a href="${pageContext.request.contextPath}/admin/filieres.jsp" class="btn btn-outline-secondary">
            <i class="bi bi-diagram-3"></i> Filières
          </a>
        </div>

        <!-- Recent notifications -->
        <div class="card mb-4 shadow-sm">
          <div class="card-header">Notifications récentes</div>
          <div class="card-body">
            <c:choose>
              <c:when test="${empty recentNotifs}">
                <div class="alert alert-info mb-0">Aucune notification.</div>
              </c:when>
              <c:otherwise>
                <ul class="list-group list-group-flush">
                  <c:forEach var="n" items="${recentNotifs}" end="9">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      <div>
                        <span class="badge bg-secondary me-2">${n.type}</span>
                        <strong>${n.titre}</strong>
                        <div class="small text-muted">${n.message}</div>
                      </div>
                      <a class="btn btn-sm btn-outline-primary" href="${pageContext.request.contextPath}/${n.lien}">Ouvrir</a>
                    </li>
                  </c:forEach>
                </ul>
              </c:otherwise>
            </c:choose>
          </div>
        </div>

        <!-- Upcoming events -->
        <div class="card mb-4 shadow-sm">
          <div class="card-header">Événements à venir</div>
          <div class="card-body">
            <c:choose>
              <c:when test="${empty upcomingEvents}">
                <div class="alert alert-info mb-0">Aucun événement planifié.</div>
              </c:when>
              <c:otherwise>
                <div class="table-responsive">
                  <table class="table table-hover align-middle">
                    <thead class="table-light">
                      <tr><th>Titre</th><th>Date</th><th>Lieu</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                      <c:forEach var="ev" items="${upcomingEvents}">
                        <tr>
                          <td>${ev.titre}</td>
                          <td>${ev.dateEvenement}</td>
                          <td>${ev.lieu}</td>
                          <td>
                            <a class="btn btn-sm btn-outline-secondary" href="${pageContext.request.contextPath}/admin/evenements.jsp?eventId=${ev.id}">
                              <i class="bi bi-eye"></i> Voir
                            </a>
                          </td>
                        </tr>
                      </c:forEach>
                    </tbody>
                  </table>
                </div>
              </c:otherwise>
            </c:choose>
          </div>
        </div>

        <!-- Recent audit trail -->
        <div class="card mb-5 shadow-sm">
          <div class="card-header">Dernières actions (Audit)</div>
          <div class="card-body">
            <c:choose>
              <c:when test="${empty recentAudits}">
                <div class="alert alert-info mb-0">Aucune activité récente.</div>
              </c:when>
              <c:otherwise>
                <div class="table-responsive">
                  <table class="table table-striped align-middle">
                    <thead class="table-light">
                      <tr><th>Date</th><th>Entité</th><th>ID</th><th>Action</th><th>Utilisateur</th><th>Commentaire</th></tr>
                    </thead>
                    <tbody>
                      <c:forEach var="a" items="${recentAudits}">
                        <tr>
                          <td>${a.dateAction}</td>
                          <td>${a.entity}</td>
                          <td>${a.entityId}</td>
                          <td>${a.action}</td>
                          <td>${a.userId}</td>
                          <td>${a.commentaire}</td>
                        </tr>
                      </c:forEach>
                    </tbody>
                  </table>
                </div>
              </c:otherwise>
            </c:choose>
            <div class="text-end">
              <a class="btn btn-outline-secondary btn-sm" href="${pageContext.request.contextPath}/admin/auditTrail.jsp">
                Voir tout l’historique
              </a>
            </div>
          </div>
        </div>

        <jsp:include page="/WEB-INF/includes/footer.jsp"/>

      </main>
    </div>
  </div>

  <!-- Charts -->
  <script>
    // Doughnut: inscriptions repartition
    new Chart(document.getElementById('chartInsc'), {
      type: 'doughnut',
      data: {
        labels: ['Validées','En attente','Rejetées'],
        datasets: [{ data: [<%= inscValid %>, <%= inscPending %>, <%= inscReject %>],
          backgroundColor: ['#198754','#ffc107','#dc3545'] }]
      },
      options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
    });

    // Doughnut: paiements repartition
    new Chart(document.getElementById('chartPay'), {
      type: 'doughnut',
      data: {
        labels: ['Validés','En attente','Rejetés'],
        datasets: [{ data: [<%= payValid %>, <%= payPending %>, <%= payReject %>],
          backgroundColor: ['#198754','#ffc107','#dc3545'] }]
      },
      options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
    });
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

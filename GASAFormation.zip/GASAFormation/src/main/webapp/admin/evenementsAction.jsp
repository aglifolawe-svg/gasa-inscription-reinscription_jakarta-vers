<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.EvenementDAO" %>
<%@ page import="com.gasaformation.model.Evenement" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.util.Date" %>
<%
  request.setCharacterEncoding("UTF-8");
  String titre = request.getParameter("titre");
  String description = request.getParameter("description");
  String date = request.getParameter("date"); // "YYYY-MM-DDTHH:mm"

  if (titre == null || date == null) {
      response.sendRedirect("evenements.jsp?error=invalid");
      return;
  }

  try {
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
      Date d = sdf.parse(date);

      Evenement ev = new Evenement();
      ev.setTitre(titre);
      ev.setDescription(description);
      ev.setDateEvenement(d);

      EvenementDAO edao = new EvenementDAO();
      edao.insert(ev);

      response.sendRedirect("evenements.jsp?ok=1");
  } catch (Exception e) {
      response.sendRedirect("evenements.jsp?error=server");
  }
%>

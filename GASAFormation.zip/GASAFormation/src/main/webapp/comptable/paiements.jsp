<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.PaiementDAO" %>
<%@ page import="com.gasaformation.model.Paiement" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<%
  PaiementDAO pdao = new PaiementDAO();
  List<Paiement> pending = pdao.findByStatut("en attente");
  List<Paiement> valides = pdao.findByStatut("validé");
  List<Paiement> rejetes = pdao.findByStatut("rejete");

  String tab = request.getParameter("tab");
  if (tab == null) tab = "pending";
%>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Paiements - Comptable | GASA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container-fluid py-4">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <h2 class="mb-0">Gestion des paiements</h2>
  </div>

  <ul class="nav nav-tabs">
    <li class="nav-item"><a class="nav-link ${tab=='pending'?'active':''}" href="?tab=pending">En attente</a></li>
    <li class="nav-item"><a class="nav-link ${tab=='valides'?'active':''}" href="?tab=valides">Validés</a></li>
    <li class="nav-item"><a class="nav-link ${tab=='rejetes'?'active':''}" href="?tab=rejetes">Rejetés</a></li>
  </ul>

  <div class="tab-content pt-3">
    <div class="tab-pane fade ${tab=='pending'?'show active':''}">
      <c:choose>
        <c:when test="${empty pending}"><div class="alert alert-info">Aucun paiement en attente.</div></c:when>
        <c:otherwise>
          <div class="table-responsive">
            <table class="table table-hover align-middle">
              <thead class="table-light"><tr><th>ID</th><th>Étudiant ID</th><th>Montant</th><th>Date</th><th>Reçu</th><th class="text-end">Actions</th></tr></thead>
              <tbody>
                <c:forEach var="p" items="${pending}">
                  <tr>
                    <td>${p.id}</td><td>${p.etudiantId}</td><td>${p.montant}</td><td>${p.datePaiement}</td>
                    <td>
                      <c:if test="${not empty p.recuUrl}">
                        <a href="${p.recuUrl}" target="_blank">Voir</a>
                      </c:if>
                      <c:if test="${empty p.recuUrl}">
                        <span class="text-muted">Non disponible</span>
                      </c:if>
                    </td>
                    <td class="text-end">
                      <form action="PaiementValidationAction.jsp" method="post" class="d-inline">
                        <input type="hidden" name="paiementId" value="${p.id}">
                        <button type="submit" name="action" value="valider" class="btn btn-sm btn-success">Valider</button>
                      </form>
                      <form action="PaiementValidationAction.jsp" method="post" class="d-inline ms-2">
                        <input type="hidden" name="paiementId" value="${p.id}">
                        <button type="submit" name="action" value="rejeter" class="btn btn-sm btn-danger">Rejeter</button>
                      </form>
                    </td>
                  </tr>
                </c:forEach>
              </tbody>
            </table>
          </div>
        </c:otherwise>
      </c:choose>
    </div>

    <div class="tab-pane fade ${tab=='valides'?'show active':''}">
      <c:choose>
        <c:when test="${empty valides}"><div class="alert alert-info">Aucun paiement validé.</div></c:when>
        <c:otherwise>
          <div class="table-responsive">
            <table class="table table-striped align-middle">
              <thead class="table-light"><tr><th>ID</th><th>Étudiant ID</th><th>Montant</th><th>Date</th><th>Reçu</th></tr></thead>
              <tbody>
                <c:forEach var="p" items="${valides}">
                  <tr>
                    <td>${p.id}</td><td>${p.etudiantId}</td><td>${p.montant}</td><td>${p.datePaiement}</td>
                    <td><c:if test="${not empty p.recuUrl}"><a href="${p.recuUrl}" target="_blank">Voir</a></c:if></td>
                  </tr>
                </c:forEach>
              </tbody>
            </table>
          </div>
        </c:otherwise>
      </c:choose>
    </div>

    <div class="tab-pane fade ${tab=='rejetes'?'show active':''}">
      <c:choose>
        <c:when test="${empty rejetes}"><div class="alert alert-info">Aucun paiement rejeté.</div></c:when>
        <c:otherwise>
          <div class="table-responsive">
            <table class="table table-striped align-middle">
              <thead class="table-light"><tr><th>ID</th><th>Étudiant ID</th><th>Montant</th><th>Date</th><th>Reçu</th></tr></thead>
              <tbody>
                <c:forEach var="p" items="${rejetes}">
                  <tr>
                    <td>${p.id}</td><td>${p.etudiantId}</td><td>${p.montant}</td><td>${p.datePaiement}</td>
                    <td><c:if test="${not empty p.recuUrl}"><a href="${p.recuUrl}" target="_blank">Voir</a></c:if></td>
                  </tr>
                </c:forEach>
              </tbody>
            </table>
          </div>
        </c:otherwise>
      </c:choose>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

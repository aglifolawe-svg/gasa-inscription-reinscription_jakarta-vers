<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.PaiementDAO" %>

<%
  request.setCharacterEncoding("UTF-8");
  String action = request.getParameter("action");
  String payIdStr = request.getParameter("paiementId");

  if (action == null || payIdStr == null) {
      response.sendRedirect("paiements.jsp?error=invalid");
      return;
  }

  int paiementId = Integer.parseInt(payIdStr);

  try {
      PaiementDAO pdao = new PaiementDAO();
      if ("valider".equalsIgnoreCase(action)) {
          pdao.updateStatut(paiementId, "validé");
          response.sendRedirect("paiements.jsp?ok=valide");
      } else if ("rejeter".equalsIgnoreCase(action)) {
          pdao.updateStatut(paiementId, "rejete");
          response.sendRedirect("paiements.jsp?ok=rejete");
      } else {
          response.sendRedirect("paiements.jsp?error=action");
      }
  } catch (Exception e) {
      response.sendRedirect("paiements.jsp?error=server");
  }
%>

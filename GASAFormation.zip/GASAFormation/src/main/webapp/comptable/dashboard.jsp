<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.PaiementDAO, com.gasaformation.dao.NotificationDAO" %>
<%@ page import="com.gasaformation.model.Paiement, com.gasaformation.model.Notification" %>
<%@ page import="java.security.Principal" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<%
  // RBAC: comptable only (allow admin optionally)
  Principal principal = request.getUserPrincipal();
  if (principal == null || !(request.isUserInRole("comptable") || request.isUserInRole("admin"))) {
      response.sendRedirect(request.getContextPath() + "/login.jsp?error=forbidden");
      return;
  }

  PaiementDAO pdao = new PaiementDAO();
  List<Paiement> pending = pdao.findByStatut("en attente");
  List<Paiement> valides = pdao.findByStatut("validé");
  List<Paiement> rejetes = pdao.findByStatut("rejete");

  int countPending = pending != null ? pending.size() : 0;
  int countValides = valides != null ? valides.size() : 0;
  int countRejetes = rejetes != null ? rejetes.size() : 0;

  // Optional totals for quick insight
  double totalValides = 0.0;
  double totalPending = 0.0;
  double totalRejetes = 0.0;
  if (valides != null) for (Paiement p : valides) totalValides += (p.getMontant() != null ? p.getMontant() : 0.0);
  if (pending != null) for (Paiement p : pending) totalPending += (p.getMontant() != null ? p.getMontant() : 0.0);
  if (rejetes != null) for (Paiement p : rejetes) totalRejetes += (p.getMontant() != null ? p.getMontant() : 0.0);

  // Greeting
  Calendar now = Calendar.getInstance();
  int hour = now.get(Calendar.HOUR_OF_DAY);
  String greeting = (hour < 12) ? "Bonjour" : (hour < 18 ? "Bon après-midi" : "Bonsoir");
  String currentDate = new java.text.SimpleDateFormat("dd/MM/yyyy").format(new java.util.Date());
  String currentTime = new java.text.SimpleDateFormat("HH:mm").format(new java.util.Date());

  // Notifications for current user
  int notifCount = 0;
  List<Notification> recentNotifs = Collections.emptyList();
  Integer currentUserId = (Integer) session.getAttribute("currentUserId");
  try {
    if (currentUserId != null) {
      NotificationDAO ndao = new NotificationDAO();
      recentNotifs = ndao.findByUser(currentUserId);
      for (Notification n : recentNotifs) if (!n.isLu()) notifCount++;
    }
  } catch (Exception ignore) {}

  // Expose attrs
  request.setAttribute("greeting", greeting);
  request.setAttribute("currentDate", currentDate);
  request.setAttribute("currentTime", currentTime);
  request.setAttribute("notifCount", notifCount);
  request.setAttribute("pending", pending);
  request.setAttribute("recentNotifs", recentNotifs);
%>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Comptable - GASA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link href="${pageContext.request.contextPath}/css/theme.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light">

  <jsp:include page="/WEB-INF/includes/header.jsp"/>

  <div class="container-fluid">
    <div class="row">
      <jsp:include page="/WEB-INF/includes/comptable_menu.jsp"/>

      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

        <!-- Header with greeting and notifications -->
        <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-3 border-bottom">
          <div>
            <h1 class="h4 mb-1">${greeting}, Comptabilité</h1>
            <small class="text-muted">Nous sommes le ${currentDate} — ${currentTime}</small>
          </div>
          <div>
            <a href="${pageContext.request.contextPath}/comptable/notifications.jsp"
               class="btn btn-light position-relative">
              <i class="bi bi-bell"></i> Notifications
              <c:if test="${notifCount > 0}">
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                  ${notifCount}
                </span>
              </c:if>
            </a>
          </div>
        </div>

        <!-- Quick actions -->
        <div class="mb-4 d-flex flex-wrap gap-2 justify-content-end">
          <a href="${pageContext.request.contextPath}/comptable/paiements.jsp" class="btn btn-primary">
            <i class="bi bi-cash-coin"></i> Gérer les paiements
          </a>
          <a href="${pageContext.request.contextPath}/comptable/recus.jsp" class="btn btn-outline-secondary">
            <i class="bi bi-receipt"></i> Reçus
          </a>
          <a href="${pageContext.request.contextPath}/secretaire/inscriptions.jsp" class="btn btn-outline-secondary">
            <i class="bi bi-journal-check"></i> Dossiers étudiants
          </a>
        </div>

        <!-- Counters -->
        <div class="row g-3 mb-4">
          <div class="col-md-4">
            <div class="card text-bg-warning shadow-sm">
              <div class="card-body text-center">
                <h6><i class="bi bi-hourglass-split me-2"></i>En attente</h6>
                <p class="fs-3 mb-1"><%= countPending %></p>
                <div class="small">Total: <strong><%= String.format("%.0f", totalPending) %></strong> FCFA</div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card text-bg-success shadow-sm">
              <div class="card-body text-center">
                <h6><i class="bi bi-check-circle me-2"></i>Validés</h6>
                <p class="fs-3 mb-1"><%= countValides %></p>
                <div class="small">Total: <strong><%= String.format("%.0f", totalValides) %></strong> FCFA</div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card text-bg-danger shadow-sm">
              <div class="card-body text-center">
                <h6><i class="bi bi-x-circle me-2"></i>Rejetés</h6>
                <p class="fs-3 mb-1"><%= countRejetes %></p>
                <div class="small">Total: <strong><%= String.format("%.0f", totalRejetes) %></strong> FCFA</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Chart -->
        <div class="card mb-4 shadow-sm">
          <div class="card-header">Répartition des paiements</div>
          <div class="card-body">
            <canvas id="chartPaiements" height="100"></canvas>
          </div>
        </div>

        <!-- Pending payments table with actions -->
        <div class="card mb-5 shadow-sm">
          <div class="card-header d-flex justify-content-between align-items-center">
            <span>Paiements en attente</span>
            <a href="${pageContext.request.contextPath}/comptable/paiements.jsp" class="btn btn-sm btn-outline-primary">
              <i class="bi bi-filter"></i> Filtrer et gérer
            </a>
          </div>
          <div class="card-body">
            <c:choose>
              <c:when test="${empty pending}">
                <div class="alert alert-info mb-0">Aucun paiement en attente.</div>
              </c:when>
              <c:otherwise>
                <div class="table-responsive">
                  <table class="table table-bordered table-hover align-middle">
                    <thead class="table-light">
                      <tr>
                        <th>Date</th>
                        <th>Étudiant</th>
                        <th>Référence</th>
                        <th>Montant</th>
                        <th>Moyen</th>
                        <th>Motif</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <c:forEach var="p" items="${pending}">
                        <tr>
                          <td><fmt:formatDate value="${p.datePaiement}" pattern="dd/MM/yyyy"/></td>
                          <td>Utilisateur #${p.etudiantId}</td>
                          <td>${p.reference}</td>
                          <td><strong>${p.montant}</strong> FCFA</td>
                          <td>${p.moyen}</td>
                          <td>${p.motif}</td>
                          <td>
                            <form action="paiementsValidation.jsp" method="post" class="d-inline">
                              <input type="hidden" name="paiementId" value="${p.id}">
                              <input type="hidden" name="etudiantId" value="${p.etudiantId}">
                              <button type="submit" name="action" value="valider" class="btn btn-outline-success btn-sm">
                                <i class="bi bi-check2-circle"></i> Valider
                              </button>
                            </form>
                            <form action="paiementsValidation.jsp" method="post" class="d-inline ms-2">
                              <input type="hidden" name="paiementId" value="${p.id}">
                              <button type="submit" name="action" value="rejeter" class="btn btn-outline-danger btn-sm">
                                <i class="bi bi-x-circle"></i> Rejeter
                              </button>
                            </form>
                            <a href="paiementsDetails.jsp?id=${p.id}" class="btn btn-outline-secondary btn-sm ms-2">
                              <i class="bi bi-eye"></i> Détails
                            </a>
                          </td>
                        </tr>
                      </c:forEach>
                    </tbody>
                  </table>
                </div>
              </c:otherwise>
            </c:choose>
          </div>
        </div>

        <!-- Recent notifications -->
        <div class="card mb-5 shadow-sm">
          <div class="card-header">Notifications récentes</div>
          <div class="card-body">
            <c:choose>
              <c:when test="${empty recentNotifs}">
                <div class="alert alert-info mb-0">Aucune notification.</div>
              </c:when>
              <c:otherwise>
                <ul class="list-group list-group-flush">
                  <c:forEach var="n" items="${recentNotifs}" end="9">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      <div>
                        <span class="badge bg-secondary me-2">${n.type}</span>
                        <strong>${n.titre}</strong>
                        <div class="small text-muted">${n.message}</div>
                      </div>
                      <a class="btn btn-sm btn-outline-primary" href="${pageContext.request.contextPath}/${n.lien}">Ouvrir</a>
                    </li>
                  </c:forEach>
                </ul>
              </c:otherwise>
            </c:choose>
          </div>
        </div>

        <jsp:include page="/WEB-INF/includes/footer.jsp"/>
      </main>
    </div>
  </div>

  <!-- Chart.js -->
  <script>
    const pieData = [<%= countValides %>, <%= countPending %>, <%= countRejetes %>];
    new Chart(document.getElementById('chartPaiements'), {
      type: 'doughnut',
      data: {
        labels: ['Validés', 'En attente', 'Rejetés'],
        datasets: [{ data: pieData, backgroundColor: ['#198754','#ffc107','#dc3545'] }]
      },
      options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
    });
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.*" %>
<%@ page import="com.gasaformation.model.*" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<%
    String username = (request.getUserPrincipal() != null) ? request.getUserPrincipal().getName() : null;
    if (username == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp?error=auth");
        return;
    }

    UtilisateurDAO udao = new UtilisateurDAO();
    Utilisateur user = udao.findByUsername(username);

    List<Notification> notifications = new ArrayList<>();
    try {
        NotificationDAO ndao = new NotificationDAO();
        notifications = ndao.findByUser(user.getId());
    } catch (Exception e) {
        e.printStackTrace();
    }

    request.setAttribute("notifications", notifications);
%>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Mes notifications - GASA Formation</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

  <jsp:include page="/WEB-INF/includes/header.jsp"/>

  <div class="container-fluid">
    <div class="row">
      <jsp:include page="/WEB-INF/includes/menu.jsp"/>

      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-3 border-bottom">
          <h1 class="h4">Mes notifications</h1>
          <a href="${pageContext.request.contextPath}/dashboard.jsp" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left"></i> Retour
          </a>
        </div>

        <c:choose>
          <c:when test="${empty notifications}">
            <div class="alert alert-info">Aucune notification pour le moment.</div>
          </c:when>
          <c:otherwise>
            <div class="list-group">
              <c:forEach var="notif" items="${notifications}">
                <div class="list-group-item d-flex justify-content-between align-items-center 
                            <c:if test='${!notif.lu}'>list-group-item-warning</c:if>">
                  <div>
                    <i class="bi bi-bell-fill me-2"></i>
                    ${notif.message}
                    <br>
                    <small class="text-muted">
                      <fmt:formatDate value="${notif.dateNotif}" pattern="dd/MM/yyyy HH:mm"/>
                    </small>
                  </div>
                  <c:if test="${!notif.lu}">
                    <form action="marquerLu" method="post" class="mb-0">
                      <input type="hidden" name="id" value="${notif.id}">
                      <button type="submit" class="btn btn-sm btn-outline-success">Marquer comme lu</button>
                    </form>
                  </c:if>
                </div>
              </c:forEach>
            </div>
          </c:otherwise>
        </c:choose>

        <jsp:include page="/WEB-INF/includes/footer.jsp"/>
      </main>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.InscriptionDAO" %>
<%@ page import="com.gasaformation.model.Inscription" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<%
    // Vérification authentification
    String username = (request.getUserPrincipal() != null) ? request.getUserPrincipal().getName() : null;
    if (username == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp?error=auth");
        return;
    }

    List<Inscription> demandes = new ArrayList<>();
    try {
        InscriptionDAO dao = new InscriptionDAO();
        demandes = dao.findByUsername(username);
    } catch (Exception e) {
        e.printStackTrace();
        request.setAttribute("error", "Impossible de charger vos demandes pour le moment.");
    }

    request.setAttribute("demandes", demandes);
%>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Mes demandes d'inscription - GASA Formation</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<jsp:include page="/WEB-INF/includes/header.jsp"/>

<div class="container mt-4">
  <h2 class="mb-4">Mes demandes d'inscription</h2>

  <!-- Message succès après soumission -->
  <c:if test="${param.ok eq '1'}">
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      Votre demande d'inscription a été enregistrée avec succès et est en attente de validation.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
    </div>
  </c:if>

  <!-- Message d'erreur si problème -->
  <c:if test="${not empty error}">
    <div class="alert alert-danger">${error}</div>
  </c:if>

  <c:choose>
    <c:when test="${empty demandes}">
      <div class="alert alert-info">Aucune demande d'inscription enregistrée.</div>
    </c:when>
    <c:otherwise>
      <table class="table table-bordered table-hover">
        <thead class="table-light">
          <tr>
            <th>Date</th>
            <th>Filière</th>
            <th>Niveau</th>
            <th>Type</th>
            <th>Série BAC</th>
            <th>Diplôme</th>
            <th>Année</th>
            <th>Établissement</th>
            <th>Statut</th>
          </tr>
        </thead>
        <tbody>
          <c:forEach var="insc" items="${demandes}">
            <tr>
              <td><fmt:formatDate value="${insc.dateInscription}" pattern="dd/MM/yyyy"/></td>
              <td>${insc.filiere}</td>
              <td>${insc.niveau}</td>
              <td>${insc.type}</td>
              <td>${insc.serieBac}</td>
              <td>${insc.diplome}</td>
              <td>${insc.anneeObtention}</td>
              <td>${insc.etablissementOrigine}</td>
              <td>
                <c:choose>
                  <c:when test="${insc.statut eq 'validé'}">
                    <span class="badge bg-success">Validée</span>
                  </c:when>
                  <c:when test="${insc.statut eq 'rejete'}">
                    <span class="badge bg-danger">Rejetée</span>
                  </c:when>
                  <c:otherwise>
                    <span class="badge bg-warning text-dark">En attente</span>
                  </c:otherwise>
                </c:choose>
              </td>
            </tr>
          </c:forEach>
        </tbody>
      </table>
    </c:otherwise>
  </c:choose>
</div>

<jsp:include page="/WEB-INF/includes/footer.jsp"/>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

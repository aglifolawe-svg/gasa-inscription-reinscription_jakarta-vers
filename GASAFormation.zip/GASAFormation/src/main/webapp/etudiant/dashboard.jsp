<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.*" %>
<%@ page import="com.gasaformation.model.*" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<%
    String username = (request.getUserPrincipal() != null) ? request.getUserPrincipal().getName() : null;
    if (username == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp?error=auth");
        return;
    }

    UtilisateurDAO udao = new UtilisateurDAO();
    Utilisateur user = udao.findByUsername(username);
    String role = (user != null) ? user.getRole() : "candidat";
    String statut = (user != null) ? user.getStatut() : "en attente";

    List<Inscription> inscriptions = new ArrayList<>();
    List<Paiement> paiements = new ArrayList<>();
    List<Evenement> events = new ArrayList<>();

    try {
        InscriptionDAO idao = new InscriptionDAO();
        PaiementDAO pdao = new PaiementDAO();
        EvenementDAO edao = new EvenementDAO();

        inscriptions = idao.findByUsername(username);
        paiements = pdao.findByUsername(username);
        events = edao.findUpcoming();
    } catch (Exception e) {
        e.printStackTrace();
    }

    request.setAttribute("user", user);
    request.setAttribute("role", role);
    request.setAttribute("statut", statut);
    request.setAttribute("inscriptions", inscriptions);
    request.setAttribute("paiements", paiements);
    request.setAttribute("events", events);

    Calendar now = Calendar.getInstance();
    int hour = now.get(Calendar.HOUR_OF_DAY);
    String greeting;
    if (hour < 12) {
        greeting = "Bonjour";
    } else if (hour < 18) {
        greeting = "Bon après-midi";
    } else {
        greeting = "Bonsoir";
    }

    String currentDate = new java.text.SimpleDateFormat("dd/MM/yyyy").format(new java.util.Date());
    String currentTime = new java.text.SimpleDateFormat("HH:mm").format(new java.util.Date());

    request.setAttribute("greeting", greeting);
    request.setAttribute("currentDate", currentDate);
    request.setAttribute("currentTime", currentTime);

    int notifCount = 0;
    // notifCount = new NotificationDAO().countUnread(user.getId());
    request.setAttribute("notifCount", notifCount);
%>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Étudiant - GASA Formation</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

  <jsp:include page="/WEB-INF/includes/header.jsp"/>

  <div class="container-fluid">
    <div class="row">
      <jsp:include page="/WEB-INF/includes/menu.jsp"/>

      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

        <!-- Header avec avatar -->
        <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-3 border-bottom">
          <div>
            <h1 class="h4 mb-1">
              ${greeting}, <c:out value="${user.prenom}"/> <c:out value="${user.nom}"/>
            </h1>
            <small class="text-muted">Nous sommes le ${currentDate} — ${currentTime}</small>
          </div>
          <div class="d-flex align-items-center">
            <a href="${pageContext.request.contextPath}/etudiant/notifications.jsp" 
               class="btn btn-light position-relative me-3">
              <i class="bi bi-bell"></i> Notifications
              <c:if test="${notifCount > 0}">
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                  ${notifCount}
                </span>
              </c:if>
            </a>
            <img src="<c:out value='${user.photoUrl != null ? user.photoUrl : "https://via.placeholder.com/50"}'/>"
                 class="rounded-circle" alt="avatar" width="50" height="50">
          </div>
        </div>

        <!-- Bannière de bienvenue -->
        <div class="p-4 mb-4 text-white rounded" style="background-color:#6f42c1;">
          <h5>${currentDate}</h5>
          <h2>Bienvenue <c:out value="${user.username}"/> !</h2>
          <p>Restez informé et suivez vos démarches académiques en toute simplicité.</p>
        </div>

        <c:if test="${param.demande eq 'ok'}">
          <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
            Votre demande d'inscription a été enregistrée avec succès.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
          </div>
        </c:if>

        <c:choose>
          <c:when test="${role eq 'etudiant_de_gasa'}">

            <!-- Cartes infos -->
            <div class="row mb-4">
              <div class="col-md-4">
                <div class="card shadow-sm p-3">
                  <h6><i class="bi bi-person-badge me-2"></i> Nom complet</h6>
                  <p class="fw-bold"><c:out value="${user.prenom}"/> <c:out value="${user.nom}"/></p>
                </div>
              </div>
              <div class="col-md-4">
                <div class="card shadow-sm p-3">
                  <h6><i class="bi bi-mortarboard me-2"></i> Filière</h6>
                  <p class="fw-bold"><c:out value="${user.filiere}"/></p>
                </div>
              </div>
              <div class="col-md-4">
                <div class="card shadow-sm p-3">
                  <h6><i class="bi bi-check-circle me-2"></i> Statut</h6>
                  <p class="fw-bold"><span class="badge bg-success"><c:out value="${user.statut}"/></span></p>
                </div>
              </div>
            </div>

            <!-- Inscriptions -->
            <div class="card mb-4">
              <div class="card-header">Mes inscriptions</div>
              <div class="card-body">
                <c:choose>
                  <c:when test="${empty inscriptions}">
                    <div class="alert alert-info">Aucune inscription enregistrée.</div>
                  </c:when>
                  <c:otherwise>
                    <table class="table table-bordered table-hover">
                      <thead class="table-light">
                        <tr>
                          <th>Date</th>
                          <th>Filière</th>
                          <th>Niveau</th>
                          <th>Type</th>
                          <th>Série BAC</th>
                          <th>Diplôme</th>
                          <th>Année</th>
                          <th>Établissement</th>
                          <th>Statut</th>
                        </tr>
                      </thead>
                      <tbody>
                        <c:forEach var="insc" items="${inscriptions}">
                          <tr>
                            <td><fmt:formatDate value="${insc.dateInscription}" pattern="dd/MM/yyyy"/></td>
                            <td>${insc.filiere}</td>
                            <td>${insc.niveau}</td>
                            <td>${insc.type}</td>
                            <td>${insc.serieBac}</td>
                            <td>${insc.diplome}</td>
                            <td>${insc.anneeObtention}</td>
                            <td>${insc.etablissementOrigine}</td>
                            <td>
                              <c:choose>
                                <c:when test="${insc.statut eq 'validé'}"><span class="badge bg-success">Validée</span></c:when>
                                                               <c:when test="${insc.statut eq 'rejete'}">
                                  <span class="badge bg-danger">Rejetée</span>
                                </c:when>
                                <c:otherwise>
                                  <span class="badge bg-warning text-dark">En attente</span>
                                </c:otherwise>
                              </c:choose>
                            </td>
                          </tr>
                        </c:forEach>
                      </tbody>
                    </table>
                  </c:otherwise>
                </c:choose>
              </div>
            </div>

            <!-- Paiements -->
            <div class="card mb-4">
              <div class="card-header">Mes paiements</div>
              <div class="card-body">
                <jsp:include page="/WEB-INF/includes/paymentsTable.jsp"/>
              </div>
            </div>

            <!-- Événements -->
            <div class="card mb-4">
              <div class="card-header">Événements à venir</div>
              <div class="card-body">
                <jsp:include page="/WEB-INF/includes/events.jsp"/>
              </div>
            </div>

          </c:when>
          
            <c:otherwise>
            <div class="alert alert-warning">
              <h5>Veuillez soumettre votre demande d'inscription </h5>
              <p>Une fois votre demande validée, vous accéderez à votre tableau de bord complet.</p>
            </div>
          </c:otherwise>
          
        </c:choose>
            <!-- Cas candidat ou en attente -->
          

        <jsp:include page="/WEB-INF/includes/footer.jsp"/>
      </main>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

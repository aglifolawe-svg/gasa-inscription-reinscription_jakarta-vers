<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.*" %>
<%@ page import="com.gasaformation.model.*" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<%
  // 🔹 Récupère le nom d'utilisateur connecté via le système d'authentification
String username = (request.getUserPrincipal() != null) ? request.getUserPrincipal().getName() : null;

// 🔹 Si aucun utilisateur n'est connecté, on redirige vers la page de login
if (username == null) {
    response.sendRedirect(request.getContextPath() + "/login.jsp?error=auth");
    return;
}

  // 🔹 Initialise l'identifiant de l'inscription à 0
int id = 0;

// 🔹 Essaie de récupérer l'ID de l'inscription depuis l'URL (paramètre GET "id")
try {
    id = Integer.parseInt(request.getParameter("id"));
} catch(Exception e) {
    // 🔹 Si l'ID est invalide ou absent, on redirige vers la liste des inscriptions
    response.sendRedirect("mesInscriptions.jsp?error=id");
    return;
}


  // 🔹 Instancie les DAO (Data Access Objects) pour accéder aux données en base
InscriptionDAO insDao = new InscriptionDAO();               // Pour récupérer l'inscription
NoteBacRepository noteDao = new NoteBacRepository();        // Pour récupérer les notes du BAC
JustificatifRepository jusDao = new JustificatifRepository(); // Pour récupérer les pièces justificatives
AuditTrailRepository auditDao = new AuditTrailRepository(); // Pour récupérer l'historique d'audit

  // 🔹 Récupère l'inscription à partir de son ID
Inscription insc = insDao.findById(id);

  // 🔹 Récupère toutes les notes du BAC liées à cette inscription
// ✅ C'est ici que se fait la récupération des notes
List<NoteBac> notes = noteDao.findByInscriptionId(id);
//Cette méthode findByInscriptionId(id) fait une jointure avec la table matieres_principales
//pour ramener :
// - la note
// - le libellé de la matière (matierePrincipaleLibelle)
// - le coefficient (matierePrincipaleCoefficient)

  // 🔹 Récupère toutes les pièces justificatives liées à cette inscription
List<Justificatif> justificatifs = jusDao.findByInscription(id);

// 🔹 Calcul de la moyenne pondérée
  double totalPondere = 0; // Somme des notes pondérées
  double totalCoef = 0;    // Somme des coefficients

  for (NoteBac n : notes) {
    // On multiplie chaque note par son coefficient
    totalPondere += n.getNote() * n.getMatierePrincipaleCoefficient();
    totalCoef += n.getMatierePrincipaleCoefficient();
  }

  // 🔹 Si totalCoef > 0, on calcule la moyenne. Sinon, on laisse null.
  Double moyennePonderee = (totalCoef > 0) ? (totalPondere / totalCoef) : null;

  // 🔹 On rend la moyenne disponible dans la partie HTML via JSTL
  request.setAttribute("moyennePonderee", moyennePonderee);


  // 🔹 Récupère l'historique des actions (audit trail) liées à cette inscription
List<AuditTrail> audits = auditDao.findByEntity("Inscription", id);

  // 🔹 Rend les objets disponibles dans la partie HTML via JSTL

  request.setAttribute("insc", insc);          // L'inscription elle-même
  request.setAttribute("notes", notes);        // Les notes du BAC
  request.setAttribute("justificatifs", justificatifs);     // Les pièces justificatives
  request.setAttribute("audits", audits);      // L'historique des actions

%>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Détails de l'inscription</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<jsp:include page="/WEB-INF/includes/header.jsp"/>

<div class="container mt-4">
  <h2 class="mb-4">Détails de l'inscription</h2>

  <c:if test="${insc == null}">
    <div class="alert alert-danger">Inscription introuvable.</div>
  </c:if>

  <c:if test="${insc != null}">
    <!-- Infos générales -->
    <div class="card mb-3">
      <div class="card-header">Informations générales</div>
      <div class="card-body">
        <p><strong>Date :</strong> <fmt:formatDate value="${insc.dateInscription}" pattern="dd/MM/yyyy"/></p>
        <p><strong>Filière :</strong> ${insc.filiere}</p>
        <p><strong>Niveau :</strong> ${insc.niveau}</p>
        <p><strong>Série BAC :</strong> ${insc.serieBac}</p>
        <p><strong>Diplôme :</strong> ${insc.diplome}</p>
        <p><strong>Année d’obtention :</strong> ${insc.anneeObtention}</p>
        <p><strong>Établissement d’origine :</strong> ${insc.etablissementOrigine}</p>
        <p><strong>Statut :</strong>
          <c:choose>
            <c:when test="${insc.statut eq 'validé'}"><span class="badge bg-success">Validée</span></c:when>
            <c:when test="${insc.statut eq 'rejete'}"><span class="badge bg-danger">Rejetée</span></c:when>
            <c:otherwise><span class="badge bg-warning text-dark">En attente</span></c:otherwise>
          </c:choose>
        </p>
      </div>
    </div>

    <!-- Notes -->
    <div class="card mb-3">
      <div class="card-header">Notes du BAC</div>
      <div class="card-body">
        <c:choose>
          <c:when test="${empty notes}">
            <div class="alert alert-info">Aucune note enregistrée.</div>
          </c:when>
          <c:otherwise>
            <table class="table table-sm table-bordered">
              <thead>
                <tr>
                  <th>Matière</th>
                  <th>Note</th>
                </tr>
              </thead>
              <tbody>
                <c:forEach var="n" items="${notes}">
                  <tr>
                    <td>${n.matierePrincipaleLibelle}</td>
                    <td>${n.note}</td>
                  </tr>
                </c:forEach>
                  
                <!-- 🔹 Ligne de moyenne pondérée -->
                <tr class="table-secondary">
                    <td><strong>Moyenne pondérée</strong></td>
                    <td>
                     <c:choose>
                       <c:when test="${not empty moyennePonderee}">
                        <fmt:formatNumber value="${moyennePonderee}" maxFractionDigits="2"/>
                       </c:when>
                     <c:otherwise>–</c:otherwise>
                     </c:choose>
                    </td>
                </tr>
  
              </tbody>
            </table>
          </c:otherwise>
        </c:choose>
      </div>
    </div>

    <!-- Justificatifs -->
    <div class="card mb-3">
      <div class="card-header">Pièces justificatives</div>
      <div class="card-body">
        <c:choose>
          <c:when test="${empty justificatifs}">
            <div class="alert alert-info">Aucun justificatif fourni.</div>
          </c:when>
          <c:otherwise>
            <ul class="list-group">
              <c:forEach var="j" items="${justificatifs}">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                  ${j.type} - ${j.filename}
                  <span class="badge bg-secondary">${j.statut}</span>
                </li>
              </c:forEach>
            </ul>
          </c:otherwise>
        </c:choose>
      </div>
    </div>

    <!-- Audit -->
    <div class="card mb-3">
      <div class="card-header">Historique des actions</div>
      <div class="card-body">
        <c:choose>
          <c:when test="${empty audits}">
            <div class="alert alert-info">Aucun historique disponible.</div>
          </c:when>
          <c:otherwise>
            <table class="table table-sm table-striped">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Action</th>
                  <th>Utilisateur</th>
                  <th>Commentaire</th>
                </tr>
              </thead>
              <tbody>
                <c:forEach var="a" items="${audits}">
                  <tr>
                    <td><fmt:formatDate value="${a.dateAction}" pattern="dd/MM/yyyy HH:mm"/></td>
                    <td>${a.action}</td>
                    <td>${a.userId}</td>
                    <td>${a.commentaire}</td>
                  </tr>
                </c:forEach>
              </tbody>
            </table>
          </c:otherwise>
        </c:choose>
      </div>
    </div>
  </c:if>
</div>

<jsp:include page="/WEB-INF/includes/footer.jsp"/>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

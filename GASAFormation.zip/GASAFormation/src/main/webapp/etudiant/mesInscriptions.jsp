<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.InscriptionDAO" %>
<%@ page import="com.gasaformation.model.Inscription" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<%
  String username = (request.getUserPrincipal() != null) ? request.getUserPrincipal().getName() : null;
  if (username == null) {
      response.sendRedirect(request.getContextPath() + "/login.jsp?error=auth");
      return;
  }

  List<Inscription> inscriptions = new ArrayList<>();
  try {
      InscriptionDAO idao = new InscriptionDAO();
      inscriptions = idao.findByUsername(username);
  } catch (Exception e) {
      e.printStackTrace();
      request.setAttribute("error", "Impossible de charger vos inscriptions pour le moment.");
  }
  request.setAttribute("inscriptions", inscriptions);
%>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Mes inscriptions - Étudiant</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<jsp:include page="/WEB-INF/includes/header.jspf"/>

<div class="container mt-4">
  <h2 class="mb-3">Mes inscriptions</h2>

  <!-- Message succès -->
  <c:if test="${param.ok eq '1'}">
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      Votre inscription a été enregistrée avec succès.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
    </div>
  </c:if>

  <!-- Message erreur -->
  <c:if test="${not empty error}">
    <div class="alert alert-danger">${error}</div>
  </c:if>

  <c:choose>
    <c:when test="${empty inscriptions}">
      <div class="alert alert-info">Aucune inscription enregistrée.</div>
    </c:when>
    <c:otherwise>
      <table class="table table-bordered table-hover">
        <thead class="table-light">
          <tr>
            <th>Date</th>
            <th>Filière</th>
            <th>Niveau</th>
            <th>Type</th>
            <th>Série BAC</th>
            <th>Diplôme</th>
            <th>Année</th>
            <th>Établissement</th>
            <th>Statut</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <c:forEach var="insc" items="${inscriptions}">
            <tr>
              <td><fmt:formatDate value="${insc.dateInscription}" pattern="dd/MM/yyyy"/></td>
              <td>${insc.filiere}</td>
              <td>${insc.niveau}</td>
              <td>${insc.type}</td>
              <td>${insc.serieBac}</td>
              <td>${insc.diplome}</td>
              <td>${insc.anneeObtention}</td>
              <td>${insc.etablissementOrigine}</td>
              <td>
                <c:choose>
                  <c:when test="${insc.statut eq 'validé'}"><span class="badge bg-success">Validée</span></c:when>
                  <c:when test="${insc.statut eq 'rejete'}"><span class="badge bg-danger">Rejetée</span></c:when>
                  <c:otherwise><span class="badge bg-warning text-dark">En attente</span></c:otherwise>
                </c:choose>
              </td>
              <td>
                <a href="detailsInscription.jsp?id=${insc.id}" class="btn btn-sm btn-info">
                  <i class="bi bi-eye"></i> Voir
                </a>
              </td>
            </tr>
          </c:forEach>
        </tbody>
      </table>
    </c:otherwise>
  </c:choose>
</div>

<jsp:include page="/WEB-INF/includes/footer.jspf"/>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

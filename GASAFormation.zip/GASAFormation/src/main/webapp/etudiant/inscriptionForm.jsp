<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.*" %>
<%@ page import="com.gasaformation.model.*" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>
<%!
  // Déclaration helper pour échapper des chaînes pour un littéral JS
  private String jsEscape(String in) {
    if (in == null) return "";
    return in.replace("\\", "\\\\")
             .replace("\"", "\\\"")
             .replace("\r", " ")
             .replace("\n", " ");
  }
%>
<%
  // Vérification rôle étudiant
  UtilisateurDAO udao = new UtilisateurDAO();
  Utilisateur currentUser = null;
  if (request.getUserPrincipal() != null) {
    currentUser = udao.findByUsername(request.getUserPrincipal().getName());
  }
  if (currentUser == null
      || !( "etudiant".equalsIgnoreCase(currentUser.getRole())
         || "etudiant_de_gasa".equalsIgnoreCase(currentUser.getRole()) )) {
    response.sendRedirect("../login.jsp?error=forbidden");
    return;
  }

  BacSerieRepository bRepo = new BacSerieRepository();
  FiliereDAO fdao = new FiliereDAO();

  // Charger séries depuis DB et leurs matières
  List<BacSerie> series = bRepo.findAll();
  Map<String, List<MatierePrincipale>> serieMatieres = new LinkedHashMap<>();
  for (BacSerie s : series) {
    List<MatierePrincipale> mats = bRepo.findMatieresBySerieId(s.getId());
    serieMatieres.put(s.getCode(), mats != null ? mats : Collections.emptyList());
  }

  Map<String, List<Filiere>> filieresGrouped = fdao.findGroupedByUfr();
  request.setAttribute("serieMatieres", serieMatieres);
  request.setAttribute("filieresGrouped", filieresGrouped);
%>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Demande d’inscription</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>.required::after {content:" *"; color:#d9534f;}</style>
</head>
<body class="bg-light">
<div class="container py-4">
  <h2 class="mb-4">Formulaire d’inscription</h2>

  <form action="submitInscription.jsp" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
    <!-- Informations personnelles -->
    <div class="card mb-3">
      <div class="card-header">Informations personnelles</div>
      <div class="card-body row g-3">
        <div class="col-md-6"><label class="form-label required">Nom</label><input name="nom" class="form-control" required></div>
        <div class="col-md-6"><label class="form-label required">Prénom</label><input name="prenom" class="form-control" required></div>
        <div class="col-md-3">
          <label class="form-label required">Sexe</label>
          <select name="sexe" class="form-select" required>
            <option value="">Choisir...</option><option>M</option><option>F</option>
          </select>
        </div>
        <div class="col-md-3"><label class="form-label required">Date de naissance</label><input type="date" name="dateNaissance" class="form-control" required></div>
        <div class="col-md-3"><label class="form-label required">Email</label><input type="email" name="email" class="form-control" required></div>
        <div class="col-md-3"><label class="form-label required">Téléphone</label><input name="telephone" class="form-control" required></div>
        <div class="col-md-12"><label class="form-label required">Adresse</label><input name="adresse" class="form-control" required></div>
      </div>
    </div>

    <!-- Informations académiques -->
    <div class="card mb-3">
      <div class="card-header">Informations académiques</div>
      <div class="card-body row g-3">
        <div class="col-md-4">
          <label class="form-label required">Niveau visé</label>
          <select name="niveau" id="niveau" class="form-select" required>
            <option value="">Choisir...</option>
            <option>L1</option><option>L2</option><option>L3</option><option>M1</option><option>M2</option>
          </select>
        </div>

        <div class="col-md-4">
          <label class="form-label required">Filière demandée</label>
          <select name="filiere" class="form-select" required>
            <option value="">Choisir...</option>
            <c:forEach var="entry" items="${filieresGrouped}">
              <optgroup label="${fn:escapeXml(entry.key)}">
                <c:forEach var="f" items="${entry.value}">
                  <option value="${f.id}">${fn:escapeXml(f.nom)}</option>
                </c:forEach>
              </optgroup>
            </c:forEach>
          </select>
        </div>

        <div class="col-md-4">
          <label class="form-label required">Série du BAC</label>
          <select name="serieBac" id="serieBac" class="form-select" required>
            <option value="">Choisir...</option>
            <c:forEach var="code" items="${serieMatieres.keySet()}">
              <option value="${fn:escapeXml(code)}">${fn:escapeXml(code)}</option>
            </c:forEach>
          </select>
        </div>

        <div class="col-md-4"><label class="form-label required">Année d’obtention BAC</label><input type="number" name="anneeObtention" class="form-control" min="1990" max="2090" required></div>
        <div class="col-md-4"><label class="form-label">Moyenne BAC (si connue)</label><input type="number" name="moyenneBac" class="form-control" step="0.01" min="0" max="20"></div>
        <div class="col-md-4"><label class="form-label">Établissement d’origine</label><input name="etablissementOrigine" class="form-control"></div>
      </div>
    </div>

    <!-- Notes par matière principale -->
<div class="card mb-3">
  <div class="card-header">Notes du BAC (matières principales)</div>
  <div class="card-body">
    <div id="notesContainer" class="row g-3"></div>
    <div id="moyenneContainer" class="mt-3 fw-bold"></div>
  </div>
</div>


    <!-- Pièces justificatives -->
    <div class="card mb-3">
      <div class="card-header">Pièces justificatives</div>
      <div class="card-body row g-3">
        <div class="col-md-6"><label class="form-label required">Photo d’identité (JPG/PNG)</label><input type="file" name="PHOTO" accept="image/jpeg,image/png" class="form-control" required></div>
        <div class="col-md-6"><label class="form-label required">Acte de naissance (PDF)</label><input type="file" name="ACTE_NAISSANCE" accept="application/pdf" class="form-control" required></div>
        <div class="col-md-6"><label class="form-label required">Attestation du BAC (PDF/JPG)</label><input type="file" name="ATTESTATION_BAC" accept="application/pdf,image/jpeg" class="form-control" required></div>
        <div class="col-md-6"><label class="form-label required">Relevé de notes du BAC (PDF)</label><input type="file" name="RELEVE_BAC" accept="application/pdf" class="form-control" required></div>
        <div class="col-12" id="semestresBlock" style="display:none;">
          <label class="form-label">Relevés post-BAC (PDF, multiples)</label>
          <input type="file" name="RELEVE_SEMESTRE" accept="application/pdf" class="form-control" multiple>
        </div>
      </div>
    </div>

    <!-- Consentement -->
    <div class="form-check mb-3">
      <input class="form-check-input" type="checkbox" value="1" id="consent" name="consent" required>
      <label class="form-check-label required" for="consent">
          J’atteste l’exactitude des informations fournies et j’accepte les conditions.
      </label>
    </div>

    <button class="btn btn-primary" type="submit">Soumettre la demande</button>
  </form>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
  const notesContainer = document.getElementById('notesContainer');
  const serieSelect = document.getElementById('serieBac');
  const niveauSelect = document.getElementById('niveau');
  const semestresBlock = document.getElementById('semestresBlock');
  const moyenneContainer = document.getElementById('moyenneContainer');

  // 1. Construire serieMatieres depuis le serveur
  const serieMatieres = {};
  <% 
    Map<String, List<MatierePrincipale>> sm = (Map<String, List<MatierePrincipale>>) request.getAttribute("serieMatieres");
    if (sm != null) {
      for (Iterator<Map.Entry<String, List<MatierePrincipale>>> it = sm.entrySet().iterator(); it.hasNext();) {
        Map.Entry<String, List<MatierePrincipale>> entry = it.next();
        String code = entry.getKey();
        List<MatierePrincipale> mats = entry.getValue();
        String escCode = jsEscape(code);
  %>
    serieMatieres["<%= escCode %>"] = [
      <% if (mats != null && !mats.isEmpty()) {
           for (int i=0; i<mats.size(); i++) {
             MatierePrincipale m = mats.get(i);
             String escLib = jsEscape(m.getLibelle());
      %>
        { id: <%= m.getId() %>, libelle: "<%= escLib %>", coef: <%= m.getCoef() %> }<%= (i < mats.size()-1) ? "," : "" %>
      <%   }
         } %>
    ]<%= it.hasNext() ? "," : "" %>
  <%  }
    }
  %>;

  console.log("DEBUG serieMatieres =", serieMatieres);

  // 2. Fonction pour afficher les notes
  function renderNotesForSerie(code) {
    notesContainer.innerHTML = '';
    moyenneContainer.innerHTML = '';

    if (!code || !serieMatieres[code] || serieMatieres[code].length === 0) {
      notesContainer.innerHTML =
        '<div class="alert alert-warning">Aucune matière configurée pour cette série.</div>';
      return;
    }

    const mats = serieMatieres[code];
    console.log("DEBUG renderNotesForSerie avec", code, mats);

    mats.forEach(function(m) {
      const col = document.createElement('div');
      col.className = 'col-md-4';

      col.innerHTML =
        '<label class="form-label required">' + m.libelle + ' (coef ' + m.coef + ')</label>' +
        '<input type="number" name="NOTE_' + m.id + '" ' +
        'class="form-control note-input" step="0.01" min="0" max="20" required ' +
        'data-coef="' + m.coef + '">';

      notesContainer.appendChild(col);
    });

    // Attacher les listeners pour recalculer la moyenne
    const inputs = notesContainer.querySelectorAll('.note-input');
    inputs.forEach(input => {
      input.addEventListener('input', calculerMoyenne);
    });
  }

  // 3. Fonction de calcul de la moyenne pondérée
  function calculerMoyenne() {
    const inputs = document.querySelectorAll('.note-input');
    let somme = 0;
    let totalCoef = 0;

    inputs.forEach(input => {
      const val = parseFloat(input.value);
      const coef = parseFloat(input.dataset.coef);
      if (!isNaN(val)) {
        somme += val * coef;
        totalCoef += coef;
      }
    });

    if (totalCoef > 0) {
      const moyenne = (somme / totalCoef).toFixed(2);

      // Couleur dynamique
      let color = "black";
      if (moyenne < 10) {
        color = "red";
      } else if (moyenne >= 10 && moyenne < 14) {
        color = "orange";
      } else {
        color = "green";
      }

      moyenneContainer.textContent = "Moyenne pondérée : " + moyenne + "/20";
      moyenneContainer.style.color = color;
    } else {
      moyenneContainer.textContent = "";
      moyenneContainer.style.color = "black";
    }
  }

  // 4. Listeners
  serieSelect.addEventListener('change', (e) => renderNotesForSerie(e.target.value));
  niveauSelect.addEventListener('change', (e) => {
    semestresBlock.style.display = (e.target.value && e.target.value !== 'L1') ? 'block' : 'none';
  });

  // 5. Si une série est déjà sélectionnée
  if (serieSelect.value) {
    renderNotesForSerie(serieSelect.value);
  }

  // 6. Bootstrap validation
  (function () {
    'use strict';
    const forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) { 
          event.preventDefault(); 
          event.stopPropagation(); 
        }
        form.classList.add('was-validated');
      }, false);
    });
  })();
});
</script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

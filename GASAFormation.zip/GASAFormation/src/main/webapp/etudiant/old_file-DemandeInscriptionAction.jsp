<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.*" %>
<%@ page import="com.gasaformation.model.*" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<%
  request.setCharacterEncoding("UTF-8");
  String username = (request.getUserPrincipal() != null) ? request.getUserPrincipal().getName() : null;
  if (username == null) {
      response.sendRedirect(request.getContextPath() + "/login.jsp?error=auth");
      return;
  }

  // Affichage du formulaire
  if ("1".equals(request.getParameter("form"))) {
      FiliereDAO fdao = new FiliereDAO();
      Map<String, List<com.gasaformation.model.Filiere>> filieresGrouped = fdao.findGroupedByUfr();
      request.setAttribute("filieresGrouped", filieresGrouped);
%>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Nouvelle demande d'inscription</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <jsp:include page="/WEB-INF/includes/header.jsp"/>
  <div class="container mt-4">
    <div class="row justify-content-center">
      <div class="col-md-8">
        <div class="card shadow-sm">
          <div class="card-header bg-primary text-white">
            <h4 class="mb-0">Demande d'inscription</h4>
          </div>
          <div class="card-body">
            <form action="DemandeInscriptionAction.jsp" method="post">
              <div class="mb-3">
                <label for="filiere" class="form-label">Filière</label>
                <jsp:include page="/WEB-INF/includes/filiereOptions.jsp"/>
              </div>
              <div class="mb-3">
                <label for="niveau" class="form-label">Niveau</label>
                <input type="text" id="niveau" name="niveau" class="form-control" required placeholder="Licence 1, Licence 2, Master 1...">
              </div>
              <div class="mb-3">
                <label for="serieBac" class="form-label">Série du BAC</label>
                <input type="text" id="serieBac" name="serieBac" class="form-control" required>
              </div>
              <div class="mb-3">
                <label for="diplome" class="form-label">Diplôme</label>
                <input type="text" id="diplome" name="diplome" class="form-control" required>
              </div>
              <div class="mb-3">
                <label for="anneeObtention" class="form-label">Année d'obtention</label>
                <input type="number" id="anneeObtention" name="anneeObtention" class="form-control" required>
              </div>
              <div class="mb-3">
                <label for="etablissementOrigine" class="form-label">Établissement d'origine</label>
                <input type="text" id="etablissementOrigine" name="etablissementOrigine" class="form-control" required>
              </div>
              <input type="hidden" name="type" value="inscription">
              <div class="text-end">
                <button type="submit" class="btn btn-primary">Soumettre la demande</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <jsp:include page="/WEB-INF/includes/footer.jsp"/>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<%
      return;
  }

  // Traitement du POST
  String filiere = request.getParameter("filiere");
  String niveau  = request.getParameter("niveau");
  String type    = request.getParameter("type");
  String serieBac = request.getParameter("serieBac");
  String diplome = request.getParameter("diplome");
  String anneeStr = request.getParameter("anneeObtention");
  String etablissementOrigine = request.getParameter("etablissementOrigine");

  if (filiere == null || niveau == null || type == null || serieBac == null || diplome == null || anneeStr == null) {
      response.sendRedirect("dashboard.jsp?demande=ko");
      return;
  }

  UtilisateurDAO udao = new UtilisateurDAO();
  Integer etuId = udao.getIdByUsername(username);
  if (etuId == null) {
      response.sendRedirect("dashboard.jsp?demande=ko");
      return;
  }

  Inscription insc = new Inscription();
  insc.setEtudiantId(etuId);
  insc.setFiliere(filiere);
  insc.setNiveau(niveau);
  insc.setType(type);
  insc.setStatut("en attente");
  insc.setSerieBac(serieBac);
  insc.setDiplome(diplome);
  insc.setAnneeObtention(Integer.parseInt(anneeStr));
  insc.setEtablissementOrigine(etablissementOrigine);

  try {
      InscriptionDAO idao = new InscriptionDAO();
      idao.insert(insc);
      response.sendRedirect("dashboard.jsp?demande=ok");
  } catch (Exception e) {
      e.printStackTrace();
      response.sendRedirect("dashboard.jsp?demande=ko");
  }
%>

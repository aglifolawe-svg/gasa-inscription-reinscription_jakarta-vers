<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<%@ page import="java.util.*,java.text.SimpleDateFormat,java.nio.charset.StandardCharsets,jakarta.servlet.http.Part" %>

<%@ page import="com.gasaformation.dao.*,com.gasaformation.model.*" %>

<%!
    // === Déclarations de méthodes utilitaires (au niveau classe JSP) ===
    String readPartString(Part p) throws java.io.IOException {
        if (p == null) return null;
        byte[] bytes = p.getInputStream().readAllBytes();
        if (bytes.length == 0) return null;
        return new String(bytes, StandardCharsets.UTF_8).trim();
    }

    String getText(jakarta.servlet.http.HttpServletRequest req, String name)
            throws java.io.IOException, jakarta.servlet.ServletException {
        return readPartString(req.getPart(name));
    }

    Integer getInt(jakarta.servlet.http.HttpServletRequest req, String name)
            throws java.io.IOException, jakarta.servlet.ServletException {
        String s = getText(req, name);
        if (s == null || s.isEmpty()) return null;
        try { return Integer.valueOf(s); } catch(Exception e) { return null; }
    }

    Double getDouble(jakarta.servlet.http.HttpServletRequest req, String name)
            throws java.io.IOException, jakarta.servlet.ServletException {
        String s = getText(req, name);
        if (s == null || s.isEmpty()) return null;
        try { return Double.valueOf(s); } catch(Exception e) { return null; }
    }
%>

<%
    System.out.println("=== DEBUG multipart ===");
  for (jakarta.servlet.http.Part p : request.getParts()) {
    String txt = "";
    if (p.getContentType() == null || p.getContentType().isBlank()) {
      byte[] b = p.getInputStream().readAllBytes();
      txt = new String(b, java.nio.charset.StandardCharsets.UTF_8).trim();
    }
    System.out.println("Part: " + p.getName()
      + " | size=" + p.getSize()
      + " | type=" + p.getContentType()
      + (txt.isEmpty() ? "" : " | value=" + txt));
  }
  System.out.println("====================");
  request.setCharacterEncoding("UTF-8");

  try {
    // 0. Gate: only students
    UtilisateurDAO udao = new UtilisateurDAO();
    Utilisateur currentUser = null;
    if (request.getUserPrincipal() != null) {
      currentUser = udao.findByUsername(request.getUserPrincipal().getName());
    }
    if (currentUser == null ||
        !( "etudiant".equalsIgnoreCase(currentUser.getRole())
        || "etudiant_de_gasa".equalsIgnoreCase(currentUser.getRole()) )) {
      response.sendRedirect("../login.jsp?error=forbidden");
      return;
    }

    // 1. Consentement
    String consent = getText(request, "consent");
    if (consent == null || consent.isEmpty()) {
      response.sendRedirect("inscriptionForm.jsp?error=consent");
      return;
    }

    // 2. Champs texte
    String nom = getText(request, "nom");
    String prenom = getText(request, "prenom");
    String sexe = getText(request, "sexe");
    String dateNaissanceStr = getText(request, "dateNaissance");
    String email = getText(request, "email");
    String telephone = getText(request, "telephone");
    String adresse = getText(request, "adresse");

    String niveau = getText(request, "niveau");
    String serieBac = getText(request, "serieBac");

    Integer anneeObtention = getInt(request, "anneeObtention");
    if (anneeObtention == null) {
      response.sendRedirect("inscriptionForm.jsp?error=anneeObtention");
      return;
    }

    String etablissementOrigine = getText(request, "etablissementOrigine");
    Double moyenneBac = getDouble(request, "moyenneBac");

    // 3. Création étudiant
    EtudiantRepository etRepo = new EtudiantRepository();
    Etudiant et = new Etudiant();
    et.setNom(nom);
    et.setPrenom(prenom);
    et.setSexe(sexe);

    Date dateNaissanceParsed = null;
    try {
      if (dateNaissanceStr != null && !dateNaissanceStr.isEmpty()) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        dateNaissanceParsed = sdf.parse(dateNaissanceStr);
      }
    } catch(Exception ex) {
      response.sendRedirect("inscriptionForm.jsp?error=dateNaissance");
      return;
    }
    et.setDateNaissance(dateNaissanceParsed);

    et.setEmail(email);
    et.setTelephone(telephone);
    et.setAdresse(adresse);
    et.setUtilisateurId(currentUser.getId());

    etRepo.insert(et);

    // 4. Filière
    Integer filiereId = getInt(request, "filiere");
    if (filiereId == null) {
      response.sendRedirect("inscriptionForm.jsp?error=filiere");
      return;
    }
    FiliereDAO fdao = new FiliereDAO();
    Filiere filiere = fdao.findById(filiereId);
    if (filiere == null) {
      response.sendRedirect("inscriptionForm.jsp?error=filiere");
      return;
    }

    // 5. Inscription
    InscriptionDAO insDao = new InscriptionDAO();
    Inscription ins = new Inscription();
    ins.setEtudiantId(et.getId());
    ins.setFiliereId(filiere.getId());
    ins.setNiveau(niveau);
    ins.setType("inscription");
    ins.setStatut("en attente");
    ins.setSerieBac(serieBac);
    ins.setDiplome("BAC");
    ins.setAnneeObtention(anneeObtention);
    ins.setEtablissementOrigine(etablissementOrigine);
    ins.setMoyenneBac(moyenneBac);
    insDao.insert(ins);
    int inscriptionId = ins.getId();

    // 6. Notes
    NoteBacRepository noteRepo = new NoteBacRepository();
    for (Part part : request.getParts()) {
      String pname = part.getName();
      if (pname != null && pname.startsWith("NOTE_")) {
        try {
          int matiereId = Integer.parseInt(pname.substring("NOTE_".length()));
          String val = readPartString(part);
          if (val != null && !val.isEmpty()) {
            double note = Double.parseDouble(val);
            NoteBac nb = new NoteBac();
            nb.setInscriptionId(inscriptionId);
            nb.setMatierePrincipaleId(matiereId);
            nb.setNote(note);
            noteRepo.insert(nb);
          }
        } catch(Exception ignore) {}
      }
    }

    Double moyenneCalc = noteRepo.calculateMoyennePonderee(inscriptionId);
    if (moyenneCalc != null) {
      insDao.updateMoyenneBac(inscriptionId, moyenneCalc);
      ins.setMoyenneBac(moyenneCalc);
    } else if (moyenneBac != null) {
      insDao.updateMoyenneBac(inscriptionId, moyenneBac);
    }

    // 7. Justificatifs (placeholders)
    JustificatifRepository jRepo = new JustificatifRepository();
    String[] requiredDocs = {"PHOTO","ACTE_NAISSANCE","ATTESTATION_BAC","RELEVE_BAC"};
    for (String type : requiredDocs) {
      Part docPart = request.getPart(type);
      Justificatif j = new Justificatif();
      j.setInscriptionId(inscriptionId);
      j.setType(type);
      j.setFilename(type + ".uploaded");
      j.setPath("/uploads/" + inscriptionId + "/" + j.getFilename());
      j.setMimeType("application/octet-stream");
      jRepo.insert(j);
    }
    if (!"L1".equalsIgnoreCase(niveau)) {
      Part relPart = request.getPart("RELEVE_SEMESTRE");
      Justificatif j = new Justificatif();
      j.setInscriptionId(inscriptionId);
      j.setType("RELEVE_SEMESTRE");
      j.setFilename("RELEVE_SEMESTRE.uploaded");
      j.setPath("/uploads/" + inscriptionId + "/" + j.getFilename());
      j.setMimeType("application/octet-stream");
      jRepo.insert(j);
    }

    // 8. Audit
    AuditTrailRepository audit = new AuditTrailRepository();
    AuditTrail a = new AuditTrail();
    a.setEntity("Inscription");
    a.setEntityId(inscriptionId);
    a.setAction("CREATE");
    a.setUserId(currentUser.getId());
    a.setCommentaire("Création de la demande d'inscription");
    audit.insert(a);

    // 9. Prévalidation
    com.gasaformation.service.PrevalidationService pre = new com.gasaformation.service.PrevalidationService();
    pre.prevalidate(inscriptionId);

    // 10. Succès
    response.sendRedirect("mesDemandes.jsp?ok=1");

  } catch (Exception e) {
    java.util.logging.Logger.getLogger("submitInscription")
      .log(java.util.logging.Level.SEVERE, "Erreur soumission", e);
    response.sendRedirect("inscriptionForm.jsp?error=server");
  }
%>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.gasaformation.dao.PaiementDAO" %>
<%@ page import="com.gasaformation.model.Paiement" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<%
  String username = (request.getUserPrincipal() != null) ? request.getUserPrincipal().getName() : null;
  if (username == null) {
      response.sendRedirect(request.getContextPath() + "/login.jsp?error=auth");
      return;
  }

  List<Paiement> paiements = new ArrayList<>();
  try {
      PaiementDAO pdao = new PaiementDAO();
      paiements = pdao.findByUsername(username);
  } catch (Exception e) {
      e.printStackTrace();
      request.setAttribute("error", "Impossible de charger vos paiements pour le moment.");
  }
  request.setAttribute("paiements", paiements);
%>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Mes paiements - Étudiant</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

  <jsp:include page="/WEB-INF/includes/header.jsp"/>

  <div class="container mt-4">
    <h2 class="mb-3">Mes paiements</h2>

    <!-- Message succès -->
    <c:if test="${param.ok eq '1'}">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        Votre paiement a été enregistré avec succès.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
      </div>
    </c:if>

    <!-- Message erreur -->
    <c:if test="${not empty error}">
      <div class="alert alert-danger">${error}</div>
    </c:if>

    <c:choose>
      <c:when test="${empty paiements}">
        <div class="alert alert-info">Aucun paiement enregistré.</div>
      </c:when>
      <c:otherwise>
        <table class="table table-bordered table-hover">
          <thead class="table-light">
            <tr>
              <th>Date</th>
              <th>Montant</th>
              <th>Méthode</th>
              <th>Référence</th>
              <th>Statut</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <c:forEach var="p" items="${paiements}">
              <tr>
                <td><fmt:formatDate value="${p.datePaiement}" pattern="dd/MM/yyyy"/></td>
                <td>${p.montant} FCFA</td>
                <td>${p.methode}</td>
                <td>${p.reference}</td>
                <td>
                  <c:choose>
                    <c:when test="${p.statut eq 'validé'}"><span class="badge bg-success">Validé</span></c:when>
                    <c:when test="${p.statut eq 'rejete'}"><span class="badge bg-danger">Rejeté</span></c:when>
                    <c:otherwise><span class="badge bg-warning text-dark">En attente</span></c:otherwise>
                  </c:choose>
                </td>
                <td>
                  <a href="recuPaiement.jsp?id=${p.id}" class="btn btn-sm btn-info">
                    <i class="bi bi-receipt"></i> Reçu
                  </a>
                </td>
              </tr>
            </c:forEach>
          </tbody>
        </table>
      </c:otherwise>
    </c:choose>
  </div>

  <jsp:include page="/WEB-INF/includes/footer.jsp"/>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

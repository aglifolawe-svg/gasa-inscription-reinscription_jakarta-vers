# convert-to-utf8.ps1
# Script pour convertir tous les fichiers JSP/JSPF/HTML/CSS en UTF-8

$extensions = "*.jsp","*.jspf","*.html","*.css"

Get-ChildItem -Recurse -Include $extensions | ForEach-Object {
    Write-Host "Conversion de $($_.FullName)..."
    $tmp = "$($_.FullName).tmp"
    Get-Content -Raw $_.FullName | Out-File -FilePath $tmp -Encoding utf8
    Move-Item -Force $tmp $_.FullName
}
Write-Host "✅ Conversion terminée. Tous les fichiers sont maintenant en UTF-8."

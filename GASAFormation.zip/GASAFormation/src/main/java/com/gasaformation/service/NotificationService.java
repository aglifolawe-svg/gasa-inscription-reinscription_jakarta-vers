package com.gasaformation.service;

import com.gasaformation.dao.NotificationDAO;
import com.gasaformation.model.Notification;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Service centralisé pour l’envoi de notifications.
 */
public class NotificationService {
    private static final Logger LOGGER = Logger.getLogger(NotificationService.class.getName());
    private final NotificationDAO dao;

    /**
     * Initialise le service avec le DAO.
     * Le constructeur propage l’exception pour éviter les faux multi-catch
     * et rester fidèle à la signature du DAO (throws Exception).
     *
     * @throws Exception si l’initialisation du DAO échoue
     */
    public NotificationService() throws Exception {
        this.dao = new NotificationDAO();
    }

    /**
     * Envoi d’une notification à un utilisateur.
     *
     * @param userId identifiant utilisateur
     * @param titre titre de la notification
     * @param message contenu du message
     * @param type type (INFO, WARNING, SUCCESS, ERROR, SYSTEM)
     * @param lien lien de redirection (ex: etudiant/mesDemandes.jsp)
     */
    public void send(int userId, String titre, String message, String type, String lien) {
        try {
            Notification n = new Notification();
            n.setUserId(userId);
            n.setTitre(titre);
            n.setMessage(message);
            n.setType(type);
            n.setLien(lien);
            dao.insert(n);
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur SQL lors de l’envoi de notification userId={0}", new Object[]{userId});
            LOGGER.log(Level.SEVERE, "Détail de l’erreur", e);
        }
    }
}

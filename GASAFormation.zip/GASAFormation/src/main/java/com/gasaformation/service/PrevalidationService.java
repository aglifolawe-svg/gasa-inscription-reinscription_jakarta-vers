package com.gasaformation.service;

import com.gasaformation.dao.*;
import com.gasaformation.model.*;

import java.util.logging.Level;
import java.util.logging.Logger;

public class PrevalidationService {
    private static final Logger LOGGER = Logger.getLogger(PrevalidationService.class.getName());

    private final FiliereDAO filiereDAO;
    private final JustificatifRepository justificatifRepo;
    private final NoteBacRepository noteRepo;
    private final AuditTrailRepository auditRepo;
    private final InscriptionDAO inscriptionDAO;
    private final BacSerieRepository bacRepo;
    private final NotificationService notificationService;

    public PrevalidationService() {
        try {
            this.filiereDAO = new FiliereDAO();
            this.justificatifRepo = new JustificatifRepository();
            this.noteRepo = new NoteBacRepository();
            this.auditRepo = new AuditTrailRepository();
            this.inscriptionDAO = new InscriptionDAO();
            this.bacRepo = new BacSerieRepository();
            this.notificationService = new NotificationService();
        } catch (Exception e) {
            throw new RuntimeException("Impossible d’initialiser PrevalidationService", e);
        }
    }

    public boolean prevalidate(int inscriptionId) {
        try {
            // Récupération inscription (avec filiere_nom si possible)
            Inscription ins = inscriptionDAO.findByIdWithFiliere(inscriptionId);
            if (ins == null) ins = inscriptionDAO.findById(inscriptionId);
            if (ins == null) {
                LOGGER.log(Level.WARNING, "Inscription introuvable id={0}", inscriptionId);
                return false;
            }

            // Résolution filière : priorise filiereId (nullable Integer) -> findById
            Filiere filiere = null;
            Integer fid = ins.getFiliereId(); // Inscription.getFiliereId() returns Integer (nullable)
            if (fid != null && fid > 0) {
                filiere = filiereDAO.findById(fid);
            }
            // Fallback : si aucune id trouvée, tenter par nom fourni par findByIdWithFiliere
            if (filiere == null && ins.getFiliereNom() != null && !ins.getFiliereNom().trim().isEmpty()) {
                filiere = filiereDAO.findByName(ins.getFiliereNom());
            }
            if (filiere == null) {
                return fail(ins, "Filière inconnue ou introuvable.");
            }

            // Compatibilité série ↔ filière
            String serieBac = ins.getSerieBac();
            if (!filiereDAO.isSerieCompatible(filiere.getId(), serieBac)) {
                return fail(ins, "Série du BAC non compatible avec la filière.");
            }

            // Vérification pièces justificatives
            if (!justificatifRepo.hasRequiredForLevel(inscriptionId, ins.getNiveau())) {
                return fail(ins, "Pièces justificatives manquantes.");
            }

            // Calcul moyenne pondérée via repository et écriture en base
            Double moyenne = noteRepo.calculateMoyennePonderee(inscriptionId);
            if (moyenne == null) return fail(ins, "Notes manquantes ou insuffisantes pour calcul.");
            inscriptionDAO.updateMoyenneBac(inscriptionId, moyenne);

            // Récupérer le seuil requis
            double seuil = filiereDAO.getMoyenneSeuil(filiere.getId(), ins.getNiveau());
            if (moyenne < seuil) {
                return fail(ins, "Moyenne (" + String.format("%.2f", moyenne) + ") inférieure au seuil (" + String.format("%.2f", seuil) + ").");
            }

            // Succès : mise à jour statut, notification et audit
            inscriptionDAO.updateStatut(inscriptionId, "prévalidé",
                    "Prévalidation OK (moyenne " + String.format("%.2f", moyenne) + ")");
            notify(ins.getEtudiantId(), "Prévalidation réussie",
                    "Votre dossier est prévalidé (moyenne " + String.format("%.2f", moyenne) + ").", "INFO");
            audit(inscriptionId, ins.getEtudiantId(), "PREVALIDATE", "Prévalidation automatique réussie");
            return true;

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Erreur prevalidation inscriptionId=" + inscriptionId, e);
            try {
                Inscription ins = inscriptionDAO.findById(inscriptionId);
                if (ins != null) {
                    inscriptionDAO.updateStatut(inscriptionId, "erreur", "Erreur lors de la prévalidation, voir logs");
                    audit(inscriptionId, ins.getEtudiantId(), "PREVALIDATE_ERROR", "Exception pendant prévalidation");
                }
            } catch (Exception ex) {
                LOGGER.log(Level.SEVERE, "Impossible de marquer l'inscription en erreur pour id=" + inscriptionId, ex);
            }
            return false;
        }
    }

    private boolean fail(Inscription ins, String msg) throws Exception {
        inscriptionDAO.updateStatut(ins.getId(), "rejeté", "Prévalidation échouée: " + msg);
        notify(ins.getEtudiantId(), "Prévalidation échouée", msg, "WARNING");
        audit(ins.getId(), ins.getEtudiantId(), "PREVALIDATE_FAIL", msg);
        return false;
    }

    private void notify(int userId, String titre, String message, String type) throws Exception {
        notificationService.send(userId, titre, message, type, "etudiant/mesDemandes.jsp");
    }

    private void audit(int inscriptionId, int userId, String action, String comment) throws Exception {
        AuditTrail a = new AuditTrail();
        a.setEntity("Inscription");
        a.setEntityId(inscriptionId);
        a.setAction(action);
        a.setUserId(userId);
        a.setCommentaire(comment);
        auditRepo.insert(a);
    }
}

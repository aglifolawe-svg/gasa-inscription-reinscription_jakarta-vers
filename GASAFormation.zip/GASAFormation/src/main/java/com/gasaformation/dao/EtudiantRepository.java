package com.gasaformation.dao;

import com.gasaformation.model.Etudiant;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.*;

public class EtudiantRepository {
    private final DataSource ds;

    public EtudiantRepository() throws Exception {
        ds = (DataSource) new InitialContext().lookup("jdbc/gasaFormationPool");
    }

    // Insert et retourne l'id généré dans l'objet Etudiant
    public void insert(Etudiant e) throws SQLException {
        String sql = "INSERT INTO etudiants(utilisateur_id, nom, prenom, sexe, date_naissance, lieu_naissance, adresse, telephone, email) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, e.getUtilisateurId());
            ps.setString(2, e.getNom());
            ps.setString(3, e.getPrenom());
            ps.setString(4, e.getSexe());

            if (e.getDateNaissance() != null) {
                ps.setDate(5, new java.sql.Date(e.getDateNaissance().getTime()));
            } else {
                ps.setNull(5, java.sql.Types.DATE);
            }

            ps.setString(6, e.getLieuNaissance());
            ps.setString(7, e.getAdresse());
            ps.setString(8, e.getTelephone());
            ps.setString(9, e.getEmail());

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    e.setId(rs.getInt(1));
                }
            }
        }
    }

    public Etudiant findById(int id) throws SQLException {
        String sql = "SELECT * FROM etudiants WHERE id = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Etudiant e = new Etudiant();
                    e.setId(rs.getInt("id"));
                    e.setUtilisateurId(rs.getInt("utilisateur_id"));
                    e.setNom(rs.getString("nom"));
                    e.setPrenom(rs.getString("prenom"));
                    e.setSexe(rs.getString("sexe"));
                    Date d = rs.getDate("date_naissance");
                    if (d != null) e.setDateNaissance(new java.util.Date(d.getTime()));
                    e.setLieuNaissance(rs.getString("lieu_naissance"));
                    e.setAdresse(rs.getString("adresse"));
                    e.setTelephone(rs.getString("telephone"));
                    e.setEmail(rs.getString("email"));
                    return e;
                }
            }
        }
        return null;
    }
}

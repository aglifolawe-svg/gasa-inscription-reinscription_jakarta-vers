package com.gasaformation.dao;

import com.gasaformation.model.BacSerie;
import com.gasaformation.model.MatierePrincipale;

import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

public class BacSerieRepository {
    private final DataSource ds;

    public BacSerieRepository() throws Exception {
        ds = (DataSource) new InitialContext().lookup("jdbc/gasaFormationPool");
    }

    // Attempt safe fetch of all series; tolerate either libelle or name column
    public List<BacSerie> findAll() throws SQLException {
        List<BacSerie> list = new ArrayList<>();

        // Try preferred schema first: libelle
        String sql1 = "SELECT id, code, libelle FROM bac_series ORDER BY id";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql1);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                BacSerie b = new BacSerie();
                b.setId(rs.getInt("id"));
                b.setCode(rs.getString("code"));
                b.setLibelle(rs.getString("libelle"));
                list.add(b);
            }
            return list;
        } catch (SQLException e) {
            // If column libelle doesn't exist, fall through to alternate query
        }

        // Fallback: try column 'name' mapped to libelle
        String sql2 = "SELECT id, code, name AS libelle FROM bac_series ORDER BY id";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql2);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                BacSerie b = new BacSerie();
                b.setId(rs.getInt("id"));
                b.setCode(rs.getString("code"));
                b.setLibelle(rs.getString("libelle"));
                list.add(b);
            }
            return list;
        } catch (SQLException e) {
            // If both fail, rethrow the original exception for visibility
            throw new SQLException("Impossible de lire bac_series (ni libelle ni name)", e);
        }
    }

    public BacSerie findByCode(String code) throws SQLException {
        // Prefer libelle column variant; use COALESCE not possible cross-schema, so attempt both
        String sql1 = "SELECT id, code, libelle FROM bac_series WHERE code = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql1)) {
            ps.setString(1, code);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    BacSerie b = new BacSerie();
                    b.setId(rs.getInt("id"));
                    b.setCode(rs.getString("code"));
                    b.setLibelle(rs.getString("libelle"));
                    return b;
                }
            }
        } catch (SQLException e) {
            // fallthrough
        }

        String sql2 = "SELECT id, code, name AS libelle FROM bac_series WHERE code = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql2)) {
            ps.setString(1, code);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    BacSerie b = new BacSerie();
                    b.setId(rs.getInt("id"));
                    b.setCode(rs.getString("code"));
                    b.setLibelle(rs.getString("libelle"));
                    return b;
                }
            }
        }
        return null;
    }

    public List<MatierePrincipale> findMatieresBySerieId(int serieId) throws SQLException {
        String sql = "SELECT id, code, libelle, coefficient, bac_serie_id " +
                     "FROM matieres_principales WHERE bac_serie_id = ? ORDER BY id";
        List<MatierePrincipale> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, serieId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    MatierePrincipale m = new MatierePrincipale();
                    m.setId(rs.getInt("id"));
                    m.setCode(rs.getString("code"));
                    m.setLibelle(rs.getString("libelle"));
                    m.setCoef(rs.getDouble("coefficient"));
                    m.setBacSerieId(rs.getInt("bac_serie_id"));
                    list.add(m);
                }
            }
        }
        return list;
    }

    public List<MatierePrincipale> findMatieresBySerieCode(String serieCode) throws SQLException {
        String sql = "SELECT m.id, m.code, m.libelle, m.coefficient, m.bac_serie_id " +
                     "FROM matieres_principales m " +
                     "JOIN bac_series b ON m.bac_serie_id = b.id " +
                     "WHERE b.code = ? ORDER BY m.id";
        List<MatierePrincipale> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, serieCode);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    MatierePrincipale m = new MatierePrincipale();
                    m.setId(rs.getInt("id"));
                    m.setCode(rs.getString("code"));
                    m.setLibelle(rs.getString("libelle"));
                    m.setCoef(rs.getDouble("coefficient"));
                    m.setBacSerieId(rs.getInt("bac_serie_id"));
                    list.add(m);
                }
            }
        }
        return list;
    }
}

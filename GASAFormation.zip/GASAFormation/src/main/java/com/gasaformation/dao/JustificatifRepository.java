package com.gasaformation.dao;

import com.gasaformation.model.Justificatif;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

public class JustificatifRepository {
    private final DataSource ds;

    public JustificatifRepository() throws Exception {
        ds = (DataSource) new InitialContext().lookup("jdbc/gasaFormationPool");
    }

    // Insert aligné sur la table (pas de colonne "statut" en base)
    public void insert(Justificatif j) throws SQLException {
        String sql = "INSERT INTO justificatifs(inscription_id, type, filename, path, mime_type, date_upload) " +
                     "VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, j.getInscriptionId());
            ps.setString(2, j.getType());
            ps.setString(3, j.getFilename());
            ps.setString(4, j.getPath());
            ps.setString(5, j.getMimeType());

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    j.setId(rs.getInt(1));
                }
            }
        }
    }

    // Récupération des justificatifs d'une inscription (sans statut en base)
    public List<Justificatif> findByInscription(int inscriptionId) throws SQLException {
        String sql = "SELECT id, inscription_id, type, filename, path, mime_type, date_upload " +
                     "FROM justificatifs WHERE inscription_id = ?";
        List<Justificatif> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, inscriptionId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Justificatif j = new Justificatif();
                    j.setId(rs.getInt("id"));
                    j.setInscriptionId(rs.getInt("inscription_id"));
                    j.setType(rs.getString("type"));
                    j.setFilename(rs.getString("filename"));
                    j.setPath(rs.getString("path"));
                    j.setMimeType(rs.getString("mime_type"));
                    Timestamp ts = rs.getTimestamp("date_upload");
                    if (ts != null) j.setDateUpload(new java.util.Date(ts.getTime()));
                    // j.getStatut() reste un champ transient géré côté appli si nécessaire
                    list.add(j);
                }
            }
        }
        return list;
    }

    // Vérifie la présence des pièces obligatoires selon le niveau
    public boolean hasRequiredForLevel(int inscriptionId, String niveau) throws SQLException {
        String sql = "SELECT type FROM justificatifs WHERE inscription_id = ?";
        Set<String> types = new HashSet<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, inscriptionId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) types.add(rs.getString("type"));
            }
        }
        boolean baseOk = types.contains("PHOTO") && types.contains("ACTE_NAISSANCE")
                && types.contains("ATTESTATION_BAC") && types.contains("RELEVE_BAC");
        if ("L1".equalsIgnoreCase(niveau)) return baseOk;
        boolean hasSemestre = types.contains("RELEVE_SEMESTRE");
        return baseOk && hasSemestre;
    }
}

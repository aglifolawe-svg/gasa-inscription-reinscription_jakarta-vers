package com.gasaformation.dao;

import com.gasaformation.model.NoteBac;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

public class NoteBacRepository {
    private final DataSource ds;

    public NoteBacRepository() throws Exception {
        ds = (DataSource) new InitialContext().lookup("jdbc/gasaFormationPool");
    }

    // Insertion: récupère l'id généré et le place dans l'objet NoteBac
    public void insert(NoteBac n) throws SQLException {
        String sql = "INSERT INTO notes_bac(inscription_id, matiere_principale_id, note) VALUES (?, ?, ?)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, n.getInscriptionId());
            ps.setInt(2, n.getMatierePrincipaleId());
            ps.setDouble(3, n.getNote());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) n.setId(rs.getInt(1));
            }
        }
    }

    // Méthode brute (conserve pour compatibilité)
    public List<NoteBac> findByInscription(int inscriptionId) throws SQLException {
        String sql = "SELECT * FROM notes_bac WHERE inscription_id = ?";
        List<NoteBac> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, inscriptionId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    NoteBac n = new NoteBac();
                    n.setId(rs.getInt("id"));
                    n.setInscriptionId(rs.getInt("inscription_id"));
                    n.setMatierePrincipaleId(rs.getInt("matiere_principale_id"));
                    n.setNote(rs.getDouble("note"));
                    list.add(n);
                }
            }
        }
        return list;
    }

    // Méthode enrichie: jointure sur matière pour coefficient/libellé
    public List<NoteBac> findByInscriptionId(int inscriptionId) throws SQLException {
        String sql = "SELECT n.id, n.inscription_id, n.matiere_principale_id, n.note, " +
                     "m.libelle, m.coefficient " +
                     "FROM notes_bac n " +
                     "LEFT JOIN matieres_principales m ON n.matiere_principale_id = m.id " +
                     "WHERE n.inscription_id = ?";
        List<NoteBac> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, inscriptionId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    NoteBac n = new NoteBac();
                    n.setId(rs.getInt("id"));
                    n.setInscriptionId(rs.getInt("inscription_id"));
                    n.setMatierePrincipaleId(rs.getInt("matiere_principale_id"));
                    n.setNote(rs.getDouble("note"));
                    try { n.setMatierePrincipaleLibelle(rs.getString("libelle")); } catch (SQLException ignore) {}
                    try {
                        double coeff = rs.getDouble("coefficient");
                        if (!rs.wasNull()) n.setMatierePrincipaleCoefficient(coeff);
                    } catch (SQLException ignore) {}
                    list.add(n);
                }
            }
        }
        return list;
    }

    // Calcule la moyenne pondérée basée sur les notes et coefficients
    // Retourne null si aucune note trouvée
    public Double calculateMoyennePonderee(int inscriptionId) throws SQLException {
        String sql = "SELECT n.note, COALESCE(m.coefficient, 1) AS coefficient " +
                     "FROM notes_bac n " +
                     "LEFT JOIN matieres_principales m ON n.matiere_principale_id = m.id " +
                     "WHERE n.inscription_id = ?";
        double sommePesee = 0.0;
        double sommeCoef = 0.0;
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, inscriptionId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    double note = rs.getDouble("note");
                    if (rs.wasNull()) continue;
                    double coef = rs.getDouble("coefficient");
                    if (rs.wasNull()) coef = 1.0;
                    sommePesee += note * coef;
                    sommeCoef += coef;
                }
            }
        }
        if (sommeCoef == 0.0) return null;
        // Arrondi à 2 décimales pour stockage lisible
        double moyenne = sommePesee / sommeCoef;
        return Math.round(moyenne * 100.0) / 100.0;
    }
}

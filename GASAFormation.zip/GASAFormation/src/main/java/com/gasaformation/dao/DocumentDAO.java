package com.gasaformation.dao;

import com.gasaformation.model.Document;

import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DocumentDAO {
    private static final Logger LOGGER = Logger.getLogger(DocumentDAO.class.getName());
    private final DataSource ds;

    public DocumentDAO() throws Exception {
        ds = (DataSource) new InitialContext().lookup("jdbc/gasaFormationPool");
    }

    public void insert(Document doc) throws SQLException {
        String sql = "INSERT INTO documents(inscription_id, type, filename, path, date_upload) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, doc.getInscriptionId());
            ps.setString(2, doc.getType());
            ps.setString(3, doc.getFilename());
            ps.setString(4, doc.getPath());
            ps.executeUpdate();
        }
    }

    public List<Document> findByInscription(int inscriptionId) {
        String sql = "SELECT * FROM documents WHERE inscription_id = ?";
        List<Document> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, inscriptionId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findByInscription documents", e);
        }
        return list;
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM documents WHERE id = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    private Document map(ResultSet rs) throws SQLException {
        Document d = new Document();
        d.setId(rs.getInt("id"));
        d.setInscriptionId(rs.getInt("inscription_id"));
        d.setType(rs.getString("type"));
        d.setFilename(rs.getString("filename"));
        d.setPath(rs.getString("path"));
        d.setDateUpload(rs.getTimestamp("date_upload"));
        return d;
    }
}

package com.gasaformation.dao;

import com.gasaformation.model.Notification;

import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class NotificationDAO {
    private static final Logger LOGGER = Logger.getLogger(NotificationDAO.class.getName());
    private final DataSource ds;

    public NotificationDAO() throws Exception {
        ds = (DataSource) new InitialContext().lookup("jdbc/gasaFormationPool");
    }

    // 🔹 Créer une notification
    public void insert(Notification n) throws SQLException {
        String sql = "INSERT INTO notifications(user_id, titre, message, type, lien, date_notif, lu) " +
                     "VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, false)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, n.getUserId());
            ps.setString(2, n.getTitre());
            ps.setString(3, n.getMessage());
            ps.setString(4, n.getType());
            ps.setString(5, n.getLien());
            ps.executeUpdate();
        }
    }

    // 🔹 Récupérer les notifications d’un utilisateur
    public List<Notification> findByUser(int userId) {
        String sql = "SELECT * FROM notifications WHERE user_id = ? ORDER BY date_notif DESC";
        List<Notification> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findByUser notifications", e);
        }
        return list;
    }

    // 🔹 Marquer comme lue
    public void markAsRead(int id) throws SQLException {
        String sql = "UPDATE notifications SET lu = true WHERE id = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    // 🔹 Mapping ResultSet -> Objet
    private Notification map(ResultSet rs) throws SQLException {
        Notification n = new Notification();
        n.setId(rs.getInt("id"));
        n.setUserId(rs.getInt("user_id"));
        n.setTitre(rs.getString("titre"));
        n.setMessage(rs.getString("message"));
        n.setType(rs.getString("type"));
        n.setLien(rs.getString("lien"));
        n.setDateNotif(rs.getTimestamp("date_notif"));
        n.setLu(rs.getBoolean("lu"));
        return n;
    }
}

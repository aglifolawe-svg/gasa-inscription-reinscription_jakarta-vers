package com.gasaformation.dao;

import com.gasaformation.model.AuditTrail;

import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AuditTrailRepository {
    private static final Logger LOGGER = Logger.getLogger(AuditTrailRepository.class.getName());
    private final DataSource ds;

    public AuditTrailRepository() throws Exception {
        ds = (DataSource) new InitialContext().lookup("jdbc/gasaFormationPool");
    }

    // 🔹 Insérer une nouvelle entrée d’audit
    public void insert(AuditTrail audit) throws SQLException {
        String sql = "INSERT INTO audit_trail(entity, entity_id, action, user_id, commentaire, date_action) " +
                     "VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, audit.getEntity());
            ps.setInt(2, audit.getEntityId());
            ps.setString(3, audit.getAction());
            ps.setInt(4, audit.getUserId());
            ps.setString(5, audit.getCommentaire());
            ps.executeUpdate();
        }
    }

    // 🔹 Récupérer tout l’historique
    public List<AuditTrail> findAll() {
        String sql = "SELECT * FROM audit_trail ORDER BY date_action DESC";
        List<AuditTrail> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findAll audit_trail", e);
        }
        return list;
    }

    // 🔹 Récupérer l’historique d’une entité spécifique (ex: une inscription)
    public List<AuditTrail> findByEntity(String entity, int entityId) {
        String sql = "SELECT * FROM audit_trail WHERE entity = ? AND entity_id = ? ORDER BY date_action DESC";
        List<AuditTrail> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, entity);
            ps.setInt(2, entityId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findByEntity audit_trail", e);
        }
        return list;
    }

    // 🔹 Récupérer l’historique d’un utilisateur (qui a fait quoi)
    public List<AuditTrail> findByUser(int userId) {
        String sql = "SELECT * FROM audit_trail WHERE user_id = ? ORDER BY date_action DESC";
        List<AuditTrail> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findByUser audit_trail", e);
        }
        return list;
    }

    // 🔹 Mapping ResultSet -> Objet AuditTrail
    private AuditTrail map(ResultSet rs) throws SQLException {
        AuditTrail a = new AuditTrail();
        a.setId(rs.getInt("id"));
        a.setEntity(rs.getString("entity"));
        a.setEntityId(rs.getInt("entity_id"));
        a.setAction(rs.getString("action"));
        a.setUserId(rs.getInt("user_id"));
        a.setCommentaire(rs.getString("commentaire"));
        a.setDateAction(rs.getTimestamp("date_action"));
        return a;
    }
}

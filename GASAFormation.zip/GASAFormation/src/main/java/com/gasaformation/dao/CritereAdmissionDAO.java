package com.gasaformation.dao;

import com.gasaformation.model.CritereAdmission;
import com.gasaformation.model.CritereMatiereSeuil;

import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CritereAdmissionDAO {
    private static final Logger LOGGER = Logger.getLogger(CritereAdmissionDAO.class.getName());
    private final DataSource ds;

    public CritereAdmissionDAO() throws Exception {
        ds = (DataSource) new InitialContext().lookup("jdbc/gasaFormationPool");
    }

    // Insérer un critère d’admission
    public void insert(CritereAdmission cr) throws SQLException {
        String sql = "INSERT INTO criteres_admission(filiere_id, niveau, moyenne_minimum, series_compatibles, titre, description, document_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, cr.getFiliereId());
            ps.setString(2, cr.getNiveau());
            ps.setDouble(3, cr.getMoyenneMinimum());
            ps.setString(4, cr.getSeriesCompatibles() != null ? String.join(",", cr.getSeriesCompatibles()) : null);
            ps.setString(5, cr.getTitre());
            ps.setString(6, cr.getDescription());
            if (cr.getDocumentId() != null) {
                ps.setInt(7, cr.getDocumentId());
            } else {
                ps.setNull(7, Types.INTEGER);
            }

            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) cr.setId(rs.getInt(1));
            }
        }

        // Insérer les seuils matières si fournis
        if (cr.getMatieresSeuils() != null) {
            for (CritereMatiereSeuil s : cr.getMatieresSeuils()) {
                insertMatiereSeuil(cr.getId(), s);
            }
        }
    }

    // Insérer un seuil matière
    public void insertMatiereSeuil(int critereId, CritereMatiereSeuil s) throws SQLException {
        String sql = "INSERT INTO critere_matieres(critere_id, matiere_code, note_min) VALUES (?, ?, ?)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, critereId);
            ps.setString(2, s.getMatiereCode());
            ps.setDouble(3, s.getNoteMin());
            ps.executeUpdate();
        }
    }

    // Récupérer critère par filière + niveau
    public CritereAdmission findByFiliereAndNiveau(int filiereId, String niveau) {
        String sql = "SELECT id, filiere_id, niveau, moyenne_minimum, series_compatibles, titre, description, document_id FROM criteres_admission WHERE filiere_id = ? AND LOWER(niveau) = LOWER(?)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, filiereId);
            ps.setString(2, niveau);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    CritereAdmission cr = map(rs);
                    cr.setMatieresSeuils(findSeuilsByCritere(cr.getId()));
                    return cr;
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findByFiliereAndNiveau", e);
        }
        return null;
    }

    // Récupérer les seuils matières
    public List<CritereMatiereSeuil> findSeuilsByCritere(int critereId) {
        String sql = "SELECT id, critere_id, matiere_code, note_min FROM critere_matieres WHERE critere_id = ?";
        List<CritereMatiereSeuil> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, critereId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    CritereMatiereSeuil s = new CritereMatiereSeuil();
                    s.setId(rs.getInt("id"));
                    s.setCritereId(rs.getInt("critere_id"));
                    s.setMatiereCode(rs.getString("matiere_code"));
                    s.setNoteMin(rs.getDouble("note_min"));
                    list.add(s);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findSeuilsByCritere", e);
        }
        return list;
    }

    // Mapping ResultSet -> Objet
    private CritereAdmission map(ResultSet rs) throws SQLException {
        CritereAdmission cr = new CritereAdmission();
        cr.setId(rs.getInt("id"));
        cr.setFiliereId(rs.getInt("filiere_id"));
        cr.setNiveau(rs.getString("niveau"));

        // colonne nommée moyenne_minimum dans ton modèle
        try {
            double mm = rs.getDouble("moyenne_minimum");
            if (!rs.wasNull()) cr.setMoyenneMinimum(mm);
        } catch (SQLException ignore) {
            // si la colonne n'existe pas dans un ancien schéma, garder la valeur par défaut
        }

        String csv = null;
        try { csv = rs.getString("series_compatibles"); } catch (SQLException ignore) {}
        cr.setSeriesCompatibles((csv != null && !csv.trim().isEmpty()) ? Arrays.asList(csv.split(",")) : Collections.emptyList());

        try { cr.setTitre(rs.getString("titre")); } catch (SQLException ignore) {}
        try { cr.setDescription(rs.getString("description")); } catch (SQLException ignore) {}

        try {
            Object docObj = rs.getObject("document_id");
            if (docObj == null) cr.setDocumentId(null);
            else if (docObj instanceof Number) cr.setDocumentId(((Number) docObj).intValue());
            else cr.setDocumentId(Integer.valueOf(docObj.toString()));
        } catch (SQLException ignore) {
            cr.setDocumentId(null);
        }

        return cr;
    }
}

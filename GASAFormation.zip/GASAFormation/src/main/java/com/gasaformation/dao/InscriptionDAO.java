package com.gasaformation.dao;

import com.gasaformation.model.Inscription;

import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class InscriptionDAO {
    private static final Logger LOGGER = Logger.getLogger(InscriptionDAO.class.getName());
    private final DataSource ds;

    public InscriptionDAO() throws Exception {
        ds = (DataSource) new InitialContext().lookup("jdbc/gasaFormationPool");
    }

    // Vérifie si un étudiant existe
    private boolean etudiantExists(Connection c, int etudiantId) throws SQLException {
        String sql = "SELECT 1 FROM etudiants WHERE id = ?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, etudiantId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    // Insertion d'une nouvelle inscription (alignée sur la base: filiere_id)
public void insert(Inscription insc) throws SQLException {
    // 🔹 Forcer un statut par défaut si rien n’est fourni
    if (insc.getStatut() == null || insc.getStatut().trim().isEmpty()) {
        insc.setStatut("en attente");
    }

    String sql = "INSERT INTO inscriptions(" +
                 "etudiant_id, filiere_id, niveau, type, statut, date_inscription, " +
                 "serie_bac, diplome, annee_obtention, etablissement_origine, " +
                 "commentaire, mention, moyenne_bac) " +
                 "VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?, ?, ?, ?, ?, ?, ?)";

    try (Connection c = ds.getConnection()) {
        // Vérifier que l'étudiant existe
        if (!etudiantExists(c, insc.getEtudiantId())) {
            throw new SQLException("L'étudiant avec id=" + insc.getEtudiantId() + " n'existe pas.");
        }

        try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            // FK vers etudiants
            ps.setInt(1, insc.getEtudiantId());

            // FK vers filieres
            ps.setInt(2, insc.getFiliereId());

            // Métadonnées
            ps.setString(3, insc.getNiveau());
            ps.setString(4, insc.getType());
            ps.setString(5, insc.getStatut());

            // Académiques
            ps.setString(6, insc.getSerieBac());
            ps.setString(7, insc.getDiplome());
            ps.setInt(8, insc.getAnneeObtention());
            ps.setString(9, insc.getEtablissementOrigine());

            // Compléments
            ps.setString(10, insc.getCommentaire());
            ps.setString(11, insc.getMention());
            if (insc.getMoyenneBac() != null) {
                ps.setDouble(12, insc.getMoyenneBac());
            } else {
                ps.setNull(12, java.sql.Types.NUMERIC);
            }

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) insc.setId(rs.getInt(1));
            }
        }
    }
}


    // Variante pratique : insérer une inscription directement via username
public void insertForUsername(String username, Inscription insc) throws SQLException {
    String sqlEtudiant = "SELECT e.id FROM etudiants e " +
                         "JOIN utilisateurs u ON e.utilisateur_id = u.id " +
                         "WHERE u.username = ?";
    try (Connection c = ds.getConnection();
         PreparedStatement psE = c.prepareStatement(sqlEtudiant)) {
        psE.setString(1, username);
        try (ResultSet rs = psE.executeQuery()) {
            if (rs.next()) {
                int etudiantId = rs.getInt("id");
                insc.setEtudiantId(etudiantId);

                // 🔹 Forcer statut par défaut si absent
                if (insc.getStatut() == null || insc.getStatut().trim().isEmpty()) {
                    insc.setStatut("en attente");
                }

                // 🔹 Insertion classique
                insert(insc);

                // 🔹 Déclenchement de la prévalidation automatique
                try {
                    com.gasaformation.service.PrevalidationService prevalidator =
                            new com.gasaformation.service.PrevalidationService();
                    prevalidator.prevalidate(insc.getId());
                } catch (Exception e) {
                    // On logge mais on ne bloque pas l’insertion
                    LOGGER.log(Level.SEVERE, "Erreur lors de la prévalidation automatique", e);
                }

            } else {
                throw new SQLException("Aucun étudiant trouvé pour l'utilisateur " + username);
            }
        }
    }
}


    // Mettre à jour la moyenne calculée (pour la prévalidation)
    public void updateMoyenneBac(int inscriptionId, Double moyenne) throws SQLException {
        String sql = "UPDATE inscriptions SET moyenne_bac = ? WHERE id = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            if (moyenne != null) {
                ps.setDouble(1, moyenne);
            } else {
                ps.setNull(1, java.sql.Types.NUMERIC);
            }
            ps.setInt(2, inscriptionId);
            ps.executeUpdate();
        }
    }

    // Récupérer les inscriptions par statut
    public List<Inscription> findByStatut(String statut) {
        String sql = "SELECT * FROM inscriptions WHERE LOWER(statut) = LOWER(?) ORDER BY date_inscription DESC";
        List<Inscription> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, statut);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findByStatut inscriptions", e);
        }
        return list;
    }

    // Récupérer une inscription par id
    public Inscription findById(int id) {
        String sql = "SELECT * FROM inscriptions WHERE id = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findById inscription", e);
        }
        return null;
    }

    // Récupérer les inscriptions d'un utilisateur par username
    public List<Inscription> findByUsername(String username) {
        String sql = "SELECT i.* " +
                     "FROM inscriptions i " +
                     "JOIN etudiants e ON i.etudiant_id = e.id " +
                     "JOIN utilisateurs u ON e.utilisateur_id = u.id " +
                     "WHERE u.username = ? " +
                     "ORDER BY i.date_inscription DESC";
        List<Inscription> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findByUsername inscriptions", e);
        }
        return list;
    }

    // Récupérer une inscription avec nom de filière (remplit filiereNom)
    public Inscription findByIdWithFiliere(int id) {
        String sql = "SELECT i.*, f.nom AS filiere_nom " +
                     "FROM inscriptions i " +
                     "LEFT JOIN filieres f ON i.filiere_id = f.id " +
                     "WHERE i.id = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Inscription ins = map(rs);
                    ins.setFiliereNom(rs.getString("filiere_nom"));
                    return ins;
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findByIdWithFiliere inscription", e);
        }
        return null;
    }

    // Validation inscription + promotion utilisateur
    public void validateInscriptionAndUser(int inscriptionId, int userId) throws SQLException {
        String sql1 = "UPDATE inscriptions SET statut = 'validé' WHERE id = ?";
        String sql2 = "UPDATE utilisateurs SET role = 'etudiant_de_gasa', statut = 'validé' WHERE id = ?";
        try (Connection c = ds.getConnection()) {
            c.setAutoCommit(false);
            try (PreparedStatement ps1 = c.prepareStatement(sql1);
                 PreparedStatement ps2 = c.prepareStatement(sql2)) {
                ps1.setInt(1, inscriptionId);
                ps1.executeUpdate();
                ps2.setInt(1, userId);
                ps2.executeUpdate();
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            } finally {
                c.setAutoCommit(true);
            }
        }
    }

    // Validation inscription seule
    public void validateOnlyInscription(int inscriptionId) throws SQLException {
        String sql = "UPDATE inscriptions SET statut = 'validé' WHERE id = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, inscriptionId);
            ps.executeUpdate();
        }
    }

    // Rejet inscription
    public void rejectInscription(int inscriptionId) throws SQLException {
        String sql = "UPDATE inscriptions SET statut = 'rejete' WHERE id = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, inscriptionId);
            ps.executeUpdate();
        }
    }

    // Mettre à jour statut + commentaire
    public void updateStatut(int inscriptionId, String statut, String commentaire) throws SQLException {
        String sql = "UPDATE inscriptions SET statut = ?, commentaire = ? WHERE id = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, statut);
            ps.setString(2, commentaire);
            ps.setInt(3, inscriptionId);
            ps.executeUpdate();
        }
    }

    // Mapping ResultSet -> Objet Inscription (aligné sur colonnes réelles)
    private Inscription map(ResultSet rs) throws SQLException {
        Inscription ins = new Inscription();
        ins.setId(rs.getInt("id"));
        ins.setEtudiantId(rs.getInt("etudiant_id"));

        // FK filiere_id
        try {
            ins.setFiliereId(rs.getInt("filiere_id"));
        } catch (SQLException ignore) {
            // si la colonne n'existe pas dans un ancien schéma
        }

        // Colonne texte filiere (si présente dans inscriptions)
        try {
            ins.setFiliere(rs.getString("filiere"));
        } catch (SQLException ignore) {}

        ins.setNiveau(rs.getString("niveau"));
        ins.setType(rs.getString("type"));
        ins.setStatut(rs.getString("statut"));

        Timestamp ts = rs.getTimestamp("date_inscription");
        if (ts != null) ins.setDateInscription(new java.util.Date(ts.getTime()));

        ins.setSerieBac(rs.getString("serie_bac"));
        ins.setDiplome(rs.getString("diplome"));
        ins.setAnneeObtention(rs.getInt("annee_obtention"));
        ins.setEtablissementOrigine(rs.getString("etablissement_origine"));

        ins.setCommentaire(rs.getString("commentaire"));

        // mention (text) si présente
        try {
            ins.setMention(rs.getString("mention"));
        } catch (SQLException ignore) {}

        // moyenne_bac si présente
        try {
            double mb = rs.getDouble("moyenne_bac");
            if (!rs.wasNull()) ins.setMoyenneBac(mb);
        } catch (SQLException ignore) {}

        return ins;
    }
}

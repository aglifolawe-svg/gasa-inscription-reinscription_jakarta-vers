package com.gasaformation.dao;

import com.gasaformation.model.EmploiDuTemps;
import javax.naming.InitialContext;
import javax.naming.Context;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

public class EmploiDuTempsDAO {
    private DataSource ds;

    public EmploiDuTempsDAO() throws Exception {
        Context ctx = new InitialContext();
        ds = (DataSource) ctx.lookup("jdbc/gasaFormationPool");
    }

    public List<EmploiDuTemps> findAll() throws SQLException {
        List<EmploiDuTemps> list = new ArrayList<>();
        String sql = "SELECT * FROM emplois_du_temps";
        try (Connection conn = ds.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                EmploiDuTemps e = new EmploiDuTemps();
                e.setId(rs.getInt("id"));
                e.setFiliere(rs.getString("filiere"));
                e.setNiveau(rs.getString("niveau"));
                e.setSalle(rs.getString("salle"));
                e.setJour(rs.getString("jour"));
                Time tDeb = rs.getTime("heure_debut");
                Time tFin = rs.getTime("heure_fin");
                if (tDeb != null) e.setHeureDebut(tDeb.toLocalTime());
                if (tFin != null) e.setHeureFin(tFin.toLocalTime());
                list.add(e);
            }
        }
        return list;
    }
}

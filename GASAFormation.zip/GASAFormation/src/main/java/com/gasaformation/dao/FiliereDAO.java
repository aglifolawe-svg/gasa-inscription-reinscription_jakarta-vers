package com.gasaformation.dao;

import com.gasaformation.model.Filiere;

import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FiliereDAO {
    private static final Logger LOGGER = Logger.getLogger(FiliereDAO.class.getName());
    private final DataSource ds;

    public FiliereDAO() throws Exception {
        ds = (DataSource) new InitialContext().lookup("jdbc/gasaFormationPool");
    }

    // Récupérer une filière par id
    public Filiere findById(int id) {
        String sql = "SELECT id, nom, ufr FROM filieres WHERE id = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Filiere f = new Filiere();
                    f.setId(rs.getInt("id"));
                    f.setNom(rs.getString("nom"));
                    try { f.setUfr(rs.getString("ufr")); } catch (SQLException ignore) {}
                    return f;
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findById filiere id=" + id, e);
        }
        return null;
    }

    // Groupement par UFR (robuste si la colonne ufr n’existe pas)
    public Map<String, List<Filiere>> findGroupedByUfr() {
        String sql = "SELECT id, nom, ufr FROM filieres ORDER BY ufr, nom";
        Map<String, List<Filiere>> map = new LinkedHashMap<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Filiere f = new Filiere();
                f.setId(rs.getInt("id"));
                f.setNom(rs.getString("nom"));
                String ufr;
                try {
                    ufr = rs.getString("ufr"); // peut ne pas exister selon le schéma
                } catch (SQLException ignore) {
                    ufr = null;
                }
                f.setUfr(ufr);
                map.computeIfAbsent(ufr != null ? ufr : "Autres", k -> new ArrayList<>()).add(f);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur groupement filières par UFR", e);
        }
        return map;
    }

    // Trouver une filière par nom
    public Filiere findByName(String nom) {
        String sql = "SELECT id, nom, ufr FROM filieres WHERE LOWER(nom) = LOWER(?)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, nom);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Filiere f = new Filiere();
                    f.setId(rs.getInt("id"));
                    f.setNom(rs.getString("nom"));
                    try { f.setUfr(rs.getString("ufr")); } catch (SQLException ignore) {}
                    return f;
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findByName filière: " + nom, e);
        }
        return null;
    }

    // Vérifier compatibilité série ↔ filière (tente 2 noms de table)
    public boolean isSerieCompatible(int filiereId, String serieCode) {
        if (serieCode == null) return false;
        String[] tables = {
            "filiere_compat_series",
            "filiere_comptat_series" // fallback vu dans certains dumps
        };
        for (String table : tables) {
            String sql = "SELECT 1 FROM " + table + " WHERE filiere_id = ? AND UPPER(serie_code) = UPPER(?)";
            try (Connection c = ds.getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setInt(1, filiereId);
                ps.setString(2, serieCode);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return true;
                }
            } catch (SQLException e) {
                // table peut ne pas exister : on essaie la suivante
                LOGGER.log(Level.FINE, "Table compatibilité série introuvable ou erreur: " + table, e);
            }
        }
        return false;
    }

    // Récupérer le seuil de moyenne exigé (fallback 12 si non défini)
    public double getMoyenneSeuil(int filiereId, String niveau) {
        // On tente moyenne_minimum puis moyenne_min
        String[] cols = { "moyenne_minimum", "moyenne_min" };
        for (String col : cols) {
            String sql = "SELECT " + col + " FROM criteres_admission WHERE filiere_id = ? AND LOWER(niveau) = LOWER(?)";
            try (Connection c = ds.getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setInt(1, filiereId);
                ps.setString(2, niveau);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        double val = rs.getDouble(1);
                        if (!rs.wasNull()) return val;
                    }
                }
            } catch (SQLException e) {
                LOGGER.log(Level.FINE, "Colonne seuil non trouvée: " + col, e);
            }
        }
        return 12.0;
    }
}

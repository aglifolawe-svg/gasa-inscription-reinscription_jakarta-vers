package com.gasaformation.dao;

import com.gasaformation.model.Utilisateur;

import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UtilisateurDAO {
    private static final Logger LOGGER = Logger.getLogger(UtilisateurDAO.class.getName());
    private final DataSource ds;

    public UtilisateurDAO() throws Exception {
        ds = (DataSource) new InitialContext().lookup("jdbc/gasaFormationPool");
    }

    // Insertion complète
    public void insert(Utilisateur u) throws SQLException {
        String sql = "INSERT INTO utilisateurs(username, password, role, statut, poste, nom, prenom, sexe, photo_url, filiere, numero_etudiant) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, u.getUsername());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getRole());
            ps.setString(4, u.getStatut());
            ps.setString(5, u.getPoste());
            ps.setString(6, u.getNom());
            ps.setString(7, u.getPrenom());
            ps.setString(8, u.getSexe());
            ps.setString(9, u.getPhotoUrl());
            ps.setString(10, u.getFiliere());
            ps.setString(11, u.getNumeroEtudiant());
            ps.executeUpdate();
        }
    }

    // Récupération par username
    public Utilisateur findByUsername(String username) {
        String sql = "SELECT * FROM utilisateurs WHERE username = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findByUsername " + username, e);
        }
        return null;
    }

    // Récupération par ID
    public Utilisateur findById(int id) {
        String sql = "SELECT * FROM utilisateurs WHERE id = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findById utilisateur", e);
        }
        return null;
    }

    // Mapping ResultSet → Utilisateur
    private Utilisateur map(ResultSet rs) throws SQLException {
        Utilisateur u = new Utilisateur();
        u.setId(rs.getInt("id"));
        u.setUsername(rs.getString("username"));
        u.setPassword(rs.getString("password"));
        u.setRole(rs.getString("role"));
        u.setPoste(rs.getString("poste"));
        u.setStatut(rs.getString("statut"));
        u.setNom(rs.getString("nom"));
        u.setPrenom(rs.getString("prenom"));
        u.setSexe(rs.getString("sexe"));
        u.setPhotoUrl(rs.getString("photo_url"));
        u.setFiliere(rs.getString("filiere"));
        u.setNumeroEtudiant(rs.getString("numero_etudiant"));
        return u;
    }

    // Mise à jour complète
    public void update(Utilisateur u) throws SQLException {
        String sql = "UPDATE utilisateurs SET username=?, password=?, role=?, statut=?, poste=?, nom=?, prenom=?, sexe=?, photo_url=?, filiere=?, numero_etudiant=? WHERE id=?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, u.getUsername());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getRole());
            ps.setString(4, u.getStatut());
            ps.setString(5, u.getPoste());
            ps.setString(6, u.getNom());
            ps.setString(7, u.getPrenom());
            ps.setString(8, u.getSexe());
            ps.setString(9, u.getPhotoUrl());
            ps.setString(10, u.getFiliere());
            ps.setString(11, u.getNumeroEtudiant());
            ps.setInt(12, u.getId());
            ps.executeUpdate();
        }
    }

    // Mise à jour du statut
    public void updateStatutByUserId(int userId, String newStatut) throws SQLException {
        String sql = "UPDATE utilisateurs SET statut = ? WHERE id = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, newStatut);
            ps.setInt(2, userId);
            ps.executeUpdate();
        }
    }

    // Promotion en étudiant validé
    public void promoteToEtudiantDeGasa(int userId) throws SQLException {
        String sql = "UPDATE utilisateurs SET role = 'etudiant_de_gasa', statut = 'validé' WHERE id = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.executeUpdate();
        }
    }

    // Récupération du statut
    public String getStatutByUsername(String username) {
        String sql = "SELECT statut FROM utilisateurs WHERE username = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String s = rs.getString("statut");
                    return (s != null) ? s.trim() : "en attente";
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur getStatutByUsername " + username, e);
        }
        return "en attente";
    }

    // Récupération de l'ID
    public Integer getIdByUsername(String username) {
        String sql = "SELECT id FROM utilisateurs WHERE username = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt("id");
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur getIdByUsername " + username, e);
        }
        return null;
    }

    // Ajout de notification
    public void addNotification(int userId, String message) throws SQLException {
        String sql = "INSERT INTO notifications(user_id, message, date_notif, lu) VALUES (?, ?, CURRENT_TIMESTAMP, false)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setString(2, message);
            ps.executeUpdate();
        }
    }
}

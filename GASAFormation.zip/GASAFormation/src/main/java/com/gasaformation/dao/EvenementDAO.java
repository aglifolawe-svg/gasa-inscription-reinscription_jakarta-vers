package com.gasaformation.dao;

import com.gasaformation.model.Evenement;

import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EvenementDAO {
    private static final Logger LOGGER = Logger.getLogger(EvenementDAO.class.getName());
    private final DataSource ds;

    public EvenementDAO() throws Exception {
        ds = (DataSource) new InitialContext().lookup("jdbc/gasaFormationPool");
    }

    // Insert: only the core fields; optional extras if needed
    public void insert(Evenement e) throws SQLException {
        String sql = "INSERT INTO evenements(titre, description, date_evenement, auteur_role, auteur_nom, cible) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, e.getTitre());
            ps.setString(2, e.getDescription());
            ps.setTimestamp(3, e.getDateEvenement() != null ? new Timestamp(e.getDateEvenement().getTime()) : null);
            ps.setString(4, e.getAuteurRole());
            ps.setString(5, e.getAuteurNom());
            ps.setString(6, e.getCible());
            ps.executeUpdate();
        }
    }

    public List<Evenement> findUpcoming() {
        String sql = "SELECT * FROM evenements WHERE date_evenement >= CURRENT_TIMESTAMP ORDER BY date_evenement ASC";
        List<Evenement> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findUpcoming evenements", e);
        }
        return list;
    }

    public List<Evenement> findAll() {
        String sql = "SELECT * FROM evenements ORDER BY date_evenement DESC";
        List<Evenement> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findAll evenements", e);
        }
        return list;
    }

    private Evenement map(ResultSet rs) throws SQLException {
        Evenement ev = new Evenement();
        ev.setId(rs.getInt("id"));
        ev.setTitre(rs.getString("titre"));
        ev.setDescription(rs.getString("description"));
        ev.setDateEvenement(rs.getTimestamp("date_evenement"));
        // Optional extras
        try { ev.setAuteurRole(rs.getString("auteur_role")); } catch (SQLException ignored) {}
        try { ev.setAuteurNom(rs.getString("auteur_nom")); } catch (SQLException ignored) {}
        try { ev.setCible(rs.getString("cible")); } catch (SQLException ignored) {}
        return ev;
    }
}

package com.gasaformation.dao;

import com.gasaformation.model.MatierePrincipale;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

public class MatierePrincipaleDAO {
    private final DataSource ds;

    public MatierePrincipaleDAO() throws Exception {
        ds = (DataSource) new InitialContext().lookup("jdbc/gasaFormationPool");
    }

    // 🔹 Récupérer toutes les matières principales
    public List<MatierePrincipale> findAll() throws SQLException {
        String sql = "SELECT id, code, libelle, coefficient, bac_serie_id FROM matieres_principales ORDER BY id";
        List<MatierePrincipale> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                MatierePrincipale m = new MatierePrincipale();
                m.setId(rs.getInt("id"));
                m.setCode(rs.getString("code"));
                m.setLibelle(rs.getString("libelle"));
                m.setCoef(rs.getDouble("coefficient"));
                m.setBacSerieId(rs.getInt("bac_serie_id"));
                list.add(m);
            }
        }
        return list;
    }

    // 🔹 Récupérer les matières d’une série de BAC spécifique
    public List<MatierePrincipale> findByBacSerie(int bacSerieId) throws SQLException {
        String sql = "SELECT id, code, libelle, coefficient, bac_serie_id " +
                     "FROM matieres_principales WHERE bac_serie_id = ? ORDER BY id";
        List<MatierePrincipale> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, bacSerieId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    MatierePrincipale m = new MatierePrincipale();
                    m.setId(rs.getInt("id"));
                    m.setCode(rs.getString("code"));
                    m.setLibelle(rs.getString("libelle"));
                    m.setCoef(rs.getDouble("coefficient"));
                    m.setBacSerieId(rs.getInt("bac_serie_id"));
                    
                    // 🔹 Log de debug
                System.out.println("[DEBUG] Matiere trouvée: " 
                    + m.getLibelle() + " (coef=" + m.getCoef() + ") pour série=" + bacSerieId);

                    list.add(m);
                }
            }
        }
        return list;
    }

    // 🔹 Récupérer une matière par son ID
    public MatierePrincipale findById(int id) throws SQLException {
        String sql = "SELECT id, code, libelle, coefficient, bac_serie_id FROM matieres_principales WHERE id = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    MatierePrincipale m = new MatierePrincipale();
                    m.setId(rs.getInt("id"));
                    m.setCode(rs.getString("code"));
                    m.setLibelle(rs.getString("libelle"));
                    m.setCoef(rs.getDouble("coefficient"));
                    m.setBacSerieId(rs.getInt("bac_serie_id"));
                    return m;
                }
            }
        }
        return null;
    }
}

package com.gasaformation.dao;

import com.gasaformation.model.Paiement;

import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PaiementDAO {
    private static final Logger LOGGER = Logger.getLogger(PaiementDAO.class.getName());
    private final DataSource ds;

    public PaiementDAO() throws Exception {
        ds = (DataSource) new InitialContext().lookup("jdbc/gasaFormationPool");
    }

    public void insert(Paiement p) throws SQLException {
        String sql = "INSERT INTO paiements(etudiant_id, montant, statut, date_paiement) VALUES (?, ?, ?, CURRENT_TIMESTAMP)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, p.getEtudiantId());
            ps.setBigDecimal(2, p.getMontant());
            ps.setString(3, p.getStatut());
            ps.executeUpdate();
        }
    }

    public List<Paiement> findByUsername(String username) {
        String sql = "SELECT p.* FROM paiements p JOIN utilisateurs u ON p.etudiant_id = u.id WHERE u.username = ? ORDER BY p.date_paiement DESC";
        List<Paiement> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findByUsername paiements", e);
        }
        return list;
    }

    public int countByStatut(String username, String statut) {
        String sql = "SELECT COUNT(*) FROM paiements p JOIN utilisateurs u ON p.etudiant_id = u.id WHERE u.username = ? AND LOWER(p.statut) = LOWER(?)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, statut);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur countByStatut paiements", e);
        }
        return 0;
    }

    public Map<String,Integer> countByStatutGrouped(String username) {
        String sql = "SELECT LOWER(p.statut) AS st, COUNT(*) AS cnt FROM paiements p JOIN utilisateurs u ON p.etudiant_id = u.id WHERE u.username = ? GROUP BY LOWER(p.statut)";
        Map<String,Integer> map = new HashMap<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) map.put(rs.getString("st"), rs.getInt("cnt"));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur countByStatutGrouped paiements", e);
        }
        return map;
    }

    public List<Paiement> findByStatut(String statut) {
        String sql = "SELECT * FROM paiements WHERE LOWER(statut) = LOWER(?) ORDER BY date_paiement DESC";
        List<Paiement> list = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, statut);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Erreur findByStatut paiements", e);
        }
        return list;
    }

    public void updateStatut(int paiementId, String newStatut) throws SQLException {
        String sql = "UPDATE paiements SET statut = ? WHERE id = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, newStatut);
            ps.setInt(2, paiementId);
            ps.executeUpdate();
        }
    }

    private Paiement map(ResultSet rs) throws SQLException {
        Paiement p = new Paiement();
        p.setId(rs.getInt("id"));
        p.setEtudiantId(rs.getInt("etudiant_id"));
        p.setMontant(rs.getBigDecimal("montant"));
        p.setStatut(rs.getString("statut"));
        p.setDatePaiement(rs.getTimestamp("date_paiement"));
        // recu_url optional in your DB; not required for core features
        return p;
    }
}

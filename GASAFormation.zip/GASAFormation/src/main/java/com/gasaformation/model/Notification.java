package com.gasaformation.model;

import java.util.Date;

public class Notification {
    private int id;
    private int userId;
    private String titre;       // ex: "Validation d'inscription"
    private String message;     // contenu détaillé
    private String type;        // INFO | SUCCESS | WARNING | ERROR | SYSTEM
    private String lien;        // lien vers la ressource (facultatif)
    private Date dateNotif;
    private boolean lu;

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getTitre() { return titre; }
    public void setTitre(String titre) { this.titre = titre; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getLien() { return lien; }
    public void setLien(String lien) { this.lien = lien; }

    public Date getDateNotif() { return dateNotif; }
    public void setDateNotif(Date dateNotif) { this.dateNotif = dateNotif; }

    public boolean isLu() { return lu; }
    public void setLu(boolean lu) { this.lu = lu; }
}

package com.gasaformation.model;

public class NoteBac {
    private int id;
    private int inscriptionId;     // FK vers inscriptions
    private int matierePrincipaleId; // FK vers matieres_principales
    private double note;           // 0..20
    private String matierePrincipaleLibelle;
    private double matierePrincipaleCoefficient;



    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getInscriptionId() { return inscriptionId; }
    public void setInscriptionId(int inscriptionId) { this.inscriptionId = inscriptionId; }

    public int getMatierePrincipaleId() { return matierePrincipaleId; }
    public void setMatierePrincipaleId(int matierePrincipaleId) { this.matierePrincipaleId = matierePrincipaleId; }

    public double getNote() { return note; }
    public void setNote(double note) { this.note = note; }
    
    public String getMatierePrincipaleLibelle() {
    return matierePrincipaleLibelle;
}
public void setMatierePrincipaleLibelle(String libelle) {
    this.matierePrincipaleLibelle = libelle;
}

public double getMatierePrincipaleCoefficient() {
    return matierePrincipaleCoefficient;
}
public void setMatierePrincipaleCoefficient(double coef) {
    this.matierePrincipaleCoefficient = coef;
}

}

package com.gasaformation.model;

import java.util.List;

/**
 * Correspondance avec la table criteres_admission:
 * - id (PK)
 * - filiere_id (FK -> filieres.id)
 * - niveau (si présent dans ta base)
 * - moyenne_minimum (numeric)
 * - document_id (FK -> documents.id)
 *
 * Champs applicatifs (non mappés directement en DB):
 * - titre, description, seriesCompatibles, matieresSeuils
 */
public class CritereAdmission {
    private int id;                 // PK
    private int filiereId;          // FK
    private String niveau;          // garder si ta table le contient
    private double moyenneMinimum;  // renomme pour coller à la DB
    private Integer documentId;     // FK vers documents, nullable

    // Champs applicatifs (non persistés directement)
    private transient String titre;
    private transient String description;
    private transient List<String> seriesCompatibles;
    private transient List<CritereMatiereSeuil> matieresSeuils;

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getFiliereId() { return filiereId; }
    public void setFiliereId(int filiereId) { this.filiereId = filiereId; }

    public String getNiveau() { return niveau; }
    public void setNiveau(String niveau) { this.niveau = niveau; }

    public double getMoyenneMinimum() { return moyenneMinimum; }
    public void setMoyenneMinimum(double moyenneMinimum) { this.moyenneMinimum = moyenneMinimum; }

    public Integer getDocumentId() { return documentId; }
    public void setDocumentId(Integer documentId) { this.documentId = documentId; }

    public String getTitre() { return titre; }
    public void setTitre(String titre) { this.titre = titre; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public List<String> getSeriesCompatibles() { return seriesCompatibles; }
    public void setSeriesCompatibles(List<String> seriesCompatibles) { this.seriesCompatibles = seriesCompatibles; }

    public List<CritereMatiereSeuil> getMatieresSeuils() { return matieresSeuils; }
    public void setMatieresSeuils(List<CritereMatiereSeuil> matieresSeuils) { this.matieresSeuils = matieresSeuils; }
}

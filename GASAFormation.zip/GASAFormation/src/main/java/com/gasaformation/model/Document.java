package com.gasaformation.model;

import java.util.Date;

public class Document {
    private int id;
    private int inscriptionId;
    private String type;       // ex: "CNI", "BAC", "Diplôme", "Relevé"
    private String filename;
    private String path;
    private Date dateUpload;

    // Getters / setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getInscriptionId() { return inscriptionId; }
    public void setInscriptionId(int inscriptionId) { this.inscriptionId = inscriptionId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getFilename() { return filename; }
    public void setFilename(String filename) { this.filename = filename; }

    public String getPath() { return path; }
    public void setPath(String path) { this.path = path; }

    public Date getDateUpload() { return dateUpload; }
    public void setDateUpload(Date dateUpload) { this.dateUpload = dateUpload; }
}

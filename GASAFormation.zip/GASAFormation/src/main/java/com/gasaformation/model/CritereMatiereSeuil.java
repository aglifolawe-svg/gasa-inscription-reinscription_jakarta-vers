package com.gasaformation.model;

/**
 * Correspondance avec la table critere_matieres:
 * - id (PK)
 * - critere_id (FK -> criteres_admission.id)
 * - soit matiere_code (varchar) soit matiere_principale_id (int) selon ton schéma exact
 * - note_min (numeric)
 * (Dans certaines captures on voit aussi filiere_id ou serie_code: ajouter si présent dans ta base)
 */
public class CritereMatiereSeuil {
    private int id;              // PK
    private int critereId;       // FK vers criteres_admission

    // Choisis l’un des deux selon ta base:
    private String matiereCode;      // si ton champ est "matiere_code"
    private Integer matiereId;       // si ton champ est "matiere_principale_id"

    private double noteMin;      // plancher requis (note_min)

    // Optionnels si présents dans ta table:
    private Integer filiereId;   // certains dumps montrent ce champ
    private String serieCode;    // si ta table relie le seuil à une série spécifique

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getCritereId() { return critereId; }
    public void setCritereId(int critereId) { this.critereId = critereId; }

    public String getMatiereCode() { return matiereCode; }
    public void setMatiereCode(String matiereCode) { this.matiereCode = matiereCode; }

    public Integer getMatiereId() { return matiereId; }
    public void setMatiereId(Integer matiereId) { this.matiereId = matiereId; }

    public double getNoteMin() { return noteMin; }
    public void setNoteMin(double noteMin) { this.noteMin = noteMin; }

    public Integer getFiliereId() { return filiereId; }
    public void setFiliereId(Integer filiereId) { this.filiereId = filiereId; }

    public String getSerieCode() { return serieCode; }
    public void setSerieCode(String serieCode) { this.serieCode = serieCode; }
}

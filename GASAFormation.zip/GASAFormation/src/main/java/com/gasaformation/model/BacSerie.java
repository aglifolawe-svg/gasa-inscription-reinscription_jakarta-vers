package com.gasaformation.model;

/**
 * Représente une série de BAC (ex: C, D, A1).
 * - id: clé technique (PK numérique), utilisée par bac_serie_id dans matieres_principales.
 * - code: clé “naturelle” (ex: "C"), utile pour l’affichage et les règles métier.
 * - libelle: nom lisible (ex: "Série C").
 */
public class BacSerie {
    private int id;         // PK technique en base (utilisée par les FKs)
    private String code;    // Code de série (ex: "C"), unique
    private String libelle; // Intitulé (ex: "Série C")

    // Getters & Setters simples
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getLibelle() { return libelle; }
    public void setLibelle(String libelle) { this.libelle = libelle; }

    /**
     * Confort: libellé à afficher. Si libelle est nul dans certaines bases,
     * tu pourras faire évoluer le DAO pour remplir libelle depuis "name".
     */
    public String getDisplayLabel() {
        return libelle != null ? libelle : code;
    }
}

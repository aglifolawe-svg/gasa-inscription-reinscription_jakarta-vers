package com.gasaformation.model;

import java.util.Date;

/**
 * Représente une pièce justificative liée à une inscription.
 * Correspond exactement aux colonnes de la table "justificatifs".
 */
public class Justificatif {
    private int id;               // PK
    private int inscriptionId;    // FK -> inscriptions.id
    private String type;          // PHOTO, ACTE_NAISSANCE, ATTESTATION_BAC, RELEVE_BAC, RELEVE_SEMESTRE
    private String filename;      // nom du fichier
    private String path;          // chemin de stockage
    private String mimeType;      // image/jpeg, application/pdf...
    private Date dateUpload;      // date d’upload

    // Champ applicatif optionnel (non stocké en base)
    private transient String statut; // en_attente | valide | invalide (transient = non persisté)

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getInscriptionId() { return inscriptionId; }
    public void setInscriptionId(int inscriptionId) { this.inscriptionId = inscriptionId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getFilename() { return filename; }
    public void setFilename(String filename) { this.filename = filename; }

    public String getPath() { return path; }
    public void setPath(String path) { this.path = path; }

    public String getMimeType() { return mimeType; }
    public void setMimeType(String mimeType) { this.mimeType = mimeType; }

    public Date getDateUpload() { return dateUpload; }
    public void setDateUpload(Date dateUpload) { this.dateUpload = dateUpload; }

    public String getStatut() { return statut; }
    public void setStatut(String statut) { this.statut = statut; }
}

package com.gasaformation.model;

public class Filiere {
    private int id;
    private String nom;
    private String ufr; // Unité de Formation et de Recherche

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public String getUfr() { return ufr; }
    public void setUfr(String ufr) { this.ufr = ufr; }
}

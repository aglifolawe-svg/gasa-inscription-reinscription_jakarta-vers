package com.gasaformation.model;

import java.util.Date;

public class Evenement {
    private int id;
    private String titre;
    private String description;
    private Date dateEvenement;

    // Optional extra columns in your DB
    private String auteurRole;
    private String auteurNom;
    private String cible;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitre() { return titre; }
    public void setTitre(String titre) { this.titre = titre; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Date getDateEvenement() { return dateEvenement; }
    public void setDateEvenement(Date dateEvenement) { this.dateEvenement = dateEvenement; }

    public String getAuteurRole() { return auteurRole; }
    public void setAuteurRole(String auteurRole) { this.auteurRole = auteurRole; }

    public String getAuteurNom() { return auteurNom; }
    public void setAuteurNom(String auteurNom) { this.auteurNom = auteurNom; }

    public String getCible() { return cible; }
    public void setCible(String cible) { this.cible = cible; }
}

package com.gasaformation.model;

public class MatierePrincipale {
    private int id;
    private String code;
    private String libelle;
    private double coef;
    private int bacSerieId;

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getLibelle() { return libelle; }
    public void setLibelle(String libelle) { this.libelle = libelle; }

    public double getCoef() { return coef; }
    public void setCoef(double coef) { this.coef = coef; }

    public int getBacSerieId() { return bacSerieId; }
    public void setBacSerieId(int bacSerieId) { this.bacSerieId = bacSerieId; }
}

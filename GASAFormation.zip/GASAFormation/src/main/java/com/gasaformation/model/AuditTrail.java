package com.gasaformation.model;

import java.util.Date;

public class AuditTrail {
    private int id;
    private String entity;       // ex: "Inscription", "Utilisateur"
    private int entityId;        // id de l’entité concernée
    private String action;       // CREATE, UPDATE, VALIDATE, REJECT, PREVALIDATE
    private int userId;          // qui a fait l’action
    private String commentaire;  // détail ou motif
    private Date dateAction;

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getEntity() { return entity; }
    public void setEntity(String entity) { this.entity = entity; }

    public int getEntityId() { return entityId; }
    public void setEntityId(int entityId) { this.entityId = entityId; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getCommentaire() { return commentaire; }
    public void setCommentaire(String commentaire) { this.commentaire = commentaire; }

    public Date getDateAction() { return dateAction; }
    public void setDateAction(Date dateAction) { this.dateAction = dateAction; }
}

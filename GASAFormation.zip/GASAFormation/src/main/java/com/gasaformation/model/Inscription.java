package com.gasaformation.model;

import java.util.Date;

public class Inscription {
    // Identifiant technique
    private int id;

    // Lien vers l'étudiant (FK inscriptions.etudiant_id)
    private int etudiantId;

    // Lien vers la filière (FK inscriptions.filiere_id)
    private int filiereId;

    // Nom de la filière (colonne texte dans inscriptions, alimentée par trigger ou DAO)
    private String filiere;

    // Métadonnées d'inscription
    private String niveau;          // L1/L2/L3/M1/M2
    private String type;            // inscription | réinscription | admission parallèle
    private String statut;          // en attente | validé | rejete
    private Date dateInscription;   // date_inscription (timestamp/date)

    // Données académiques
    private String serieBac;        // serie_bac (ex: C, D, A1...)
    private String diplome;         // ex: "BAC"
    private int anneeObtention;     // année du BAC
    private String etablissementOrigine;

    // Champs complémentaires
    private String mention;         // mention (text) en base
    private String commentaire;     // feedback système/secrétaire (optionnel)
    private Double moyenneBac;      // moyenne_bac (calculée à partir des notes)

    // (Optionnel) si tu veux toujours afficher le nom: non mappé direct à la DB
    private String filiereNom;      // pratique pour la vue, alimenté via jointure DAO

    // Getters & Setters (simples et directs)

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getEtudiantId() { return etudiantId; }
    public void setEtudiantId(int etudiantId) { this.etudiantId = etudiantId; }

    public int getFiliereId() { return filiereId; }
    public void setFiliereId(int filiereId) { this.filiereId = filiereId; }

    public String getFiliere() { return filiere; }
    public void setFiliere(String filiere) { this.filiere = filiere; }

    public String getNiveau() { return niveau; }
    public void setNiveau(String niveau) { this.niveau = niveau; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getStatut() { return statut; }
    public void setStatut(String statut) { this.statut = statut; }

    public Date getDateInscription() { return dateInscription; }
    public void setDateInscription(Date dateInscription) { this.dateInscription = dateInscription; }

    public String getSerieBac() { return serieBac; }
    public void setSerieBac(String serieBac) { this.serieBac = serieBac; }

    public String getDiplome() { return diplome; }
    public void setDiplome(String diplome) { this.diplome = diplome; }

    public int getAnneeObtention() { return anneeObtention; }
    public void setAnneeObtention(int anneeObtention) { this.anneeObtention = anneeObtention; }

    public String getEtablissementOrigine() { return etablissementOrigine; }
    public void setEtablissementOrigine(String etablissementOrigine) { this.etablissementOrigine = etablissementOrigine; }

    public String getMention() { return mention; }
    public void setMention(String mention) { this.mention = mention; }

    public String getCommentaire() { return commentaire; }
    public void setCommentaire(String commentaire) { this.commentaire = commentaire; }

    public Double getMoyenneBac() { return moyenneBac; }
    public void setMoyenneBac(Double moyenneBac) { this.moyenneBac = moyenneBac; }

    public String getFiliereNom() { return filiereNom; }
    public void setFiliereNom(String filiereNom) { this.filiereNom = filiereNom; }
}

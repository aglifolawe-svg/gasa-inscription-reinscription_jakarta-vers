package com.mycompany.authentificationapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.Principal;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet démonstratif JAAS avec GlassFish.
 * -----------------------------------------
 * Objectifs :
 * - Utiliser JAAS (via le realm JDBC configuré dans GlassFish)
 *   pour savoir quel utilisateur est connecté et quels rôles il possède.
 * - Afficher les informations de l’utilisateur et ses rôles.
 *
 * Toute la logique d’authentification est gérée par le conteneur (GlassFish).
 */
@WebServlet(name = "HelloServlet", urlPatterns = {"/HelloServlet"})
public class HelloServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {

            out.println("<!DOCTYPE html>");
            out.println("<html><head><title>Démo JAAS avec GlassFish</title></head><body>");

            // JAAS : récupération de l'utilisateur connecté
            Principal user = request.getUserPrincipal();

            if (user != null) {
                out.println("<h2>✅ Utilisateur connecté : " + user.getName() + "</h2>");

                // Vérification des rôles via JAAS
                out.println("<h3>Rôles attribués :</h3>");
                if (request.isUserInRole("admin")) {
                    out.println("<p>✔ Rôle : <b>admin</b></p>");
                }
                if (request.isUserInRole("user")) {
                    out.println("<p>✔ Rôle : <b>user</b></p>");
                }

            } else {
                out.println("<h2>❌ Aucun utilisateur connecté</h2>");
                out.println("<p>Essayez de vous connecter via JAAS (GlassFish demandera un login).</p>");
            }

            out.println("</body></html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet démonstratif JAAS avec GlassFish (realm JDBC)";
    }
}

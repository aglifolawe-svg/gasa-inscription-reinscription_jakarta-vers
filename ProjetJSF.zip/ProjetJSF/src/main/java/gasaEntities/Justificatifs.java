/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "justificatifs")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Justificatifs.findAll", query = "SELECT j FROM Justificatifs j"),
    @NamedQuery(name = "Justificatifs.findById", query = "SELECT j FROM Justificatifs j WHERE j.id = :id"),
    @NamedQuery(name = "Justificatifs.findByType", query = "SELECT j FROM Justificatifs j WHERE j.type = :type"),
    @NamedQuery(name = "Justificatifs.findByFilename", query = "SELECT j FROM Justificatifs j WHERE j.filename = :filename"),
    @NamedQuery(name = "Justificatifs.findByPath", query = "SELECT j FROM Justificatifs j WHERE j.path = :path"),
    @NamedQuery(name = "Justificatifs.findByMimeType", query = "SELECT j FROM Justificatifs j WHERE j.mimeType = :mimeType"),
    @NamedQuery(name = "Justificatifs.findByStatut", query = "SELECT j FROM Justificatifs j WHERE j.statut = :statut"),
    @NamedQuery(name = "Justificatifs.findByDateUpload", query = "SELECT j FROM Justificatifs j WHERE j.dateUpload = :dateUpload")})
public class Justificatifs implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "type")
    private String type;
    @Size(max = 255)
    @Column(name = "filename")
    private String filename;
    @Size(max = 255)
    @Column(name = "path")
    private String path;
    @Size(max = 100)
    @Column(name = "mime_type")
    private String mimeType;
    @Size(max = 20)
    @Column(name = "statut")
    private String statut;
    @Column(name = "date_upload")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateUpload;
    @JoinColumn(name = "inscription_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Inscriptions inscriptionId;

    public Justificatifs() {
    }

    public Justificatifs(Integer id) {
        this.id = id;
    }

    public Justificatifs(Integer id, String type) {
        this.id = id;
        this.type = type;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public Date getDateUpload() {
        return dateUpload;
    }

    public void setDateUpload(Date dateUpload) {
        this.dateUpload = dateUpload;
    }

    public Inscriptions getInscriptionId() {
        return inscriptionId;
    }

    public void setInscriptionId(Inscriptions inscriptionId) {
        this.inscriptionId = inscriptionId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Justificatifs)) {
            return false;
        }
        Justificatifs other = (Justificatifs) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.Justificatifs[ id=" + id + " ]";
    }
    
}

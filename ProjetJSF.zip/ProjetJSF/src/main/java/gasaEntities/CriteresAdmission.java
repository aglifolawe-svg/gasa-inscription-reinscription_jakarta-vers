/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "criteres_admission")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CriteresAdmission.findAll", query = "SELECT c FROM CriteresAdmission c"),
    @NamedQuery(name = "CriteresAdmission.findById", query = "SELECT c FROM CriteresAdmission c WHERE c.id = :id"),
    @NamedQuery(name = "CriteresAdmission.findByNiveau", query = "SELECT c FROM CriteresAdmission c WHERE c.niveau = :niveau"),
    @NamedQuery(name = "CriteresAdmission.findByMoyenneMinimum", query = "SELECT c FROM CriteresAdmission c WHERE c.moyenneMinimum = :moyenneMinimum"),
    @NamedQuery(name = "CriteresAdmission.findByActif", query = "SELECT c FROM CriteresAdmission c WHERE c.actif = :actif")})
public class CriteresAdmission implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "niveau")
    private String niveau;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Column(name = "moyenne_minimum")
    private BigDecimal moyenneMinimum;
    @Column(name = "actif")
    private Boolean actif;
    @JoinColumn(name = "filiere", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Filieres filiere;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "critereId1")
    private List<CritereMatieres> critereMatieresList;

    public CriteresAdmission() {
    }

    public CriteresAdmission(Integer id) {
        this.id = id;
    }

    public CriteresAdmission(Integer id, String niveau, BigDecimal moyenneMinimum) {
        this.id = id;
        this.niveau = niveau;
        this.moyenneMinimum = moyenneMinimum;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNiveau() {
        return niveau;
    }

    public void setNiveau(String niveau) {
        this.niveau = niveau;
    }

    public BigDecimal getMoyenneMinimum() {
        return moyenneMinimum;
    }

    public void setMoyenneMinimum(BigDecimal moyenneMinimum) {
        this.moyenneMinimum = moyenneMinimum;
    }

    public Boolean getActif() {
        return actif;
    }

    public void setActif(Boolean actif) {
        this.actif = actif;
    }

    public Filieres getFiliere() {
        return filiere;
    }

    public void setFiliere(Filieres filiere) {
        this.filiere = filiere;
    }

    @XmlTransient
    public List<CritereMatieres> getCritereMatieresList() {
        return critereMatieresList;
    }

    public void setCritereMatieresList(List<CritereMatieres> critereMatieresList) {
        this.critereMatieresList = critereMatieresList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CriteresAdmission)) {
            return false;
        }
        CriteresAdmission other = (CriteresAdmission) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.CriteresAdmission[ id=" + id + " ]";
    }
    
}

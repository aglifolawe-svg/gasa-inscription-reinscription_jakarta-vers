/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.Size;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "evenements")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Evenements.findAll", query = "SELECT e FROM Evenements e"),
    @NamedQuery(name = "Evenements.findById", query = "SELECT e FROM Evenements e WHERE e.id = :id"),
    @NamedQuery(name = "Evenements.findByTitre", query = "SELECT e FROM Evenements e WHERE e.titre = :titre"),
    @NamedQuery(name = "Evenements.findByDescription", query = "SELECT e FROM Evenements e WHERE e.description = :description"),
    @NamedQuery(name = "Evenements.findByDateEvenement", query = "SELECT e FROM Evenements e WHERE e.dateEvenement = :dateEvenement"),
    @NamedQuery(name = "Evenements.findByAuteurRole", query = "SELECT e FROM Evenements e WHERE e.auteurRole = :auteurRole"),
    @NamedQuery(name = "Evenements.findByAuteurNom", query = "SELECT e FROM Evenements e WHERE e.auteurNom = :auteurNom"),
    @NamedQuery(name = "Evenements.findByCible", query = "SELECT e FROM Evenements e WHERE e.cible = :cible")})
public class Evenements implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Size(max = 255)
    @Column(name = "titre")
    private String titre;
    @Size(max = 2147483647)
    @Column(name = "description")
    private String description;
    @Column(name = "date_evenement")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateEvenement;
    @Size(max = 50)
    @Column(name = "auteur_role")
    private String auteurRole;
    @Size(max = 100)
    @Column(name = "auteur_nom")
    private String auteurNom;
    @Size(max = 50)
    @Column(name = "cible")
    private String cible;

    public Evenements() {
    }

    public Evenements(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDateEvenement() {
        return dateEvenement;
    }

    public void setDateEvenement(Date dateEvenement) {
        this.dateEvenement = dateEvenement;
    }

    public String getAuteurRole() {
        return auteurRole;
    }

    public void setAuteurRole(String auteurRole) {
        this.auteurRole = auteurRole;
    }

    public String getAuteurNom() {
        return auteurNom;
    }

    public void setAuteurNom(String auteurNom) {
        this.auteurNom = auteurNom;
    }

    public String getCible() {
        return cible;
    }

    public void setCible(String cible) {
        this.cible = cible;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Evenements)) {
            return false;
        }
        Evenements other = (Evenements) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.Evenements[ id=" + id + " ]";
    }
    
}

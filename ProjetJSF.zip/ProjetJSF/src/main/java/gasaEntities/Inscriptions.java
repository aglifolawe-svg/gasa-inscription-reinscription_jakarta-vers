/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "inscriptions")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Inscriptions.findAll", query = "SELECT i FROM Inscriptions i"),
    @NamedQuery(name = "Inscriptions.findById", query = "SELECT i FROM Inscriptions i WHERE i.id = :id"),
    @NamedQuery(name = "Inscriptions.findByFiliere", query = "SELECT i FROM Inscriptions i WHERE i.filiere = :filiere"),
    @NamedQuery(name = "Inscriptions.findByNiveau", query = "SELECT i FROM Inscriptions i WHERE i.niveau = :niveau"),
    @NamedQuery(name = "Inscriptions.findByType", query = "SELECT i FROM Inscriptions i WHERE i.type = :type"),
    @NamedQuery(name = "Inscriptions.findByStatut", query = "SELECT i FROM Inscriptions i WHERE i.statut = :statut"),
    @NamedQuery(name = "Inscriptions.findByDateInscription", query = "SELECT i FROM Inscriptions i WHERE i.dateInscription = :dateInscription"),
    @NamedQuery(name = "Inscriptions.findBySerieBac", query = "SELECT i FROM Inscriptions i WHERE i.serieBac = :serieBac"),
    @NamedQuery(name = "Inscriptions.findByDiplome", query = "SELECT i FROM Inscriptions i WHERE i.diplome = :diplome"),
    @NamedQuery(name = "Inscriptions.findByAnneeObtention", query = "SELECT i FROM Inscriptions i WHERE i.anneeObtention = :anneeObtention"),
    @NamedQuery(name = "Inscriptions.findByEtablissementOrigine", query = "SELECT i FROM Inscriptions i WHERE i.etablissementOrigine = :etablissementOrigine"),
    @NamedQuery(name = "Inscriptions.findByCommentaire", query = "SELECT i FROM Inscriptions i WHERE i.commentaire = :commentaire"),
    @NamedQuery(name = "Inscriptions.findByMoyenneBac", query = "SELECT i FROM Inscriptions i WHERE i.moyenneBac = :moyenneBac"),
    @NamedQuery(name = "Inscriptions.findByMention", query = "SELECT i FROM Inscriptions i WHERE i.mention = :mention"),
    @NamedQuery(name = "Inscriptions.findByValidePar", query = "SELECT i FROM Inscriptions i WHERE i.validePar = :validePar")})
public class Inscriptions implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Size(max = 100)
    @Column(name = "filiere")
    private String filiere;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "niveau")
    private String niveau;
    @Size(max = 50)
    @Column(name = "type")
    private String type;
    @Size(max = 20)
    @Column(name = "statut")
    private String statut;
    @Column(name = "date_inscription")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateInscription;
    @Size(max = 10)
    @Column(name = "serie_bac")
    private String serieBac;
    @Size(max = 100)
    @Column(name = "diplome")
    private String diplome;
    @Column(name = "annee_obtention")
    private Integer anneeObtention;
    @Size(max = 150)
    @Column(name = "etablissement_origine")
    private String etablissementOrigine;
    @Size(max = 2147483647)
    @Column(name = "commentaire")
    private String commentaire;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "moyenne_bac")
    private BigDecimal moyenneBac;
    @Size(max = 55)
    @Column(name = "mention")
    private String mention;
    @Size(max = 64)
    @Column(name = "valide_par")
    private String validePar;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "inscriptionId")
    private List<Documents> documentsList;
    @JoinColumn(name = "filiere_id", referencedColumnName = "id")
    @ManyToOne
    private Filieres filiereId;
    @JoinColumn(name = "etudiant_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Utilisateurs etudiantId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "inscriptionId")
    private List<Justificatifs> justificatifsList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "inscriptionId")
    private List<NotesBac> notesBacList;

    public Inscriptions() {
    }

    public Inscriptions(Integer id) {
        this.id = id;
    }

    public Inscriptions(Integer id, String niveau) {
        this.id = id;
        this.niveau = niveau;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFiliere() {
        return filiere;
    }

    public void setFiliere(String filiere) {
        this.filiere = filiere;
    }

    public String getNiveau() {
        return niveau;
    }

    public void setNiveau(String niveau) {
        this.niveau = niveau;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public Date getDateInscription() {
        return dateInscription;
    }

    public void setDateInscription(Date dateInscription) {
        this.dateInscription = dateInscription;
    }

    public String getSerieBac() {
        return serieBac;
    }

    public void setSerieBac(String serieBac) {
        this.serieBac = serieBac;
    }

    public String getDiplome() {
        return diplome;
    }

    public void setDiplome(String diplome) {
        this.diplome = diplome;
    }

    public Integer getAnneeObtention() {
        return anneeObtention;
    }

    public void setAnneeObtention(Integer anneeObtention) {
        this.anneeObtention = anneeObtention;
    }

    public String getEtablissementOrigine() {
        return etablissementOrigine;
    }

    public void setEtablissementOrigine(String etablissementOrigine) {
        this.etablissementOrigine = etablissementOrigine;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public BigDecimal getMoyenneBac() {
        return moyenneBac;
    }

    public void setMoyenneBac(BigDecimal moyenneBac) {
        this.moyenneBac = moyenneBac;
    }

    public String getMention() {
        return mention;
    }

    public void setMention(String mention) {
        this.mention = mention;
    }

    public String getValidePar() {
        return validePar;
    }

    public void setValidePar(String validePar) {
        this.validePar = validePar;
    }

    @XmlTransient
    public List<Documents> getDocumentsList() {
        return documentsList;
    }

    public void setDocumentsList(List<Documents> documentsList) {
        this.documentsList = documentsList;
    }

    public Filieres getFiliereId() {
        return filiereId;
    }

    public void setFiliereId(Filieres filiereId) {
        this.filiereId = filiereId;
    }

    public Utilisateurs getEtudiantId() {
        return etudiantId;
    }

    public void setEtudiantId(Utilisateurs etudiantId) {
        this.etudiantId = etudiantId;
    }

    @XmlTransient
    public List<Justificatifs> getJustificatifsList() {
        return justificatifsList;
    }

    public void setJustificatifsList(List<Justificatifs> justificatifsList) {
        this.justificatifsList = justificatifsList;
    }

    @XmlTransient
    public List<NotesBac> getNotesBacList() {
        return notesBacList;
    }

    public void setNotesBacList(List<NotesBac> notesBacList) {
        this.notesBacList = notesBacList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Inscriptions)) {
            return false;
        }
        Inscriptions other = (Inscriptions) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.Inscriptions[ id=" + id + " ]";
    }
    
}

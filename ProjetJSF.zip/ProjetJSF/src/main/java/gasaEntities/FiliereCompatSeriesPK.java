/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;

/**
 *
 * @author folaw
 */
@Embeddable
public class FiliereCompatSeriesPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "filiere_id")
    private int filiereId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "serie_code")
    private String serieCode;

    public FiliereCompatSeriesPK() {
    }

    public FiliereCompatSeriesPK(int filiereId, String serieCode) {
        this.filiereId = filiereId;
        this.serieCode = serieCode;
    }

    public int getFiliereId() {
        return filiereId;
    }

    public void setFiliereId(int filiereId) {
        this.filiereId = filiereId;
    }

    public String getSerieCode() {
        return serieCode;
    }

    public void setSerieCode(String serieCode) {
        this.serieCode = serieCode;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) filiereId;
        hash += (serieCode != null ? serieCode.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FiliereCompatSeriesPK)) {
            return false;
        }
        FiliereCompatSeriesPK other = (FiliereCompatSeriesPK) object;
        if (this.filiereId != other.filiereId) {
            return false;
        }
        if ((this.serieCode == null && other.serieCode != null) || (this.serieCode != null && !this.serieCode.equals(other.serieCode))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.FiliereCompatSeriesPK[ filiereId=" + filiereId + ", serieCode=" + serieCode + " ]";
    }
    
}

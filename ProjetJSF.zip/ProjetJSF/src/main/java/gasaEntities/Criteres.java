/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "criteres")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Criteres.findAll", query = "SELECT c FROM Criteres c"),
    @NamedQuery(name = "Criteres.findById", query = "SELECT c FROM Criteres c WHERE c.id = :id")})
public class Criteres implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "critereId")
    private List<CritereMatieres> critereMatieresList;
    @JoinColumn(name = "filiere_id", referencedColumnName = "id")
    @ManyToOne
    private Filieres filiereId;

    public Criteres() {
    }

    public Criteres(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @XmlTransient
    public List<CritereMatieres> getCritereMatieresList() {
        return critereMatieresList;
    }

    public void setCritereMatieresList(List<CritereMatieres> critereMatieresList) {
        this.critereMatieresList = critereMatieresList;
    }

    public Filieres getFiliereId() {
        return filiereId;
    }

    public void setFiliereId(Filieres filiereId) {
        this.filiereId = filiereId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Criteres)) {
            return false;
        }
        Criteres other = (Criteres) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.Criteres[ id=" + id + " ]";
    }
    
}

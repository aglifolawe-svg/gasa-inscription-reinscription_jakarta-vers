/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "emplois_du_temps")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "EmploisDuTemps.findAll", query = "SELECT e FROM EmploisDuTemps e"),
    @NamedQuery(name = "EmploisDuTemps.findById", query = "SELECT e FROM EmploisDuTemps e WHERE e.id = :id"),
    @NamedQuery(name = "EmploisDuTemps.findByDateCours", query = "SELECT e FROM EmploisDuTemps e WHERE e.dateCours = :dateCours"),
    @NamedQuery(name = "EmploisDuTemps.findByMatiere", query = "SELECT e FROM EmploisDuTemps e WHERE e.matiere = :matiere"),
    @NamedQuery(name = "EmploisDuTemps.findByProfesseur", query = "SELECT e FROM EmploisDuTemps e WHERE e.professeur = :professeur"),
    @NamedQuery(name = "EmploisDuTemps.findByGroupe", query = "SELECT e FROM EmploisDuTemps e WHERE e.groupe = :groupe"),
    @NamedQuery(name = "EmploisDuTemps.findBySite", query = "SELECT e FROM EmploisDuTemps e WHERE e.site = :site"),
    @NamedQuery(name = "EmploisDuTemps.findByHeureDebut", query = "SELECT e FROM EmploisDuTemps e WHERE e.heureDebut = :heureDebut"),
    @NamedQuery(name = "EmploisDuTemps.findByHeureFin", query = "SELECT e FROM EmploisDuTemps e WHERE e.heureFin = :heureFin"),
    @NamedQuery(name = "EmploisDuTemps.findByStatut", query = "SELECT e FROM EmploisDuTemps e WHERE e.statut = :statut"),
    @NamedQuery(name = "EmploisDuTemps.findByCommentaire", query = "SELECT e FROM EmploisDuTemps e WHERE e.commentaire = :commentaire"),
    @NamedQuery(name = "EmploisDuTemps.findByDateCreation", query = "SELECT e FROM EmploisDuTemps e WHERE e.dateCreation = :dateCreation")})
public class EmploisDuTemps implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "date_cours")
    @Temporal(TemporalType.DATE)
    private Date dateCours;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "matiere")
    private String matiere;
    @Size(max = 100)
    @Column(name = "professeur")
    private String professeur;
    @Size(max = 50)
    @Column(name = "groupe")
    private String groupe;
    @Size(max = 100)
    @Column(name = "site")
    private String site;
    @Column(name = "heure_debut")
    @Temporal(TemporalType.TIME)
    private Date heureDebut;
    @Column(name = "heure_fin")
    @Temporal(TemporalType.TIME)
    private Date heureFin;
    @Size(max = 20)
    @Column(name = "statut")
    private String statut;
    @Size(max = 255)
    @Column(name = "commentaire")
    private String commentaire;
    @Column(name = "date_creation")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreation;

    public EmploisDuTemps() {
    }

    public EmploisDuTemps(Integer id) {
        this.id = id;
    }

    public EmploisDuTemps(Integer id, Date dateCours, String matiere) {
        this.id = id;
        this.dateCours = dateCours;
        this.matiere = matiere;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDateCours() {
        return dateCours;
    }

    public void setDateCours(Date dateCours) {
        this.dateCours = dateCours;
    }

    public String getMatiere() {
        return matiere;
    }

    public void setMatiere(String matiere) {
        this.matiere = matiere;
    }

    public String getProfesseur() {
        return professeur;
    }

    public void setProfesseur(String professeur) {
        this.professeur = professeur;
    }

    public String getGroupe() {
        return groupe;
    }

    public void setGroupe(String groupe) {
        this.groupe = groupe;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public Date getHeureDebut() {
        return heureDebut;
    }

    public void setHeureDebut(Date heureDebut) {
        this.heureDebut = heureDebut;
    }

    public Date getHeureFin() {
        return heureFin;
    }

    public void setHeureFin(Date heureFin) {
        this.heureFin = heureFin;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public Date getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EmploisDuTemps)) {
            return false;
        }
        EmploisDuTemps other = (EmploisDuTemps) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.EmploisDuTemps[ id=" + id + " ]";
    }
    
}

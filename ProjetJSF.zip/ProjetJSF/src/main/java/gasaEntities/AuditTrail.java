/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "audit_trail")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "AuditTrail.findAll", query = "SELECT a FROM AuditTrail a"),
    @NamedQuery(name = "AuditTrail.findById", query = "SELECT a FROM AuditTrail a WHERE a.id = :id"),
    @NamedQuery(name = "AuditTrail.findByEntity", query = "SELECT a FROM AuditTrail a WHERE a.entity = :entity"),
    @NamedQuery(name = "AuditTrail.findByEntityId", query = "SELECT a FROM AuditTrail a WHERE a.entityId = :entityId"),
    @NamedQuery(name = "AuditTrail.findByAction", query = "SELECT a FROM AuditTrail a WHERE a.action = :action"),
    @NamedQuery(name = "AuditTrail.findByUserId", query = "SELECT a FROM AuditTrail a WHERE a.userId = :userId"),
    @NamedQuery(name = "AuditTrail.findByCommentaire", query = "SELECT a FROM AuditTrail a WHERE a.commentaire = :commentaire"),
    @NamedQuery(name = "AuditTrail.findByDateAction", query = "SELECT a FROM AuditTrail a WHERE a.dateAction = :dateAction")})
public class AuditTrail implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "entity")
    private String entity;
    @Basic(optional = false)
    @NotNull
    @Column(name = "entity_id")
    private int entityId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "action")
    private String action;
    @Basic(optional = false)
    @NotNull
    @Column(name = "user_id")
    private int userId;
    @Size(max = 2147483647)
    @Column(name = "commentaire")
    private String commentaire;
    @Column(name = "date_action")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateAction;

    public AuditTrail() {
    }

    public AuditTrail(Integer id) {
        this.id = id;
    }

    public AuditTrail(Integer id, String entity, int entityId, String action, int userId) {
        this.id = id;
        this.entity = entity;
        this.entityId = entityId;
        this.action = action;
        this.userId = userId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEntity() {
        return entity;
    }

    public void setEntity(String entity) {
        this.entity = entity;
    }

    public int getEntityId() {
        return entityId;
    }

    public void setEntityId(int entityId) {
        this.entityId = entityId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public Date getDateAction() {
        return dateAction;
    }

    public void setDateAction(Date dateAction) {
        this.dateAction = dateAction;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AuditTrail)) {
            return false;
        }
        AuditTrail other = (AuditTrail) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.AuditTrail[ id=" + id + " ]";
    }
    
}

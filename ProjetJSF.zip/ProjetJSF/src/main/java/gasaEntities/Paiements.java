/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "paiements")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Paiements.findAll", query = "SELECT p FROM Paiements p"),
    @NamedQuery(name = "Paiements.findById", query = "SELECT p FROM Paiements p WHERE p.id = :id"),
    @NamedQuery(name = "Paiements.findByMontant", query = "SELECT p FROM Paiements p WHERE p.montant = :montant"),
    @NamedQuery(name = "Paiements.findByStatut", query = "SELECT p FROM Paiements p WHERE p.statut = :statut"),
    @NamedQuery(name = "Paiements.findByDatePaiement", query = "SELECT p FROM Paiements p WHERE p.datePaiement = :datePaiement"),
    @NamedQuery(name = "Paiements.findByCommentaire", query = "SELECT p FROM Paiements p WHERE p.commentaire = :commentaire")})
public class Paiements implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Column(name = "montant")
    private BigDecimal montant;
    @Size(max = 20)
    @Column(name = "statut")
    private String statut;
    @Column(name = "date_paiement")
    @Temporal(TemporalType.TIMESTAMP)
    private Date datePaiement;
    @Size(max = 2147483647)
    @Column(name = "commentaire")
    private String commentaire;
    @JoinColumn(name = "etudiant_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Utilisateurs etudiantId;

    public Paiements() {
    }

    public Paiements(Integer id) {
        this.id = id;
    }

    public Paiements(Integer id, BigDecimal montant) {
        this.id = id;
        this.montant = montant;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public BigDecimal getMontant() {
        return montant;
    }

    public void setMontant(BigDecimal montant) {
        this.montant = montant;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public Date getDatePaiement() {
        return datePaiement;
    }

    public void setDatePaiement(Date datePaiement) {
        this.datePaiement = datePaiement;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public Utilisateurs getEtudiantId() {
        return etudiantId;
    }

    public void setEtudiantId(Utilisateurs etudiantId) {
        this.etudiantId = etudiantId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Paiements)) {
            return false;
        }
        Paiements other = (Paiements) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.Paiements[ id=" + id + " ]";
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "utilisateurs")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Utilisateurs.findAll", query = "SELECT u FROM Utilisateurs u"),
    @NamedQuery(name = "Utilisateurs.findById", query = "SELECT u FROM Utilisateurs u WHERE u.id = :id"),
    @NamedQuery(name = "Utilisateurs.findByUsername", query = "SELECT u FROM Utilisateurs u WHERE u.username = :username"),
    @NamedQuery(name = "Utilisateurs.findByPassword", query = "SELECT u FROM Utilisateurs u WHERE u.password = :password"),
    @NamedQuery(name = "Utilisateurs.findByRole", query = "SELECT u FROM Utilisateurs u WHERE u.role = :role"),
    @NamedQuery(name = "Utilisateurs.findByPoste", query = "SELECT u FROM Utilisateurs u WHERE u.poste = :poste"),
    @NamedQuery(name = "Utilisateurs.findByStatut", query = "SELECT u FROM Utilisateurs u WHERE u.statut = :statut"),
    @NamedQuery(name = "Utilisateurs.findByNom", query = "SELECT u FROM Utilisateurs u WHERE u.nom = :nom"),
    @NamedQuery(name = "Utilisateurs.findByPrenom", query = "SELECT u FROM Utilisateurs u WHERE u.prenom = :prenom"),
    @NamedQuery(name = "Utilisateurs.findBySexe", query = "SELECT u FROM Utilisateurs u WHERE u.sexe = :sexe"),
    @NamedQuery(name = "Utilisateurs.findByCommentaire", query = "SELECT u FROM Utilisateurs u WHERE u.commentaire = :commentaire"),
    @NamedQuery(name = "Utilisateurs.findByPhotoUrl", query = "SELECT u FROM Utilisateurs u WHERE u.photoUrl = :photoUrl"),
    @NamedQuery(name = "Utilisateurs.findByFiliere", query = "SELECT u FROM Utilisateurs u WHERE u.filiere = :filiere"),
    @NamedQuery(name = "Utilisateurs.findByNumeroEtudiant", query = "SELECT u FROM Utilisateurs u WHERE u.numeroEtudiant = :numeroEtudiant")})
public class Utilisateurs implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "username")
    private String username;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "password")
    private String password;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "role")
    private String role;
    @Size(max = 100)
    @Column(name = "poste")
    private String poste;
    @Size(max = 20)
    @Column(name = "statut")
    private String statut;
    @Size(max = 100)
    @Column(name = "nom")
    private String nom;
    @Size(max = 100)
    @Column(name = "prenom")
    private String prenom;
    @Size(max = 10)
    @Column(name = "sexe")
    private String sexe;
    @Size(max = 2147483647)
    @Column(name = "commentaire")
    private String commentaire;
    @Size(max = 255)
    @Column(name = "photo_url")
    private String photoUrl;
    @Size(max = 100)
    @Column(name = "filiere")
    private String filiere;
    @Size(max = 50)
    @Column(name = "numero_etudiant")
    private String numeroEtudiant;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "etudiantId")
    private List<Inscriptions> inscriptionsList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "utilisateurId")
    private List<Etudiants> etudiantsList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "etudiantId")
    private List<Paiements> paiementsList;

    public Utilisateurs() {
    }

    public Utilisateurs(Integer id) {
        this.id = id;
    }

    public Utilisateurs(Integer id, String username, String password, String role) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getPoste() {
        return poste;
    }

    public void setPoste(String poste) {
        this.poste = poste;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getSexe() {
        return sexe;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public String getFiliere() {
        return filiere;
    }

    public void setFiliere(String filiere) {
        this.filiere = filiere;
    }

    public String getNumeroEtudiant() {
        return numeroEtudiant;
    }

    public void setNumeroEtudiant(String numeroEtudiant) {
        this.numeroEtudiant = numeroEtudiant;
    }

    @XmlTransient
    public List<Inscriptions> getInscriptionsList() {
        return inscriptionsList;
    }

    public void setInscriptionsList(List<Inscriptions> inscriptionsList) {
        this.inscriptionsList = inscriptionsList;
    }

    @XmlTransient
    public List<Etudiants> getEtudiantsList() {
        return etudiantsList;
    }

    public void setEtudiantsList(List<Etudiants> etudiantsList) {
        this.etudiantsList = etudiantsList;
    }

    @XmlTransient
    public List<Paiements> getPaiementsList() {
        return paiementsList;
    }

    public void setPaiementsList(List<Paiements> paiementsList) {
        this.paiementsList = paiementsList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Utilisateurs)) {
            return false;
        }
        Utilisateurs other = (Utilisateurs) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.Utilisateurs[ id=" + id + " ]";
    }
    
}

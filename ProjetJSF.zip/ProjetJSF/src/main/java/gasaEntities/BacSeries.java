/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "bac_series")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "BacSeries.findAll", query = "SELECT b FROM BacSeries b"),
    @NamedQuery(name = "BacSeries.findById", query = "SELECT b FROM BacSeries b WHERE b.id = :id"),
    @NamedQuery(name = "BacSeries.findByCode", query = "SELECT b FROM BacSeries b WHERE b.code = :code"),
    @NamedQuery(name = "BacSeries.findByLibelle", query = "SELECT b FROM BacSeries b WHERE b.libelle = :libelle")})
public class BacSeries implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "code")
    private String code;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "libelle")
    private String libelle;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "bacSerieId")
    private List<MatieresPrincipales> matieresPrincipalesList;

    public BacSeries() {
    }

    public BacSeries(Integer id) {
        this.id = id;
    }

    public BacSeries(Integer id, String code, String libelle) {
        this.id = id;
        this.code = code;
        this.libelle = libelle;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    @XmlTransient
    public List<MatieresPrincipales> getMatieresPrincipalesList() {
        return matieresPrincipalesList;
    }

    public void setMatieresPrincipalesList(List<MatieresPrincipales> matieresPrincipalesList) {
        this.matieresPrincipalesList = matieresPrincipalesList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof BacSeries)) {
            return false;
        }
        BacSeries other = (BacSeries) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.BacSeries[ id=" + id + " ]";
    }
    
}

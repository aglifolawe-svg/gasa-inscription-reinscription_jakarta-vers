/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "matieres_principales")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "MatieresPrincipales.findAll", query = "SELECT m FROM MatieresPrincipales m"),
    @NamedQuery(name = "MatieresPrincipales.findById", query = "SELECT m FROM MatieresPrincipales m WHERE m.id = :id"),
    @NamedQuery(name = "MatieresPrincipales.findByCode", query = "SELECT m FROM MatieresPrincipales m WHERE m.code = :code"),
    @NamedQuery(name = "MatieresPrincipales.findByLibelle", query = "SELECT m FROM MatieresPrincipales m WHERE m.libelle = :libelle"),
    @NamedQuery(name = "MatieresPrincipales.findByCoefficient", query = "SELECT m FROM MatieresPrincipales m WHERE m.coefficient = :coefficient")})
public class MatieresPrincipales implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "code")
    private String code;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "libelle")
    private String libelle;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "coefficient")
    private BigDecimal coefficient;
    @JoinColumn(name = "bac_serie_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private BacSeries bacSerieId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "matierePrincipaleId")
    private List<NotesBac> notesBacList;

    public MatieresPrincipales() {
    }

    public MatieresPrincipales(Integer id) {
        this.id = id;
    }

    public MatieresPrincipales(Integer id, String code, String libelle) {
        this.id = id;
        this.code = code;
        this.libelle = libelle;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public BigDecimal getCoefficient() {
        return coefficient;
    }

    public void setCoefficient(BigDecimal coefficient) {
        this.coefficient = coefficient;
    }

    public BacSeries getBacSerieId() {
        return bacSerieId;
    }

    public void setBacSerieId(BacSeries bacSerieId) {
        this.bacSerieId = bacSerieId;
    }

    @XmlTransient
    public List<NotesBac> getNotesBacList() {
        return notesBacList;
    }

    public void setNotesBacList(List<NotesBac> notesBacList) {
        this.notesBacList = notesBacList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MatieresPrincipales)) {
            return false;
        }
        MatieresPrincipales other = (MatieresPrincipales) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.MatieresPrincipales[ id=" + id + " ]";
    }
    
}

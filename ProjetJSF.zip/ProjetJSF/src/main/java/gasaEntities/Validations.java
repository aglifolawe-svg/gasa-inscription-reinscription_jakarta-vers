/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.Size;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "validations")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Validations.findAll", query = "SELECT v FROM Validations v"),
    @NamedQuery(name = "Validations.findById", query = "SELECT v FROM Validations v WHERE v.id = :id"),
    @NamedQuery(name = "Validations.findByDossierId", query = "SELECT v FROM Validations v WHERE v.dossierId = :dossierId"),
    @NamedQuery(name = "Validations.findByValidateur", query = "SELECT v FROM Validations v WHERE v.validateur = :validateur"),
    @NamedQuery(name = "Validations.findByRole", query = "SELECT v FROM Validations v WHERE v.role = :role"),
    @NamedQuery(name = "Validations.findByDateValidation", query = "SELECT v FROM Validations v WHERE v.dateValidation = :dateValidation"),
    @NamedQuery(name = "Validations.findByCommentaire", query = "SELECT v FROM Validations v WHERE v.commentaire = :commentaire")})
public class Validations implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "dossier_id")
    private Integer dossierId;
    @Size(max = 50)
    @Column(name = "validateur")
    private String validateur;
    @Size(max = 20)
    @Column(name = "role")
    private String role;
    @Column(name = "date_validation")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateValidation;
    @Size(max = 2147483647)
    @Column(name = "commentaire")
    private String commentaire;

    public Validations() {
    }

    public Validations(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getDossierId() {
        return dossierId;
    }

    public void setDossierId(Integer dossierId) {
        this.dossierId = dossierId;
    }

    public String getValidateur() {
        return validateur;
    }

    public void setValidateur(String validateur) {
        this.validateur = validateur;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Date getDateValidation() {
        return dateValidation;
    }

    public void setDateValidation(Date dateValidation) {
        this.dateValidation = dateValidation;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Validations)) {
            return false;
        }
        Validations other = (Validations) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.Validations[ id=" + id + " ]";
    }
    
}

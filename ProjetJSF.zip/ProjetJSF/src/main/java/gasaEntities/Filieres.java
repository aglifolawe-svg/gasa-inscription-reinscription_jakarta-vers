/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "filieres")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Filieres.findAll", query = "SELECT f FROM Filieres f"),
    @NamedQuery(name = "Filieres.findById", query = "SELECT f FROM Filieres f WHERE f.id = :id"),
    @NamedQuery(name = "Filieres.findByNom", query = "SELECT f FROM Filieres f WHERE f.nom = :nom"),
    @NamedQuery(name = "Filieres.findByUfr", query = "SELECT f FROM Filieres f WHERE f.ufr = :ufr")})
public class Filieres implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "nom")
    private String nom;
    @Size(max = 100)
    @Column(name = "ufr")
    private String ufr;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "filiere")
    private List<CriteresAdmission> criteresAdmissionList;
    @OneToMany(mappedBy = "filiereId")
    private List<CritereMatieres> critereMatieresList;
    @OneToMany(mappedBy = "filiereId")
    private List<Inscriptions> inscriptionsList;
    @OneToMany(mappedBy = "filiereId")
    private List<Criteres> criteresList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "filieres")
    private List<FiliereCompatSeries> filiereCompatSeriesList;

    public Filieres() {
    }

    public Filieres(Integer id) {
        this.id = id;
    }

    public Filieres(Integer id, String nom) {
        this.id = id;
        this.nom = nom;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getUfr() {
        return ufr;
    }

    public void setUfr(String ufr) {
        this.ufr = ufr;
    }

    @XmlTransient
    public List<CriteresAdmission> getCriteresAdmissionList() {
        return criteresAdmissionList;
    }

    public void setCriteresAdmissionList(List<CriteresAdmission> criteresAdmissionList) {
        this.criteresAdmissionList = criteresAdmissionList;
    }

    @XmlTransient
    public List<CritereMatieres> getCritereMatieresList() {
        return critereMatieresList;
    }

    public void setCritereMatieresList(List<CritereMatieres> critereMatieresList) {
        this.critereMatieresList = critereMatieresList;
    }

    @XmlTransient
    public List<Inscriptions> getInscriptionsList() {
        return inscriptionsList;
    }

    public void setInscriptionsList(List<Inscriptions> inscriptionsList) {
        this.inscriptionsList = inscriptionsList;
    }

    @XmlTransient
    public List<Criteres> getCriteresList() {
        return criteresList;
    }

    public void setCriteresList(List<Criteres> criteresList) {
        this.criteresList = criteresList;
    }

    @XmlTransient
    public List<FiliereCompatSeries> getFiliereCompatSeriesList() {
        return filiereCompatSeriesList;
    }

    public void setFiliereCompatSeriesList(List<FiliereCompatSeries> filiereCompatSeriesList) {
        this.filiereCompatSeriesList = filiereCompatSeriesList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Filieres)) {
            return false;
        }
        Filieres other = (Filieres) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.Filieres[ id=" + id + " ]";
    }
    
}

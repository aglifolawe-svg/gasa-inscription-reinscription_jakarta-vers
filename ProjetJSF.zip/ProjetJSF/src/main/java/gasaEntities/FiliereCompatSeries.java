/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "filiere_compat_series")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "FiliereCompatSeries.findAll", query = "SELECT f FROM FiliereCompatSeries f"),
    @NamedQuery(name = "FiliereCompatSeries.findByFiliereId", query = "SELECT f FROM FiliereCompatSeries f WHERE f.filiereCompatSeriesPK.filiereId = :filiereId"),
    @NamedQuery(name = "FiliereCompatSeries.findBySerieCode", query = "SELECT f FROM FiliereCompatSeries f WHERE f.filiereCompatSeriesPK.serieCode = :serieCode")})
public class FiliereCompatSeries implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected FiliereCompatSeriesPK filiereCompatSeriesPK;
    @JoinColumn(name = "filiere_id", referencedColumnName = "id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Filieres filieres;

    public FiliereCompatSeries() {
    }

    public FiliereCompatSeries(FiliereCompatSeriesPK filiereCompatSeriesPK) {
        this.filiereCompatSeriesPK = filiereCompatSeriesPK;
    }

    public FiliereCompatSeries(int filiereId, String serieCode) {
        this.filiereCompatSeriesPK = new FiliereCompatSeriesPK(filiereId, serieCode);
    }

    public FiliereCompatSeriesPK getFiliereCompatSeriesPK() {
        return filiereCompatSeriesPK;
    }

    public void setFiliereCompatSeriesPK(FiliereCompatSeriesPK filiereCompatSeriesPK) {
        this.filiereCompatSeriesPK = filiereCompatSeriesPK;
    }

    public Filieres getFilieres() {
        return filieres;
    }

    public void setFilieres(Filieres filieres) {
        this.filieres = filieres;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (filiereCompatSeriesPK != null ? filiereCompatSeriesPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FiliereCompatSeries)) {
            return false;
        }
        FiliereCompatSeries other = (FiliereCompatSeries) object;
        if ((this.filiereCompatSeriesPK == null && other.filiereCompatSeriesPK != null) || (this.filiereCompatSeriesPK != null && !this.filiereCompatSeriesPK.equals(other.filiereCompatSeriesPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.FiliereCompatSeries[ filiereCompatSeriesPK=" + filiereCompatSeriesPK + " ]";
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "critere_matieres")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CritereMatieres.findAll", query = "SELECT c FROM CritereMatieres c"),
    @NamedQuery(name = "CritereMatieres.findById", query = "SELECT c FROM CritereMatieres c WHERE c.id = :id"),
    @NamedQuery(name = "CritereMatieres.findByMatiereCode", query = "SELECT c FROM CritereMatieres c WHERE c.matiereCode = :matiereCode"),
    @NamedQuery(name = "CritereMatieres.findByNoteMin", query = "SELECT c FROM CritereMatieres c WHERE c.noteMin = :noteMin")})
public class CritereMatieres implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "matiere_code")
    private String matiereCode;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Column(name = "note_min")
    private BigDecimal noteMin;
    @JoinColumn(name = "critere_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Criteres critereId;
    @JoinColumn(name = "critere_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private CriteresAdmission critereId1;
    @JoinColumn(name = "filiere_id", referencedColumnName = "id")
    @ManyToOne
    private Filieres filiereId;

    public CritereMatieres() {
    }

    public CritereMatieres(Integer id) {
        this.id = id;
    }

    public CritereMatieres(Integer id, String matiereCode, BigDecimal noteMin) {
        this.id = id;
        this.matiereCode = matiereCode;
        this.noteMin = noteMin;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMatiereCode() {
        return matiereCode;
    }

    public void setMatiereCode(String matiereCode) {
        this.matiereCode = matiereCode;
    }

    public BigDecimal getNoteMin() {
        return noteMin;
    }

    public void setNoteMin(BigDecimal noteMin) {
        this.noteMin = noteMin;
    }

    public Criteres getCritereId() {
        return critereId;
    }

    public void setCritereId(Criteres critereId) {
        this.critereId = critereId;
    }

    public CriteresAdmission getCritereId1() {
        return critereId1;
    }

    public void setCritereId1(CriteresAdmission critereId1) {
        this.critereId1 = critereId1;
    }

    public Filieres getFiliereId() {
        return filiereId;
    }

    public void setFiliereId(Filieres filiereId) {
        this.filiereId = filiereId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CritereMatieres)) {
            return false;
        }
        CritereMatieres other = (CritereMatieres) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.CritereMatieres[ id=" + id + " ]";
    }
    
}

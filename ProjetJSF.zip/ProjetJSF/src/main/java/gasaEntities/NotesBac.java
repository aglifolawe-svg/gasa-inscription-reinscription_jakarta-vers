/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasaEntities;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author folaw
 */
@Entity
@Table(name = "notes_bac")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "NotesBac.findAll", query = "SELECT n FROM NotesBac n"),
    @NamedQuery(name = "NotesBac.findById", query = "SELECT n FROM NotesBac n WHERE n.id = :id"),
    @NamedQuery(name = "NotesBac.findByNote", query = "SELECT n FROM NotesBac n WHERE n.note = :note")})
public class NotesBac implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Column(name = "note")
    private BigDecimal note;
    @JoinColumn(name = "inscription_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Inscriptions inscriptionId;
    @JoinColumn(name = "matiere_principale_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private MatieresPrincipales matierePrincipaleId;

    public NotesBac() {
    }

    public NotesBac(Integer id) {
        this.id = id;
    }

    public NotesBac(Integer id, BigDecimal note) {
        this.id = id;
        this.note = note;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public BigDecimal getNote() {
        return note;
    }

    public void setNote(BigDecimal note) {
        this.note = note;
    }

    public Inscriptions getInscriptionId() {
        return inscriptionId;
    }

    public void setInscriptionId(Inscriptions inscriptionId) {
        this.inscriptionId = inscriptionId;
    }

    public MatieresPrincipales getMatierePrincipaleId() {
        return matierePrincipaleId;
    }

    public void setMatierePrincipaleId(MatieresPrincipales matierePrincipaleId) {
        this.matierePrincipaleId = matierePrincipaleId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof NotesBac)) {
            return false;
        }
        NotesBac other = (NotesBac) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gasaEntities.NotesBac[ id=" + id + " ]";
    }
    
}

package gasa.entities;

import gasaEntities.FiliereCompatSeries;
import gasa.entities.util.JsfUtil;
import gasa.entities.util.PaginationHelper;
import gasa.controllers.FiliereCompatSeriesJpaController;

import java.io.Serializable;
import java.util.ResourceBundle;
import jakarta.annotation.Resource;
import jakarta.inject.Named;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;
import jakarta.faces.model.DataModel;
import jakarta.faces.model.ListDataModel;
import jakarta.faces.model.SelectItem;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.PersistenceUnit;
import jakarta.transaction.UserTransaction;

@Named("filiereCompatSeriesController")
@SessionScoped
public class FiliereCompatSeriesController implements Serializable {

    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "my_persistence_unit")
    private EntityManagerFactory emf = null;

    private FiliereCompatSeries current;
    private DataModel items = null;
    private FiliereCompatSeriesJpaController jpaController = null;
    private PaginationHelper pagination;
    private int selectedItemIndex;

    public FiliereCompatSeriesController() {
    }

    public FiliereCompatSeries getSelected() {
        if (current == null) {
            current = new FiliereCompatSeries();
            current.setFiliereCompatSeriesPK(new gasaEntities.FiliereCompatSeriesPK());
            selectedItemIndex = -1;
        }
        return current;
    }

    private FiliereCompatSeriesJpaController getJpaController() {
        if (jpaController == null) {
            jpaController = new FiliereCompatSeriesJpaController(utx, emf);
        }
        return jpaController;
    }

    public PaginationHelper getPagination() {
        if (pagination == null) {
            pagination = new PaginationHelper(10) {

                @Override
                public int getItemsCount() {
                    return getJpaController().getFiliereCompatSeriesCount();
                }

                @Override
                public DataModel createPageDataModel() {
                    return new ListDataModel(getJpaController().findFiliereCompatSeriesEntities(getPageSize(), getPageFirstItem()));
                }
            };
        }
        return pagination;
    }

    public String prepareList() {
        recreateModel();
        return "List";
    }

    public String prepareView() {
        current = (FiliereCompatSeries) getItems().getRowData();
        selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex();
        return "View";
    }

    public String prepareCreate() {
        current = new FiliereCompatSeries();
        current.setFiliereCompatSeriesPK(new gasaEntities.FiliereCompatSeriesPK());
        selectedItemIndex = -1;
        return "Create";
    }

    public String create() {
        try {
            current.getFiliereCompatSeriesPK().setFiliereId(current.getFilieres().getId());
            getJpaController().create(current);
            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/Bundle").getString("FiliereCompatSeriesCreated"));
            return prepareCreate();
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
            return null;
        }
    }

    public String prepareEdit() {
        current = (FiliereCompatSeries) getItems().getRowData();
        selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex();
        return "Edit";
    }

    public String update() {
        try {
            current.getFiliereCompatSeriesPK().setFiliereId(current.getFilieres().getId());
            getJpaController().edit(current);
            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/Bundle").getString("FiliereCompatSeriesUpdated"));
            return "View";
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
            return null;
        }
    }

    public String destroy() {
        current = (FiliereCompatSeries) getItems().getRowData();
        selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex();
        performDestroy();
        recreatePagination();
        recreateModel();
        return "List";
    }

    public String destroyAndView() {
        performDestroy();
        recreateModel();
        updateCurrentItem();
        if (selectedItemIndex >= 0) {
            return "View";
        } else {
            // all items were removed - go back to list
            recreateModel();
            return "List";
        }
    }

    private void performDestroy() {
        try {
            getJpaController().destroy(current.getFiliereCompatSeriesPK());
            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/Bundle").getString("FiliereCompatSeriesDeleted"));
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
        }
    }

    private void updateCurrentItem() {
        int count = getJpaController().getFiliereCompatSeriesCount();
        if (selectedItemIndex >= count) {
            // selected index cannot be bigger than number of items:
            selectedItemIndex = count - 1;
            // go to previous page if last page disappeared:
            if (pagination.getPageFirstItem() >= count) {
                pagination.previousPage();
            }
        }
        if (selectedItemIndex >= 0) {
            current = getJpaController().findFiliereCompatSeriesEntities(1, selectedItemIndex).get(0);
        }
    }

    public DataModel getItems() {
        if (items == null) {
            items = getPagination().createPageDataModel();
        }
        return items;
    }

    private void recreateModel() {
        items = null;
    }

    private void recreatePagination() {
        pagination = null;
    }

    public String next() {
        getPagination().nextPage();
        recreateModel();
        return "List";
    }

    public String previous() {
        getPagination().previousPage();
        recreateModel();
        return "List";
    }

    public SelectItem[] getItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(getJpaController().findFiliereCompatSeriesEntities(), false);
    }

    public SelectItem[] getItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(getJpaController().findFiliereCompatSeriesEntities(), true);
    }

    @FacesConverter(forClass = FiliereCompatSeries.class)
    public static class FiliereCompatSeriesControllerConverter implements Converter {

        private static final String SEPARATOR = "#";
        private static final String SEPARATOR_ESCAPED = "\\#";

        @Override
        public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
            if (value == null || value.length() == 0) {
                return null;
            }
            FiliereCompatSeriesController controller = (FiliereCompatSeriesController) facesContext.getApplication().getELResolver().
                    getValue(facesContext.getELContext(), null, "filiereCompatSeriesController");
            return controller.getJpaController().findFiliereCompatSeries(getKey(value));
        }

        gasaEntities.FiliereCompatSeriesPK getKey(String value) {
            gasaEntities.FiliereCompatSeriesPK key;
            String values[] = value.split(SEPARATOR_ESCAPED);
            key = new gasaEntities.FiliereCompatSeriesPK();
            key.setFiliereId(Integer.parseInt(values[0]));
            key.setSerieCode(values[1]);
            return key;
        }

        String getStringKey(gasaEntities.FiliereCompatSeriesPK value) {
            StringBuilder sb = new StringBuilder();
            sb.append(value.getFiliereId());
            sb.append(SEPARATOR);
            sb.append(value.getSerieCode());
            return sb.toString();
        }

        @Override
        public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
            if (object == null) {
                return null;
            }
            if (object instanceof FiliereCompatSeries) {
                FiliereCompatSeries o = (FiliereCompatSeries) object;
                return getStringKey(o.getFiliereCompatSeriesPK());
            } else {
                throw new IllegalArgumentException("object " + object + " is of type " + object.getClass().getName() + "; expected type: " + FiliereCompatSeries.class.getName());
            }
        }

    }

}

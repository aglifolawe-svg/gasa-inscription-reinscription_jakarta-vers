/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasa.controllers;

import gasa.controllers.exceptions.NonexistentEntityException;
import gasa.controllers.exceptions.RollbackFailureException;
import gasaEntities.Etudiants;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import gasaEntities.Utilisateurs;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.transaction.UserTransaction;
import java.util.List;

/**
 *
 * @author folaw
 */
public class EtudiantsJpaController implements Serializable {

    public EtudiantsJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Etudiants etudiants) throws RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Utilisateurs utilisateurId = etudiants.getUtilisateurId();
            if (utilisateurId != null) {
                utilisateurId = em.getReference(utilisateurId.getClass(), utilisateurId.getId());
                etudiants.setUtilisateurId(utilisateurId);
            }
            em.persist(etudiants);
            if (utilisateurId != null) {
                utilisateurId.getEtudiantsList().add(etudiants);
                utilisateurId = em.merge(utilisateurId);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Etudiants etudiants) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Etudiants persistentEtudiants = em.find(Etudiants.class, etudiants.getId());
            Utilisateurs utilisateurIdOld = persistentEtudiants.getUtilisateurId();
            Utilisateurs utilisateurIdNew = etudiants.getUtilisateurId();
            if (utilisateurIdNew != null) {
                utilisateurIdNew = em.getReference(utilisateurIdNew.getClass(), utilisateurIdNew.getId());
                etudiants.setUtilisateurId(utilisateurIdNew);
            }
            etudiants = em.merge(etudiants);
            if (utilisateurIdOld != null && !utilisateurIdOld.equals(utilisateurIdNew)) {
                utilisateurIdOld.getEtudiantsList().remove(etudiants);
                utilisateurIdOld = em.merge(utilisateurIdOld);
            }
            if (utilisateurIdNew != null && !utilisateurIdNew.equals(utilisateurIdOld)) {
                utilisateurIdNew.getEtudiantsList().add(etudiants);
                utilisateurIdNew = em.merge(utilisateurIdNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = etudiants.getId();
                if (findEtudiants(id) == null) {
                    throw new NonexistentEntityException("The etudiants with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Etudiants etudiants;
            try {
                etudiants = em.getReference(Etudiants.class, id);
                etudiants.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The etudiants with id " + id + " no longer exists.", enfe);
            }
            Utilisateurs utilisateurId = etudiants.getUtilisateurId();
            if (utilisateurId != null) {
                utilisateurId.getEtudiantsList().remove(etudiants);
                utilisateurId = em.merge(utilisateurId);
            }
            em.remove(etudiants);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Etudiants> findEtudiantsEntities() {
        return findEtudiantsEntities(true, -1, -1);
    }

    public List<Etudiants> findEtudiantsEntities(int maxResults, int firstResult) {
        return findEtudiantsEntities(false, maxResults, firstResult);
    }

    private List<Etudiants> findEtudiantsEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Etudiants.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Etudiants findEtudiants(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Etudiants.class, id);
        } finally {
            em.close();
        }
    }

    public int getEtudiantsCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Etudiants> rt = cq.from(Etudiants.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

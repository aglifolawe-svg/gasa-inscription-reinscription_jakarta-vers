/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasa.controllers;

import gasa.controllers.exceptions.IllegalOrphanException;
import gasa.controllers.exceptions.NonexistentEntityException;
import gasa.controllers.exceptions.RollbackFailureException;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import gasaEntities.Filieres;
import gasaEntities.Utilisateurs;
import gasaEntities.Documents;
import gasaEntities.Inscriptions;
import java.util.ArrayList;
import java.util.List;
import gasaEntities.Justificatifs;
import gasaEntities.NotesBac;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.transaction.UserTransaction;

/**
 *
 * @author folaw
 */
public class InscriptionsJpaController implements Serializable {

    public InscriptionsJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Inscriptions inscriptions) throws RollbackFailureException, Exception {
        if (inscriptions.getDocumentsList() == null) {
            inscriptions.setDocumentsList(new ArrayList<Documents>());
        }
        if (inscriptions.getJustificatifsList() == null) {
            inscriptions.setJustificatifsList(new ArrayList<Justificatifs>());
        }
        if (inscriptions.getNotesBacList() == null) {
            inscriptions.setNotesBacList(new ArrayList<NotesBac>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Filieres filiereId = inscriptions.getFiliereId();
            if (filiereId != null) {
                filiereId = em.getReference(filiereId.getClass(), filiereId.getId());
                inscriptions.setFiliereId(filiereId);
            }
            Utilisateurs etudiantId = inscriptions.getEtudiantId();
            if (etudiantId != null) {
                etudiantId = em.getReference(etudiantId.getClass(), etudiantId.getId());
                inscriptions.setEtudiantId(etudiantId);
            }
            List<Documents> attachedDocumentsList = new ArrayList<Documents>();
            for (Documents documentsListDocumentsToAttach : inscriptions.getDocumentsList()) {
                documentsListDocumentsToAttach = em.getReference(documentsListDocumentsToAttach.getClass(), documentsListDocumentsToAttach.getId());
                attachedDocumentsList.add(documentsListDocumentsToAttach);
            }
            inscriptions.setDocumentsList(attachedDocumentsList);
            List<Justificatifs> attachedJustificatifsList = new ArrayList<Justificatifs>();
            for (Justificatifs justificatifsListJustificatifsToAttach : inscriptions.getJustificatifsList()) {
                justificatifsListJustificatifsToAttach = em.getReference(justificatifsListJustificatifsToAttach.getClass(), justificatifsListJustificatifsToAttach.getId());
                attachedJustificatifsList.add(justificatifsListJustificatifsToAttach);
            }
            inscriptions.setJustificatifsList(attachedJustificatifsList);
            List<NotesBac> attachedNotesBacList = new ArrayList<NotesBac>();
            for (NotesBac notesBacListNotesBacToAttach : inscriptions.getNotesBacList()) {
                notesBacListNotesBacToAttach = em.getReference(notesBacListNotesBacToAttach.getClass(), notesBacListNotesBacToAttach.getId());
                attachedNotesBacList.add(notesBacListNotesBacToAttach);
            }
            inscriptions.setNotesBacList(attachedNotesBacList);
            em.persist(inscriptions);
            if (filiereId != null) {
                filiereId.getInscriptionsList().add(inscriptions);
                filiereId = em.merge(filiereId);
            }
            if (etudiantId != null) {
                etudiantId.getInscriptionsList().add(inscriptions);
                etudiantId = em.merge(etudiantId);
            }
            for (Documents documentsListDocuments : inscriptions.getDocumentsList()) {
                Inscriptions oldInscriptionIdOfDocumentsListDocuments = documentsListDocuments.getInscriptionId();
                documentsListDocuments.setInscriptionId(inscriptions);
                documentsListDocuments = em.merge(documentsListDocuments);
                if (oldInscriptionIdOfDocumentsListDocuments != null) {
                    oldInscriptionIdOfDocumentsListDocuments.getDocumentsList().remove(documentsListDocuments);
                    oldInscriptionIdOfDocumentsListDocuments = em.merge(oldInscriptionIdOfDocumentsListDocuments);
                }
            }
            for (Justificatifs justificatifsListJustificatifs : inscriptions.getJustificatifsList()) {
                Inscriptions oldInscriptionIdOfJustificatifsListJustificatifs = justificatifsListJustificatifs.getInscriptionId();
                justificatifsListJustificatifs.setInscriptionId(inscriptions);
                justificatifsListJustificatifs = em.merge(justificatifsListJustificatifs);
                if (oldInscriptionIdOfJustificatifsListJustificatifs != null) {
                    oldInscriptionIdOfJustificatifsListJustificatifs.getJustificatifsList().remove(justificatifsListJustificatifs);
                    oldInscriptionIdOfJustificatifsListJustificatifs = em.merge(oldInscriptionIdOfJustificatifsListJustificatifs);
                }
            }
            for (NotesBac notesBacListNotesBac : inscriptions.getNotesBacList()) {
                Inscriptions oldInscriptionIdOfNotesBacListNotesBac = notesBacListNotesBac.getInscriptionId();
                notesBacListNotesBac.setInscriptionId(inscriptions);
                notesBacListNotesBac = em.merge(notesBacListNotesBac);
                if (oldInscriptionIdOfNotesBacListNotesBac != null) {
                    oldInscriptionIdOfNotesBacListNotesBac.getNotesBacList().remove(notesBacListNotesBac);
                    oldInscriptionIdOfNotesBacListNotesBac = em.merge(oldInscriptionIdOfNotesBacListNotesBac);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Inscriptions inscriptions) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Inscriptions persistentInscriptions = em.find(Inscriptions.class, inscriptions.getId());
            Filieres filiereIdOld = persistentInscriptions.getFiliereId();
            Filieres filiereIdNew = inscriptions.getFiliereId();
            Utilisateurs etudiantIdOld = persistentInscriptions.getEtudiantId();
            Utilisateurs etudiantIdNew = inscriptions.getEtudiantId();
            List<Documents> documentsListOld = persistentInscriptions.getDocumentsList();
            List<Documents> documentsListNew = inscriptions.getDocumentsList();
            List<Justificatifs> justificatifsListOld = persistentInscriptions.getJustificatifsList();
            List<Justificatifs> justificatifsListNew = inscriptions.getJustificatifsList();
            List<NotesBac> notesBacListOld = persistentInscriptions.getNotesBacList();
            List<NotesBac> notesBacListNew = inscriptions.getNotesBacList();
            List<String> illegalOrphanMessages = null;
            for (Documents documentsListOldDocuments : documentsListOld) {
                if (!documentsListNew.contains(documentsListOldDocuments)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Documents " + documentsListOldDocuments + " since its inscriptionId field is not nullable.");
                }
            }
            for (Justificatifs justificatifsListOldJustificatifs : justificatifsListOld) {
                if (!justificatifsListNew.contains(justificatifsListOldJustificatifs)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Justificatifs " + justificatifsListOldJustificatifs + " since its inscriptionId field is not nullable.");
                }
            }
            for (NotesBac notesBacListOldNotesBac : notesBacListOld) {
                if (!notesBacListNew.contains(notesBacListOldNotesBac)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain NotesBac " + notesBacListOldNotesBac + " since its inscriptionId field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (filiereIdNew != null) {
                filiereIdNew = em.getReference(filiereIdNew.getClass(), filiereIdNew.getId());
                inscriptions.setFiliereId(filiereIdNew);
            }
            if (etudiantIdNew != null) {
                etudiantIdNew = em.getReference(etudiantIdNew.getClass(), etudiantIdNew.getId());
                inscriptions.setEtudiantId(etudiantIdNew);
            }
            List<Documents> attachedDocumentsListNew = new ArrayList<Documents>();
            for (Documents documentsListNewDocumentsToAttach : documentsListNew) {
                documentsListNewDocumentsToAttach = em.getReference(documentsListNewDocumentsToAttach.getClass(), documentsListNewDocumentsToAttach.getId());
                attachedDocumentsListNew.add(documentsListNewDocumentsToAttach);
            }
            documentsListNew = attachedDocumentsListNew;
            inscriptions.setDocumentsList(documentsListNew);
            List<Justificatifs> attachedJustificatifsListNew = new ArrayList<Justificatifs>();
            for (Justificatifs justificatifsListNewJustificatifsToAttach : justificatifsListNew) {
                justificatifsListNewJustificatifsToAttach = em.getReference(justificatifsListNewJustificatifsToAttach.getClass(), justificatifsListNewJustificatifsToAttach.getId());
                attachedJustificatifsListNew.add(justificatifsListNewJustificatifsToAttach);
            }
            justificatifsListNew = attachedJustificatifsListNew;
            inscriptions.setJustificatifsList(justificatifsListNew);
            List<NotesBac> attachedNotesBacListNew = new ArrayList<NotesBac>();
            for (NotesBac notesBacListNewNotesBacToAttach : notesBacListNew) {
                notesBacListNewNotesBacToAttach = em.getReference(notesBacListNewNotesBacToAttach.getClass(), notesBacListNewNotesBacToAttach.getId());
                attachedNotesBacListNew.add(notesBacListNewNotesBacToAttach);
            }
            notesBacListNew = attachedNotesBacListNew;
            inscriptions.setNotesBacList(notesBacListNew);
            inscriptions = em.merge(inscriptions);
            if (filiereIdOld != null && !filiereIdOld.equals(filiereIdNew)) {
                filiereIdOld.getInscriptionsList().remove(inscriptions);
                filiereIdOld = em.merge(filiereIdOld);
            }
            if (filiereIdNew != null && !filiereIdNew.equals(filiereIdOld)) {
                filiereIdNew.getInscriptionsList().add(inscriptions);
                filiereIdNew = em.merge(filiereIdNew);
            }
            if (etudiantIdOld != null && !etudiantIdOld.equals(etudiantIdNew)) {
                etudiantIdOld.getInscriptionsList().remove(inscriptions);
                etudiantIdOld = em.merge(etudiantIdOld);
            }
            if (etudiantIdNew != null && !etudiantIdNew.equals(etudiantIdOld)) {
                etudiantIdNew.getInscriptionsList().add(inscriptions);
                etudiantIdNew = em.merge(etudiantIdNew);
            }
            for (Documents documentsListNewDocuments : documentsListNew) {
                if (!documentsListOld.contains(documentsListNewDocuments)) {
                    Inscriptions oldInscriptionIdOfDocumentsListNewDocuments = documentsListNewDocuments.getInscriptionId();
                    documentsListNewDocuments.setInscriptionId(inscriptions);
                    documentsListNewDocuments = em.merge(documentsListNewDocuments);
                    if (oldInscriptionIdOfDocumentsListNewDocuments != null && !oldInscriptionIdOfDocumentsListNewDocuments.equals(inscriptions)) {
                        oldInscriptionIdOfDocumentsListNewDocuments.getDocumentsList().remove(documentsListNewDocuments);
                        oldInscriptionIdOfDocumentsListNewDocuments = em.merge(oldInscriptionIdOfDocumentsListNewDocuments);
                    }
                }
            }
            for (Justificatifs justificatifsListNewJustificatifs : justificatifsListNew) {
                if (!justificatifsListOld.contains(justificatifsListNewJustificatifs)) {
                    Inscriptions oldInscriptionIdOfJustificatifsListNewJustificatifs = justificatifsListNewJustificatifs.getInscriptionId();
                    justificatifsListNewJustificatifs.setInscriptionId(inscriptions);
                    justificatifsListNewJustificatifs = em.merge(justificatifsListNewJustificatifs);
                    if (oldInscriptionIdOfJustificatifsListNewJustificatifs != null && !oldInscriptionIdOfJustificatifsListNewJustificatifs.equals(inscriptions)) {
                        oldInscriptionIdOfJustificatifsListNewJustificatifs.getJustificatifsList().remove(justificatifsListNewJustificatifs);
                        oldInscriptionIdOfJustificatifsListNewJustificatifs = em.merge(oldInscriptionIdOfJustificatifsListNewJustificatifs);
                    }
                }
            }
            for (NotesBac notesBacListNewNotesBac : notesBacListNew) {
                if (!notesBacListOld.contains(notesBacListNewNotesBac)) {
                    Inscriptions oldInscriptionIdOfNotesBacListNewNotesBac = notesBacListNewNotesBac.getInscriptionId();
                    notesBacListNewNotesBac.setInscriptionId(inscriptions);
                    notesBacListNewNotesBac = em.merge(notesBacListNewNotesBac);
                    if (oldInscriptionIdOfNotesBacListNewNotesBac != null && !oldInscriptionIdOfNotesBacListNewNotesBac.equals(inscriptions)) {
                        oldInscriptionIdOfNotesBacListNewNotesBac.getNotesBacList().remove(notesBacListNewNotesBac);
                        oldInscriptionIdOfNotesBacListNewNotesBac = em.merge(oldInscriptionIdOfNotesBacListNewNotesBac);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = inscriptions.getId();
                if (findInscriptions(id) == null) {
                    throw new NonexistentEntityException("The inscriptions with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Inscriptions inscriptions;
            try {
                inscriptions = em.getReference(Inscriptions.class, id);
                inscriptions.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The inscriptions with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Documents> documentsListOrphanCheck = inscriptions.getDocumentsList();
            for (Documents documentsListOrphanCheckDocuments : documentsListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Inscriptions (" + inscriptions + ") cannot be destroyed since the Documents " + documentsListOrphanCheckDocuments + " in its documentsList field has a non-nullable inscriptionId field.");
            }
            List<Justificatifs> justificatifsListOrphanCheck = inscriptions.getJustificatifsList();
            for (Justificatifs justificatifsListOrphanCheckJustificatifs : justificatifsListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Inscriptions (" + inscriptions + ") cannot be destroyed since the Justificatifs " + justificatifsListOrphanCheckJustificatifs + " in its justificatifsList field has a non-nullable inscriptionId field.");
            }
            List<NotesBac> notesBacListOrphanCheck = inscriptions.getNotesBacList();
            for (NotesBac notesBacListOrphanCheckNotesBac : notesBacListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Inscriptions (" + inscriptions + ") cannot be destroyed since the NotesBac " + notesBacListOrphanCheckNotesBac + " in its notesBacList field has a non-nullable inscriptionId field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Filieres filiereId = inscriptions.getFiliereId();
            if (filiereId != null) {
                filiereId.getInscriptionsList().remove(inscriptions);
                filiereId = em.merge(filiereId);
            }
            Utilisateurs etudiantId = inscriptions.getEtudiantId();
            if (etudiantId != null) {
                etudiantId.getInscriptionsList().remove(inscriptions);
                etudiantId = em.merge(etudiantId);
            }
            em.remove(inscriptions);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Inscriptions> findInscriptionsEntities() {
        return findInscriptionsEntities(true, -1, -1);
    }

    public List<Inscriptions> findInscriptionsEntities(int maxResults, int firstResult) {
        return findInscriptionsEntities(false, maxResults, firstResult);
    }

    private List<Inscriptions> findInscriptionsEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Inscriptions.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Inscriptions findInscriptions(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Inscriptions.class, id);
        } finally {
            em.close();
        }
    }

    public int getInscriptionsCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Inscriptions> rt = cq.from(Inscriptions.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

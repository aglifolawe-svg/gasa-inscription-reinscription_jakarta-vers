/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasa.controllers;

import gasa.controllers.exceptions.IllegalOrphanException;
import gasa.controllers.exceptions.NonexistentEntityException;
import gasa.controllers.exceptions.RollbackFailureException;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import gasaEntities.Inscriptions;
import java.util.ArrayList;
import java.util.List;
import gasaEntities.Etudiants;
import gasaEntities.Paiements;
import gasaEntities.Utilisateurs;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.transaction.UserTransaction;

/**
 *
 * @author folaw
 */
public class UtilisateursJpaController implements Serializable {

    public UtilisateursJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Utilisateurs utilisateurs) throws RollbackFailureException, Exception {
        if (utilisateurs.getInscriptionsList() == null) {
            utilisateurs.setInscriptionsList(new ArrayList<Inscriptions>());
        }
        if (utilisateurs.getEtudiantsList() == null) {
            utilisateurs.setEtudiantsList(new ArrayList<Etudiants>());
        }
        if (utilisateurs.getPaiementsList() == null) {
            utilisateurs.setPaiementsList(new ArrayList<Paiements>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            List<Inscriptions> attachedInscriptionsList = new ArrayList<Inscriptions>();
            for (Inscriptions inscriptionsListInscriptionsToAttach : utilisateurs.getInscriptionsList()) {
                inscriptionsListInscriptionsToAttach = em.getReference(inscriptionsListInscriptionsToAttach.getClass(), inscriptionsListInscriptionsToAttach.getId());
                attachedInscriptionsList.add(inscriptionsListInscriptionsToAttach);
            }
            utilisateurs.setInscriptionsList(attachedInscriptionsList);
            List<Etudiants> attachedEtudiantsList = new ArrayList<Etudiants>();
            for (Etudiants etudiantsListEtudiantsToAttach : utilisateurs.getEtudiantsList()) {
                etudiantsListEtudiantsToAttach = em.getReference(etudiantsListEtudiantsToAttach.getClass(), etudiantsListEtudiantsToAttach.getId());
                attachedEtudiantsList.add(etudiantsListEtudiantsToAttach);
            }
            utilisateurs.setEtudiantsList(attachedEtudiantsList);
            List<Paiements> attachedPaiementsList = new ArrayList<Paiements>();
            for (Paiements paiementsListPaiementsToAttach : utilisateurs.getPaiementsList()) {
                paiementsListPaiementsToAttach = em.getReference(paiementsListPaiementsToAttach.getClass(), paiementsListPaiementsToAttach.getId());
                attachedPaiementsList.add(paiementsListPaiementsToAttach);
            }
            utilisateurs.setPaiementsList(attachedPaiementsList);
            em.persist(utilisateurs);
            for (Inscriptions inscriptionsListInscriptions : utilisateurs.getInscriptionsList()) {
                Utilisateurs oldEtudiantIdOfInscriptionsListInscriptions = inscriptionsListInscriptions.getEtudiantId();
                inscriptionsListInscriptions.setEtudiantId(utilisateurs);
                inscriptionsListInscriptions = em.merge(inscriptionsListInscriptions);
                if (oldEtudiantIdOfInscriptionsListInscriptions != null) {
                    oldEtudiantIdOfInscriptionsListInscriptions.getInscriptionsList().remove(inscriptionsListInscriptions);
                    oldEtudiantIdOfInscriptionsListInscriptions = em.merge(oldEtudiantIdOfInscriptionsListInscriptions);
                }
            }
            for (Etudiants etudiantsListEtudiants : utilisateurs.getEtudiantsList()) {
                Utilisateurs oldUtilisateurIdOfEtudiantsListEtudiants = etudiantsListEtudiants.getUtilisateurId();
                etudiantsListEtudiants.setUtilisateurId(utilisateurs);
                etudiantsListEtudiants = em.merge(etudiantsListEtudiants);
                if (oldUtilisateurIdOfEtudiantsListEtudiants != null) {
                    oldUtilisateurIdOfEtudiantsListEtudiants.getEtudiantsList().remove(etudiantsListEtudiants);
                    oldUtilisateurIdOfEtudiantsListEtudiants = em.merge(oldUtilisateurIdOfEtudiantsListEtudiants);
                }
            }
            for (Paiements paiementsListPaiements : utilisateurs.getPaiementsList()) {
                Utilisateurs oldEtudiantIdOfPaiementsListPaiements = paiementsListPaiements.getEtudiantId();
                paiementsListPaiements.setEtudiantId(utilisateurs);
                paiementsListPaiements = em.merge(paiementsListPaiements);
                if (oldEtudiantIdOfPaiementsListPaiements != null) {
                    oldEtudiantIdOfPaiementsListPaiements.getPaiementsList().remove(paiementsListPaiements);
                    oldEtudiantIdOfPaiementsListPaiements = em.merge(oldEtudiantIdOfPaiementsListPaiements);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Utilisateurs utilisateurs) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Utilisateurs persistentUtilisateurs = em.find(Utilisateurs.class, utilisateurs.getId());
            List<Inscriptions> inscriptionsListOld = persistentUtilisateurs.getInscriptionsList();
            List<Inscriptions> inscriptionsListNew = utilisateurs.getInscriptionsList();
            List<Etudiants> etudiantsListOld = persistentUtilisateurs.getEtudiantsList();
            List<Etudiants> etudiantsListNew = utilisateurs.getEtudiantsList();
            List<Paiements> paiementsListOld = persistentUtilisateurs.getPaiementsList();
            List<Paiements> paiementsListNew = utilisateurs.getPaiementsList();
            List<String> illegalOrphanMessages = null;
            for (Inscriptions inscriptionsListOldInscriptions : inscriptionsListOld) {
                if (!inscriptionsListNew.contains(inscriptionsListOldInscriptions)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Inscriptions " + inscriptionsListOldInscriptions + " since its etudiantId field is not nullable.");
                }
            }
            for (Etudiants etudiantsListOldEtudiants : etudiantsListOld) {
                if (!etudiantsListNew.contains(etudiantsListOldEtudiants)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Etudiants " + etudiantsListOldEtudiants + " since its utilisateurId field is not nullable.");
                }
            }
            for (Paiements paiementsListOldPaiements : paiementsListOld) {
                if (!paiementsListNew.contains(paiementsListOldPaiements)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Paiements " + paiementsListOldPaiements + " since its etudiantId field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<Inscriptions> attachedInscriptionsListNew = new ArrayList<Inscriptions>();
            for (Inscriptions inscriptionsListNewInscriptionsToAttach : inscriptionsListNew) {
                inscriptionsListNewInscriptionsToAttach = em.getReference(inscriptionsListNewInscriptionsToAttach.getClass(), inscriptionsListNewInscriptionsToAttach.getId());
                attachedInscriptionsListNew.add(inscriptionsListNewInscriptionsToAttach);
            }
            inscriptionsListNew = attachedInscriptionsListNew;
            utilisateurs.setInscriptionsList(inscriptionsListNew);
            List<Etudiants> attachedEtudiantsListNew = new ArrayList<Etudiants>();
            for (Etudiants etudiantsListNewEtudiantsToAttach : etudiantsListNew) {
                etudiantsListNewEtudiantsToAttach = em.getReference(etudiantsListNewEtudiantsToAttach.getClass(), etudiantsListNewEtudiantsToAttach.getId());
                attachedEtudiantsListNew.add(etudiantsListNewEtudiantsToAttach);
            }
            etudiantsListNew = attachedEtudiantsListNew;
            utilisateurs.setEtudiantsList(etudiantsListNew);
            List<Paiements> attachedPaiementsListNew = new ArrayList<Paiements>();
            for (Paiements paiementsListNewPaiementsToAttach : paiementsListNew) {
                paiementsListNewPaiementsToAttach = em.getReference(paiementsListNewPaiementsToAttach.getClass(), paiementsListNewPaiementsToAttach.getId());
                attachedPaiementsListNew.add(paiementsListNewPaiementsToAttach);
            }
            paiementsListNew = attachedPaiementsListNew;
            utilisateurs.setPaiementsList(paiementsListNew);
            utilisateurs = em.merge(utilisateurs);
            for (Inscriptions inscriptionsListNewInscriptions : inscriptionsListNew) {
                if (!inscriptionsListOld.contains(inscriptionsListNewInscriptions)) {
                    Utilisateurs oldEtudiantIdOfInscriptionsListNewInscriptions = inscriptionsListNewInscriptions.getEtudiantId();
                    inscriptionsListNewInscriptions.setEtudiantId(utilisateurs);
                    inscriptionsListNewInscriptions = em.merge(inscriptionsListNewInscriptions);
                    if (oldEtudiantIdOfInscriptionsListNewInscriptions != null && !oldEtudiantIdOfInscriptionsListNewInscriptions.equals(utilisateurs)) {
                        oldEtudiantIdOfInscriptionsListNewInscriptions.getInscriptionsList().remove(inscriptionsListNewInscriptions);
                        oldEtudiantIdOfInscriptionsListNewInscriptions = em.merge(oldEtudiantIdOfInscriptionsListNewInscriptions);
                    }
                }
            }
            for (Etudiants etudiantsListNewEtudiants : etudiantsListNew) {
                if (!etudiantsListOld.contains(etudiantsListNewEtudiants)) {
                    Utilisateurs oldUtilisateurIdOfEtudiantsListNewEtudiants = etudiantsListNewEtudiants.getUtilisateurId();
                    etudiantsListNewEtudiants.setUtilisateurId(utilisateurs);
                    etudiantsListNewEtudiants = em.merge(etudiantsListNewEtudiants);
                    if (oldUtilisateurIdOfEtudiantsListNewEtudiants != null && !oldUtilisateurIdOfEtudiantsListNewEtudiants.equals(utilisateurs)) {
                        oldUtilisateurIdOfEtudiantsListNewEtudiants.getEtudiantsList().remove(etudiantsListNewEtudiants);
                        oldUtilisateurIdOfEtudiantsListNewEtudiants = em.merge(oldUtilisateurIdOfEtudiantsListNewEtudiants);
                    }
                }
            }
            for (Paiements paiementsListNewPaiements : paiementsListNew) {
                if (!paiementsListOld.contains(paiementsListNewPaiements)) {
                    Utilisateurs oldEtudiantIdOfPaiementsListNewPaiements = paiementsListNewPaiements.getEtudiantId();
                    paiementsListNewPaiements.setEtudiantId(utilisateurs);
                    paiementsListNewPaiements = em.merge(paiementsListNewPaiements);
                    if (oldEtudiantIdOfPaiementsListNewPaiements != null && !oldEtudiantIdOfPaiementsListNewPaiements.equals(utilisateurs)) {
                        oldEtudiantIdOfPaiementsListNewPaiements.getPaiementsList().remove(paiementsListNewPaiements);
                        oldEtudiantIdOfPaiementsListNewPaiements = em.merge(oldEtudiantIdOfPaiementsListNewPaiements);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = utilisateurs.getId();
                if (findUtilisateurs(id) == null) {
                    throw new NonexistentEntityException("The utilisateurs with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Utilisateurs utilisateurs;
            try {
                utilisateurs = em.getReference(Utilisateurs.class, id);
                utilisateurs.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The utilisateurs with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Inscriptions> inscriptionsListOrphanCheck = utilisateurs.getInscriptionsList();
            for (Inscriptions inscriptionsListOrphanCheckInscriptions : inscriptionsListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Utilisateurs (" + utilisateurs + ") cannot be destroyed since the Inscriptions " + inscriptionsListOrphanCheckInscriptions + " in its inscriptionsList field has a non-nullable etudiantId field.");
            }
            List<Etudiants> etudiantsListOrphanCheck = utilisateurs.getEtudiantsList();
            for (Etudiants etudiantsListOrphanCheckEtudiants : etudiantsListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Utilisateurs (" + utilisateurs + ") cannot be destroyed since the Etudiants " + etudiantsListOrphanCheckEtudiants + " in its etudiantsList field has a non-nullable utilisateurId field.");
            }
            List<Paiements> paiementsListOrphanCheck = utilisateurs.getPaiementsList();
            for (Paiements paiementsListOrphanCheckPaiements : paiementsListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Utilisateurs (" + utilisateurs + ") cannot be destroyed since the Paiements " + paiementsListOrphanCheckPaiements + " in its paiementsList field has a non-nullable etudiantId field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(utilisateurs);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Utilisateurs> findUtilisateursEntities() {
        return findUtilisateursEntities(true, -1, -1);
    }

    public List<Utilisateurs> findUtilisateursEntities(int maxResults, int firstResult) {
        return findUtilisateursEntities(false, maxResults, firstResult);
    }

    private List<Utilisateurs> findUtilisateursEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Utilisateurs.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Utilisateurs findUtilisateurs(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Utilisateurs.class, id);
        } finally {
            em.close();
        }
    }

    public int getUtilisateursCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Utilisateurs> rt = cq.from(Utilisateurs.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasa.controllers;

import gasa.controllers.exceptions.NonexistentEntityException;
import gasa.controllers.exceptions.RollbackFailureException;
import gasaEntities.Paiements;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import gasaEntities.Utilisateurs;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.transaction.UserTransaction;
import java.util.List;

/**
 *
 * @author folaw
 */
public class PaiementsJpaController implements Serializable {

    public PaiementsJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Paiements paiements) throws RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Utilisateurs etudiantId = paiements.getEtudiantId();
            if (etudiantId != null) {
                etudiantId = em.getReference(etudiantId.getClass(), etudiantId.getId());
                paiements.setEtudiantId(etudiantId);
            }
            em.persist(paiements);
            if (etudiantId != null) {
                etudiantId.getPaiementsList().add(paiements);
                etudiantId = em.merge(etudiantId);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Paiements paiements) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Paiements persistentPaiements = em.find(Paiements.class, paiements.getId());
            Utilisateurs etudiantIdOld = persistentPaiements.getEtudiantId();
            Utilisateurs etudiantIdNew = paiements.getEtudiantId();
            if (etudiantIdNew != null) {
                etudiantIdNew = em.getReference(etudiantIdNew.getClass(), etudiantIdNew.getId());
                paiements.setEtudiantId(etudiantIdNew);
            }
            paiements = em.merge(paiements);
            if (etudiantIdOld != null && !etudiantIdOld.equals(etudiantIdNew)) {
                etudiantIdOld.getPaiementsList().remove(paiements);
                etudiantIdOld = em.merge(etudiantIdOld);
            }
            if (etudiantIdNew != null && !etudiantIdNew.equals(etudiantIdOld)) {
                etudiantIdNew.getPaiementsList().add(paiements);
                etudiantIdNew = em.merge(etudiantIdNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = paiements.getId();
                if (findPaiements(id) == null) {
                    throw new NonexistentEntityException("The paiements with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Paiements paiements;
            try {
                paiements = em.getReference(Paiements.class, id);
                paiements.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The paiements with id " + id + " no longer exists.", enfe);
            }
            Utilisateurs etudiantId = paiements.getEtudiantId();
            if (etudiantId != null) {
                etudiantId.getPaiementsList().remove(paiements);
                etudiantId = em.merge(etudiantId);
            }
            em.remove(paiements);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Paiements> findPaiementsEntities() {
        return findPaiementsEntities(true, -1, -1);
    }

    public List<Paiements> findPaiementsEntities(int maxResults, int firstResult) {
        return findPaiementsEntities(false, maxResults, firstResult);
    }

    private List<Paiements> findPaiementsEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Paiements.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Paiements findPaiements(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Paiements.class, id);
        } finally {
            em.close();
        }
    }

    public int getPaiementsCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Paiements> rt = cq.from(Paiements.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

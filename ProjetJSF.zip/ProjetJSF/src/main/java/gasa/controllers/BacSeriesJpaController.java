/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasa.controllers;

import gasa.controllers.exceptions.IllegalOrphanException;
import gasa.controllers.exceptions.NonexistentEntityException;
import gasa.controllers.exceptions.RollbackFailureException;
import gasaEntities.BacSeries;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import gasaEntities.MatieresPrincipales;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.transaction.UserTransaction;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author folaw
 */
public class BacSeriesJpaController implements Serializable {

    public BacSeriesJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(BacSeries bacSeries) throws RollbackFailureException, Exception {
        if (bacSeries.getMatieresPrincipalesList() == null) {
            bacSeries.setMatieresPrincipalesList(new ArrayList<MatieresPrincipales>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            List<MatieresPrincipales> attachedMatieresPrincipalesList = new ArrayList<MatieresPrincipales>();
            for (MatieresPrincipales matieresPrincipalesListMatieresPrincipalesToAttach : bacSeries.getMatieresPrincipalesList()) {
                matieresPrincipalesListMatieresPrincipalesToAttach = em.getReference(matieresPrincipalesListMatieresPrincipalesToAttach.getClass(), matieresPrincipalesListMatieresPrincipalesToAttach.getId());
                attachedMatieresPrincipalesList.add(matieresPrincipalesListMatieresPrincipalesToAttach);
            }
            bacSeries.setMatieresPrincipalesList(attachedMatieresPrincipalesList);
            em.persist(bacSeries);
            for (MatieresPrincipales matieresPrincipalesListMatieresPrincipales : bacSeries.getMatieresPrincipalesList()) {
                BacSeries oldBacSerieIdOfMatieresPrincipalesListMatieresPrincipales = matieresPrincipalesListMatieresPrincipales.getBacSerieId();
                matieresPrincipalesListMatieresPrincipales.setBacSerieId(bacSeries);
                matieresPrincipalesListMatieresPrincipales = em.merge(matieresPrincipalesListMatieresPrincipales);
                if (oldBacSerieIdOfMatieresPrincipalesListMatieresPrincipales != null) {
                    oldBacSerieIdOfMatieresPrincipalesListMatieresPrincipales.getMatieresPrincipalesList().remove(matieresPrincipalesListMatieresPrincipales);
                    oldBacSerieIdOfMatieresPrincipalesListMatieresPrincipales = em.merge(oldBacSerieIdOfMatieresPrincipalesListMatieresPrincipales);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(BacSeries bacSeries) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            BacSeries persistentBacSeries = em.find(BacSeries.class, bacSeries.getId());
            List<MatieresPrincipales> matieresPrincipalesListOld = persistentBacSeries.getMatieresPrincipalesList();
            List<MatieresPrincipales> matieresPrincipalesListNew = bacSeries.getMatieresPrincipalesList();
            List<String> illegalOrphanMessages = null;
            for (MatieresPrincipales matieresPrincipalesListOldMatieresPrincipales : matieresPrincipalesListOld) {
                if (!matieresPrincipalesListNew.contains(matieresPrincipalesListOldMatieresPrincipales)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain MatieresPrincipales " + matieresPrincipalesListOldMatieresPrincipales + " since its bacSerieId field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<MatieresPrincipales> attachedMatieresPrincipalesListNew = new ArrayList<MatieresPrincipales>();
            for (MatieresPrincipales matieresPrincipalesListNewMatieresPrincipalesToAttach : matieresPrincipalesListNew) {
                matieresPrincipalesListNewMatieresPrincipalesToAttach = em.getReference(matieresPrincipalesListNewMatieresPrincipalesToAttach.getClass(), matieresPrincipalesListNewMatieresPrincipalesToAttach.getId());
                attachedMatieresPrincipalesListNew.add(matieresPrincipalesListNewMatieresPrincipalesToAttach);
            }
            matieresPrincipalesListNew = attachedMatieresPrincipalesListNew;
            bacSeries.setMatieresPrincipalesList(matieresPrincipalesListNew);
            bacSeries = em.merge(bacSeries);
            for (MatieresPrincipales matieresPrincipalesListNewMatieresPrincipales : matieresPrincipalesListNew) {
                if (!matieresPrincipalesListOld.contains(matieresPrincipalesListNewMatieresPrincipales)) {
                    BacSeries oldBacSerieIdOfMatieresPrincipalesListNewMatieresPrincipales = matieresPrincipalesListNewMatieresPrincipales.getBacSerieId();
                    matieresPrincipalesListNewMatieresPrincipales.setBacSerieId(bacSeries);
                    matieresPrincipalesListNewMatieresPrincipales = em.merge(matieresPrincipalesListNewMatieresPrincipales);
                    if (oldBacSerieIdOfMatieresPrincipalesListNewMatieresPrincipales != null && !oldBacSerieIdOfMatieresPrincipalesListNewMatieresPrincipales.equals(bacSeries)) {
                        oldBacSerieIdOfMatieresPrincipalesListNewMatieresPrincipales.getMatieresPrincipalesList().remove(matieresPrincipalesListNewMatieresPrincipales);
                        oldBacSerieIdOfMatieresPrincipalesListNewMatieresPrincipales = em.merge(oldBacSerieIdOfMatieresPrincipalesListNewMatieresPrincipales);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = bacSeries.getId();
                if (findBacSeries(id) == null) {
                    throw new NonexistentEntityException("The bacSeries with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            BacSeries bacSeries;
            try {
                bacSeries = em.getReference(BacSeries.class, id);
                bacSeries.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The bacSeries with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<MatieresPrincipales> matieresPrincipalesListOrphanCheck = bacSeries.getMatieresPrincipalesList();
            for (MatieresPrincipales matieresPrincipalesListOrphanCheckMatieresPrincipales : matieresPrincipalesListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This BacSeries (" + bacSeries + ") cannot be destroyed since the MatieresPrincipales " + matieresPrincipalesListOrphanCheckMatieresPrincipales + " in its matieresPrincipalesList field has a non-nullable bacSerieId field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(bacSeries);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<BacSeries> findBacSeriesEntities() {
        return findBacSeriesEntities(true, -1, -1);
    }

    public List<BacSeries> findBacSeriesEntities(int maxResults, int firstResult) {
        return findBacSeriesEntities(false, maxResults, firstResult);
    }

    private List<BacSeries> findBacSeriesEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(BacSeries.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public BacSeries findBacSeries(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(BacSeries.class, id);
        } finally {
            em.close();
        }
    }

    public int getBacSeriesCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<BacSeries> rt = cq.from(BacSeries.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

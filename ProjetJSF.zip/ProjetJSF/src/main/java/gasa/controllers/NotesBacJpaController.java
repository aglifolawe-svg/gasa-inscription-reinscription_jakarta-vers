/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasa.controllers;

import gasa.controllers.exceptions.NonexistentEntityException;
import gasa.controllers.exceptions.RollbackFailureException;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import gasaEntities.Inscriptions;
import gasaEntities.MatieresPrincipales;
import gasaEntities.NotesBac;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.transaction.UserTransaction;
import java.util.List;

/**
 *
 * @author folaw
 */
public class NotesBacJpaController implements Serializable {

    public NotesBacJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(NotesBac notesBac) throws RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Inscriptions inscriptionId = notesBac.getInscriptionId();
            if (inscriptionId != null) {
                inscriptionId = em.getReference(inscriptionId.getClass(), inscriptionId.getId());
                notesBac.setInscriptionId(inscriptionId);
            }
            MatieresPrincipales matierePrincipaleId = notesBac.getMatierePrincipaleId();
            if (matierePrincipaleId != null) {
                matierePrincipaleId = em.getReference(matierePrincipaleId.getClass(), matierePrincipaleId.getId());
                notesBac.setMatierePrincipaleId(matierePrincipaleId);
            }
            em.persist(notesBac);
            if (inscriptionId != null) {
                inscriptionId.getNotesBacList().add(notesBac);
                inscriptionId = em.merge(inscriptionId);
            }
            if (matierePrincipaleId != null) {
                matierePrincipaleId.getNotesBacList().add(notesBac);
                matierePrincipaleId = em.merge(matierePrincipaleId);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(NotesBac notesBac) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            NotesBac persistentNotesBac = em.find(NotesBac.class, notesBac.getId());
            Inscriptions inscriptionIdOld = persistentNotesBac.getInscriptionId();
            Inscriptions inscriptionIdNew = notesBac.getInscriptionId();
            MatieresPrincipales matierePrincipaleIdOld = persistentNotesBac.getMatierePrincipaleId();
            MatieresPrincipales matierePrincipaleIdNew = notesBac.getMatierePrincipaleId();
            if (inscriptionIdNew != null) {
                inscriptionIdNew = em.getReference(inscriptionIdNew.getClass(), inscriptionIdNew.getId());
                notesBac.setInscriptionId(inscriptionIdNew);
            }
            if (matierePrincipaleIdNew != null) {
                matierePrincipaleIdNew = em.getReference(matierePrincipaleIdNew.getClass(), matierePrincipaleIdNew.getId());
                notesBac.setMatierePrincipaleId(matierePrincipaleIdNew);
            }
            notesBac = em.merge(notesBac);
            if (inscriptionIdOld != null && !inscriptionIdOld.equals(inscriptionIdNew)) {
                inscriptionIdOld.getNotesBacList().remove(notesBac);
                inscriptionIdOld = em.merge(inscriptionIdOld);
            }
            if (inscriptionIdNew != null && !inscriptionIdNew.equals(inscriptionIdOld)) {
                inscriptionIdNew.getNotesBacList().add(notesBac);
                inscriptionIdNew = em.merge(inscriptionIdNew);
            }
            if (matierePrincipaleIdOld != null && !matierePrincipaleIdOld.equals(matierePrincipaleIdNew)) {
                matierePrincipaleIdOld.getNotesBacList().remove(notesBac);
                matierePrincipaleIdOld = em.merge(matierePrincipaleIdOld);
            }
            if (matierePrincipaleIdNew != null && !matierePrincipaleIdNew.equals(matierePrincipaleIdOld)) {
                matierePrincipaleIdNew.getNotesBacList().add(notesBac);
                matierePrincipaleIdNew = em.merge(matierePrincipaleIdNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = notesBac.getId();
                if (findNotesBac(id) == null) {
                    throw new NonexistentEntityException("The notesBac with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            NotesBac notesBac;
            try {
                notesBac = em.getReference(NotesBac.class, id);
                notesBac.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The notesBac with id " + id + " no longer exists.", enfe);
            }
            Inscriptions inscriptionId = notesBac.getInscriptionId();
            if (inscriptionId != null) {
                inscriptionId.getNotesBacList().remove(notesBac);
                inscriptionId = em.merge(inscriptionId);
            }
            MatieresPrincipales matierePrincipaleId = notesBac.getMatierePrincipaleId();
            if (matierePrincipaleId != null) {
                matierePrincipaleId.getNotesBacList().remove(notesBac);
                matierePrincipaleId = em.merge(matierePrincipaleId);
            }
            em.remove(notesBac);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<NotesBac> findNotesBacEntities() {
        return findNotesBacEntities(true, -1, -1);
    }

    public List<NotesBac> findNotesBacEntities(int maxResults, int firstResult) {
        return findNotesBacEntities(false, maxResults, firstResult);
    }

    private List<NotesBac> findNotesBacEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(NotesBac.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public NotesBac findNotesBac(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(NotesBac.class, id);
        } finally {
            em.close();
        }
    }

    public int getNotesBacCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<NotesBac> rt = cq.from(NotesBac.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasa.controllers;

import gasa.controllers.exceptions.IllegalOrphanException;
import gasa.controllers.exceptions.NonexistentEntityException;
import gasa.controllers.exceptions.RollbackFailureException;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import gasaEntities.Filieres;
import gasaEntities.CritereMatieres;
import gasaEntities.Criteres;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.transaction.UserTransaction;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author folaw
 */
public class CriteresJpaController implements Serializable {

    public CriteresJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Criteres criteres) throws RollbackFailureException, Exception {
        if (criteres.getCritereMatieresList() == null) {
            criteres.setCritereMatieresList(new ArrayList<CritereMatieres>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Filieres filiereId = criteres.getFiliereId();
            if (filiereId != null) {
                filiereId = em.getReference(filiereId.getClass(), filiereId.getId());
                criteres.setFiliereId(filiereId);
            }
            List<CritereMatieres> attachedCritereMatieresList = new ArrayList<CritereMatieres>();
            for (CritereMatieres critereMatieresListCritereMatieresToAttach : criteres.getCritereMatieresList()) {
                critereMatieresListCritereMatieresToAttach = em.getReference(critereMatieresListCritereMatieresToAttach.getClass(), critereMatieresListCritereMatieresToAttach.getId());
                attachedCritereMatieresList.add(critereMatieresListCritereMatieresToAttach);
            }
            criteres.setCritereMatieresList(attachedCritereMatieresList);
            em.persist(criteres);
            if (filiereId != null) {
                filiereId.getCriteresList().add(criteres);
                filiereId = em.merge(filiereId);
            }
            for (CritereMatieres critereMatieresListCritereMatieres : criteres.getCritereMatieresList()) {
                Criteres oldCritereIdOfCritereMatieresListCritereMatieres = critereMatieresListCritereMatieres.getCritereId();
                critereMatieresListCritereMatieres.setCritereId(criteres);
                critereMatieresListCritereMatieres = em.merge(critereMatieresListCritereMatieres);
                if (oldCritereIdOfCritereMatieresListCritereMatieres != null) {
                    oldCritereIdOfCritereMatieresListCritereMatieres.getCritereMatieresList().remove(critereMatieresListCritereMatieres);
                    oldCritereIdOfCritereMatieresListCritereMatieres = em.merge(oldCritereIdOfCritereMatieresListCritereMatieres);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Criteres criteres) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Criteres persistentCriteres = em.find(Criteres.class, criteres.getId());
            Filieres filiereIdOld = persistentCriteres.getFiliereId();
            Filieres filiereIdNew = criteres.getFiliereId();
            List<CritereMatieres> critereMatieresListOld = persistentCriteres.getCritereMatieresList();
            List<CritereMatieres> critereMatieresListNew = criteres.getCritereMatieresList();
            List<String> illegalOrphanMessages = null;
            for (CritereMatieres critereMatieresListOldCritereMatieres : critereMatieresListOld) {
                if (!critereMatieresListNew.contains(critereMatieresListOldCritereMatieres)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain CritereMatieres " + critereMatieresListOldCritereMatieres + " since its critereId field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (filiereIdNew != null) {
                filiereIdNew = em.getReference(filiereIdNew.getClass(), filiereIdNew.getId());
                criteres.setFiliereId(filiereIdNew);
            }
            List<CritereMatieres> attachedCritereMatieresListNew = new ArrayList<CritereMatieres>();
            for (CritereMatieres critereMatieresListNewCritereMatieresToAttach : critereMatieresListNew) {
                critereMatieresListNewCritereMatieresToAttach = em.getReference(critereMatieresListNewCritereMatieresToAttach.getClass(), critereMatieresListNewCritereMatieresToAttach.getId());
                attachedCritereMatieresListNew.add(critereMatieresListNewCritereMatieresToAttach);
            }
            critereMatieresListNew = attachedCritereMatieresListNew;
            criteres.setCritereMatieresList(critereMatieresListNew);
            criteres = em.merge(criteres);
            if (filiereIdOld != null && !filiereIdOld.equals(filiereIdNew)) {
                filiereIdOld.getCriteresList().remove(criteres);
                filiereIdOld = em.merge(filiereIdOld);
            }
            if (filiereIdNew != null && !filiereIdNew.equals(filiereIdOld)) {
                filiereIdNew.getCriteresList().add(criteres);
                filiereIdNew = em.merge(filiereIdNew);
            }
            for (CritereMatieres critereMatieresListNewCritereMatieres : critereMatieresListNew) {
                if (!critereMatieresListOld.contains(critereMatieresListNewCritereMatieres)) {
                    Criteres oldCritereIdOfCritereMatieresListNewCritereMatieres = critereMatieresListNewCritereMatieres.getCritereId();
                    critereMatieresListNewCritereMatieres.setCritereId(criteres);
                    critereMatieresListNewCritereMatieres = em.merge(critereMatieresListNewCritereMatieres);
                    if (oldCritereIdOfCritereMatieresListNewCritereMatieres != null && !oldCritereIdOfCritereMatieresListNewCritereMatieres.equals(criteres)) {
                        oldCritereIdOfCritereMatieresListNewCritereMatieres.getCritereMatieresList().remove(critereMatieresListNewCritereMatieres);
                        oldCritereIdOfCritereMatieresListNewCritereMatieres = em.merge(oldCritereIdOfCritereMatieresListNewCritereMatieres);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = criteres.getId();
                if (findCriteres(id) == null) {
                    throw new NonexistentEntityException("The criteres with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Criteres criteres;
            try {
                criteres = em.getReference(Criteres.class, id);
                criteres.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The criteres with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<CritereMatieres> critereMatieresListOrphanCheck = criteres.getCritereMatieresList();
            for (CritereMatieres critereMatieresListOrphanCheckCritereMatieres : critereMatieresListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Criteres (" + criteres + ") cannot be destroyed since the CritereMatieres " + critereMatieresListOrphanCheckCritereMatieres + " in its critereMatieresList field has a non-nullable critereId field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Filieres filiereId = criteres.getFiliereId();
            if (filiereId != null) {
                filiereId.getCriteresList().remove(criteres);
                filiereId = em.merge(filiereId);
            }
            em.remove(criteres);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Criteres> findCriteresEntities() {
        return findCriteresEntities(true, -1, -1);
    }

    public List<Criteres> findCriteresEntities(int maxResults, int firstResult) {
        return findCriteresEntities(false, maxResults, firstResult);
    }

    private List<Criteres> findCriteresEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Criteres.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Criteres findCriteres(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Criteres.class, id);
        } finally {
            em.close();
        }
    }

    public int getCriteresCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Criteres> rt = cq.from(Criteres.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

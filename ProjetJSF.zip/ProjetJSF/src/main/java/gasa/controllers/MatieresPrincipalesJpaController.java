/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasa.controllers;

import gasa.controllers.exceptions.IllegalOrphanException;
import gasa.controllers.exceptions.NonexistentEntityException;
import gasa.controllers.exceptions.RollbackFailureException;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import gasaEntities.BacSeries;
import gasaEntities.MatieresPrincipales;
import gasaEntities.NotesBac;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.transaction.UserTransaction;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author folaw
 */
public class MatieresPrincipalesJpaController implements Serializable {

    public MatieresPrincipalesJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(MatieresPrincipales matieresPrincipales) throws RollbackFailureException, Exception {
        if (matieresPrincipales.getNotesBacList() == null) {
            matieresPrincipales.setNotesBacList(new ArrayList<NotesBac>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            BacSeries bacSerieId = matieresPrincipales.getBacSerieId();
            if (bacSerieId != null) {
                bacSerieId = em.getReference(bacSerieId.getClass(), bacSerieId.getId());
                matieresPrincipales.setBacSerieId(bacSerieId);
            }
            List<NotesBac> attachedNotesBacList = new ArrayList<NotesBac>();
            for (NotesBac notesBacListNotesBacToAttach : matieresPrincipales.getNotesBacList()) {
                notesBacListNotesBacToAttach = em.getReference(notesBacListNotesBacToAttach.getClass(), notesBacListNotesBacToAttach.getId());
                attachedNotesBacList.add(notesBacListNotesBacToAttach);
            }
            matieresPrincipales.setNotesBacList(attachedNotesBacList);
            em.persist(matieresPrincipales);
            if (bacSerieId != null) {
                bacSerieId.getMatieresPrincipalesList().add(matieresPrincipales);
                bacSerieId = em.merge(bacSerieId);
            }
            for (NotesBac notesBacListNotesBac : matieresPrincipales.getNotesBacList()) {
                MatieresPrincipales oldMatierePrincipaleIdOfNotesBacListNotesBac = notesBacListNotesBac.getMatierePrincipaleId();
                notesBacListNotesBac.setMatierePrincipaleId(matieresPrincipales);
                notesBacListNotesBac = em.merge(notesBacListNotesBac);
                if (oldMatierePrincipaleIdOfNotesBacListNotesBac != null) {
                    oldMatierePrincipaleIdOfNotesBacListNotesBac.getNotesBacList().remove(notesBacListNotesBac);
                    oldMatierePrincipaleIdOfNotesBacListNotesBac = em.merge(oldMatierePrincipaleIdOfNotesBacListNotesBac);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(MatieresPrincipales matieresPrincipales) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            MatieresPrincipales persistentMatieresPrincipales = em.find(MatieresPrincipales.class, matieresPrincipales.getId());
            BacSeries bacSerieIdOld = persistentMatieresPrincipales.getBacSerieId();
            BacSeries bacSerieIdNew = matieresPrincipales.getBacSerieId();
            List<NotesBac> notesBacListOld = persistentMatieresPrincipales.getNotesBacList();
            List<NotesBac> notesBacListNew = matieresPrincipales.getNotesBacList();
            List<String> illegalOrphanMessages = null;
            for (NotesBac notesBacListOldNotesBac : notesBacListOld) {
                if (!notesBacListNew.contains(notesBacListOldNotesBac)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain NotesBac " + notesBacListOldNotesBac + " since its matierePrincipaleId field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (bacSerieIdNew != null) {
                bacSerieIdNew = em.getReference(bacSerieIdNew.getClass(), bacSerieIdNew.getId());
                matieresPrincipales.setBacSerieId(bacSerieIdNew);
            }
            List<NotesBac> attachedNotesBacListNew = new ArrayList<NotesBac>();
            for (NotesBac notesBacListNewNotesBacToAttach : notesBacListNew) {
                notesBacListNewNotesBacToAttach = em.getReference(notesBacListNewNotesBacToAttach.getClass(), notesBacListNewNotesBacToAttach.getId());
                attachedNotesBacListNew.add(notesBacListNewNotesBacToAttach);
            }
            notesBacListNew = attachedNotesBacListNew;
            matieresPrincipales.setNotesBacList(notesBacListNew);
            matieresPrincipales = em.merge(matieresPrincipales);
            if (bacSerieIdOld != null && !bacSerieIdOld.equals(bacSerieIdNew)) {
                bacSerieIdOld.getMatieresPrincipalesList().remove(matieresPrincipales);
                bacSerieIdOld = em.merge(bacSerieIdOld);
            }
            if (bacSerieIdNew != null && !bacSerieIdNew.equals(bacSerieIdOld)) {
                bacSerieIdNew.getMatieresPrincipalesList().add(matieresPrincipales);
                bacSerieIdNew = em.merge(bacSerieIdNew);
            }
            for (NotesBac notesBacListNewNotesBac : notesBacListNew) {
                if (!notesBacListOld.contains(notesBacListNewNotesBac)) {
                    MatieresPrincipales oldMatierePrincipaleIdOfNotesBacListNewNotesBac = notesBacListNewNotesBac.getMatierePrincipaleId();
                    notesBacListNewNotesBac.setMatierePrincipaleId(matieresPrincipales);
                    notesBacListNewNotesBac = em.merge(notesBacListNewNotesBac);
                    if (oldMatierePrincipaleIdOfNotesBacListNewNotesBac != null && !oldMatierePrincipaleIdOfNotesBacListNewNotesBac.equals(matieresPrincipales)) {
                        oldMatierePrincipaleIdOfNotesBacListNewNotesBac.getNotesBacList().remove(notesBacListNewNotesBac);
                        oldMatierePrincipaleIdOfNotesBacListNewNotesBac = em.merge(oldMatierePrincipaleIdOfNotesBacListNewNotesBac);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = matieresPrincipales.getId();
                if (findMatieresPrincipales(id) == null) {
                    throw new NonexistentEntityException("The matieresPrincipales with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            MatieresPrincipales matieresPrincipales;
            try {
                matieresPrincipales = em.getReference(MatieresPrincipales.class, id);
                matieresPrincipales.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The matieresPrincipales with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<NotesBac> notesBacListOrphanCheck = matieresPrincipales.getNotesBacList();
            for (NotesBac notesBacListOrphanCheckNotesBac : notesBacListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This MatieresPrincipales (" + matieresPrincipales + ") cannot be destroyed since the NotesBac " + notesBacListOrphanCheckNotesBac + " in its notesBacList field has a non-nullable matierePrincipaleId field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            BacSeries bacSerieId = matieresPrincipales.getBacSerieId();
            if (bacSerieId != null) {
                bacSerieId.getMatieresPrincipalesList().remove(matieresPrincipales);
                bacSerieId = em.merge(bacSerieId);
            }
            em.remove(matieresPrincipales);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<MatieresPrincipales> findMatieresPrincipalesEntities() {
        return findMatieresPrincipalesEntities(true, -1, -1);
    }

    public List<MatieresPrincipales> findMatieresPrincipalesEntities(int maxResults, int firstResult) {
        return findMatieresPrincipalesEntities(false, maxResults, firstResult);
    }

    private List<MatieresPrincipales> findMatieresPrincipalesEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(MatieresPrincipales.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public MatieresPrincipales findMatieresPrincipales(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(MatieresPrincipales.class, id);
        } finally {
            em.close();
        }
    }

    public int getMatieresPrincipalesCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<MatieresPrincipales> rt = cq.from(MatieresPrincipales.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

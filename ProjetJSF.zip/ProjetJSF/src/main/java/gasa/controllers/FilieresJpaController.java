/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasa.controllers;

import gasa.controllers.exceptions.IllegalOrphanException;
import gasa.controllers.exceptions.NonexistentEntityException;
import gasa.controllers.exceptions.RollbackFailureException;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import gasaEntities.CriteresAdmission;
import java.util.ArrayList;
import java.util.List;
import gasaEntities.CritereMatieres;
import gasaEntities.Inscriptions;
import gasaEntities.Criteres;
import gasaEntities.FiliereCompatSeries;
import gasaEntities.Filieres;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.transaction.UserTransaction;

/**
 *
 * @author folaw
 */
public class FilieresJpaController implements Serializable {

    public FilieresJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Filieres filieres) throws RollbackFailureException, Exception {
        if (filieres.getCriteresAdmissionList() == null) {
            filieres.setCriteresAdmissionList(new ArrayList<CriteresAdmission>());
        }
        if (filieres.getCritereMatieresList() == null) {
            filieres.setCritereMatieresList(new ArrayList<CritereMatieres>());
        }
        if (filieres.getInscriptionsList() == null) {
            filieres.setInscriptionsList(new ArrayList<Inscriptions>());
        }
        if (filieres.getCriteresList() == null) {
            filieres.setCriteresList(new ArrayList<Criteres>());
        }
        if (filieres.getFiliereCompatSeriesList() == null) {
            filieres.setFiliereCompatSeriesList(new ArrayList<FiliereCompatSeries>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            List<CriteresAdmission> attachedCriteresAdmissionList = new ArrayList<CriteresAdmission>();
            for (CriteresAdmission criteresAdmissionListCriteresAdmissionToAttach : filieres.getCriteresAdmissionList()) {
                criteresAdmissionListCriteresAdmissionToAttach = em.getReference(criteresAdmissionListCriteresAdmissionToAttach.getClass(), criteresAdmissionListCriteresAdmissionToAttach.getId());
                attachedCriteresAdmissionList.add(criteresAdmissionListCriteresAdmissionToAttach);
            }
            filieres.setCriteresAdmissionList(attachedCriteresAdmissionList);
            List<CritereMatieres> attachedCritereMatieresList = new ArrayList<CritereMatieres>();
            for (CritereMatieres critereMatieresListCritereMatieresToAttach : filieres.getCritereMatieresList()) {
                critereMatieresListCritereMatieresToAttach = em.getReference(critereMatieresListCritereMatieresToAttach.getClass(), critereMatieresListCritereMatieresToAttach.getId());
                attachedCritereMatieresList.add(critereMatieresListCritereMatieresToAttach);
            }
            filieres.setCritereMatieresList(attachedCritereMatieresList);
            List<Inscriptions> attachedInscriptionsList = new ArrayList<Inscriptions>();
            for (Inscriptions inscriptionsListInscriptionsToAttach : filieres.getInscriptionsList()) {
                inscriptionsListInscriptionsToAttach = em.getReference(inscriptionsListInscriptionsToAttach.getClass(), inscriptionsListInscriptionsToAttach.getId());
                attachedInscriptionsList.add(inscriptionsListInscriptionsToAttach);
            }
            filieres.setInscriptionsList(attachedInscriptionsList);
            List<Criteres> attachedCriteresList = new ArrayList<Criteres>();
            for (Criteres criteresListCriteresToAttach : filieres.getCriteresList()) {
                criteresListCriteresToAttach = em.getReference(criteresListCriteresToAttach.getClass(), criteresListCriteresToAttach.getId());
                attachedCriteresList.add(criteresListCriteresToAttach);
            }
            filieres.setCriteresList(attachedCriteresList);
            List<FiliereCompatSeries> attachedFiliereCompatSeriesList = new ArrayList<FiliereCompatSeries>();
            for (FiliereCompatSeries filiereCompatSeriesListFiliereCompatSeriesToAttach : filieres.getFiliereCompatSeriesList()) {
                filiereCompatSeriesListFiliereCompatSeriesToAttach = em.getReference(filiereCompatSeriesListFiliereCompatSeriesToAttach.getClass(), filiereCompatSeriesListFiliereCompatSeriesToAttach.getFiliereCompatSeriesPK());
                attachedFiliereCompatSeriesList.add(filiereCompatSeriesListFiliereCompatSeriesToAttach);
            }
            filieres.setFiliereCompatSeriesList(attachedFiliereCompatSeriesList);
            em.persist(filieres);
            for (CriteresAdmission criteresAdmissionListCriteresAdmission : filieres.getCriteresAdmissionList()) {
                Filieres oldFiliereOfCriteresAdmissionListCriteresAdmission = criteresAdmissionListCriteresAdmission.getFiliere();
                criteresAdmissionListCriteresAdmission.setFiliere(filieres);
                criteresAdmissionListCriteresAdmission = em.merge(criteresAdmissionListCriteresAdmission);
                if (oldFiliereOfCriteresAdmissionListCriteresAdmission != null) {
                    oldFiliereOfCriteresAdmissionListCriteresAdmission.getCriteresAdmissionList().remove(criteresAdmissionListCriteresAdmission);
                    oldFiliereOfCriteresAdmissionListCriteresAdmission = em.merge(oldFiliereOfCriteresAdmissionListCriteresAdmission);
                }
            }
            for (CritereMatieres critereMatieresListCritereMatieres : filieres.getCritereMatieresList()) {
                Filieres oldFiliereIdOfCritereMatieresListCritereMatieres = critereMatieresListCritereMatieres.getFiliereId();
                critereMatieresListCritereMatieres.setFiliereId(filieres);
                critereMatieresListCritereMatieres = em.merge(critereMatieresListCritereMatieres);
                if (oldFiliereIdOfCritereMatieresListCritereMatieres != null) {
                    oldFiliereIdOfCritereMatieresListCritereMatieres.getCritereMatieresList().remove(critereMatieresListCritereMatieres);
                    oldFiliereIdOfCritereMatieresListCritereMatieres = em.merge(oldFiliereIdOfCritereMatieresListCritereMatieres);
                }
            }
            for (Inscriptions inscriptionsListInscriptions : filieres.getInscriptionsList()) {
                Filieres oldFiliereIdOfInscriptionsListInscriptions = inscriptionsListInscriptions.getFiliereId();
                inscriptionsListInscriptions.setFiliereId(filieres);
                inscriptionsListInscriptions = em.merge(inscriptionsListInscriptions);
                if (oldFiliereIdOfInscriptionsListInscriptions != null) {
                    oldFiliereIdOfInscriptionsListInscriptions.getInscriptionsList().remove(inscriptionsListInscriptions);
                    oldFiliereIdOfInscriptionsListInscriptions = em.merge(oldFiliereIdOfInscriptionsListInscriptions);
                }
            }
            for (Criteres criteresListCriteres : filieres.getCriteresList()) {
                Filieres oldFiliereIdOfCriteresListCriteres = criteresListCriteres.getFiliereId();
                criteresListCriteres.setFiliereId(filieres);
                criteresListCriteres = em.merge(criteresListCriteres);
                if (oldFiliereIdOfCriteresListCriteres != null) {
                    oldFiliereIdOfCriteresListCriteres.getCriteresList().remove(criteresListCriteres);
                    oldFiliereIdOfCriteresListCriteres = em.merge(oldFiliereIdOfCriteresListCriteres);
                }
            }
            for (FiliereCompatSeries filiereCompatSeriesListFiliereCompatSeries : filieres.getFiliereCompatSeriesList()) {
                Filieres oldFilieresOfFiliereCompatSeriesListFiliereCompatSeries = filiereCompatSeriesListFiliereCompatSeries.getFilieres();
                filiereCompatSeriesListFiliereCompatSeries.setFilieres(filieres);
                filiereCompatSeriesListFiliereCompatSeries = em.merge(filiereCompatSeriesListFiliereCompatSeries);
                if (oldFilieresOfFiliereCompatSeriesListFiliereCompatSeries != null) {
                    oldFilieresOfFiliereCompatSeriesListFiliereCompatSeries.getFiliereCompatSeriesList().remove(filiereCompatSeriesListFiliereCompatSeries);
                    oldFilieresOfFiliereCompatSeriesListFiliereCompatSeries = em.merge(oldFilieresOfFiliereCompatSeriesListFiliereCompatSeries);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Filieres filieres) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Filieres persistentFilieres = em.find(Filieres.class, filieres.getId());
            List<CriteresAdmission> criteresAdmissionListOld = persistentFilieres.getCriteresAdmissionList();
            List<CriteresAdmission> criteresAdmissionListNew = filieres.getCriteresAdmissionList();
            List<CritereMatieres> critereMatieresListOld = persistentFilieres.getCritereMatieresList();
            List<CritereMatieres> critereMatieresListNew = filieres.getCritereMatieresList();
            List<Inscriptions> inscriptionsListOld = persistentFilieres.getInscriptionsList();
            List<Inscriptions> inscriptionsListNew = filieres.getInscriptionsList();
            List<Criteres> criteresListOld = persistentFilieres.getCriteresList();
            List<Criteres> criteresListNew = filieres.getCriteresList();
            List<FiliereCompatSeries> filiereCompatSeriesListOld = persistentFilieres.getFiliereCompatSeriesList();
            List<FiliereCompatSeries> filiereCompatSeriesListNew = filieres.getFiliereCompatSeriesList();
            List<String> illegalOrphanMessages = null;
            for (CriteresAdmission criteresAdmissionListOldCriteresAdmission : criteresAdmissionListOld) {
                if (!criteresAdmissionListNew.contains(criteresAdmissionListOldCriteresAdmission)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain CriteresAdmission " + criteresAdmissionListOldCriteresAdmission + " since its filiere field is not nullable.");
                }
            }
            for (FiliereCompatSeries filiereCompatSeriesListOldFiliereCompatSeries : filiereCompatSeriesListOld) {
                if (!filiereCompatSeriesListNew.contains(filiereCompatSeriesListOldFiliereCompatSeries)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain FiliereCompatSeries " + filiereCompatSeriesListOldFiliereCompatSeries + " since its filieres field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<CriteresAdmission> attachedCriteresAdmissionListNew = new ArrayList<CriteresAdmission>();
            for (CriteresAdmission criteresAdmissionListNewCriteresAdmissionToAttach : criteresAdmissionListNew) {
                criteresAdmissionListNewCriteresAdmissionToAttach = em.getReference(criteresAdmissionListNewCriteresAdmissionToAttach.getClass(), criteresAdmissionListNewCriteresAdmissionToAttach.getId());
                attachedCriteresAdmissionListNew.add(criteresAdmissionListNewCriteresAdmissionToAttach);
            }
            criteresAdmissionListNew = attachedCriteresAdmissionListNew;
            filieres.setCriteresAdmissionList(criteresAdmissionListNew);
            List<CritereMatieres> attachedCritereMatieresListNew = new ArrayList<CritereMatieres>();
            for (CritereMatieres critereMatieresListNewCritereMatieresToAttach : critereMatieresListNew) {
                critereMatieresListNewCritereMatieresToAttach = em.getReference(critereMatieresListNewCritereMatieresToAttach.getClass(), critereMatieresListNewCritereMatieresToAttach.getId());
                attachedCritereMatieresListNew.add(critereMatieresListNewCritereMatieresToAttach);
            }
            critereMatieresListNew = attachedCritereMatieresListNew;
            filieres.setCritereMatieresList(critereMatieresListNew);
            List<Inscriptions> attachedInscriptionsListNew = new ArrayList<Inscriptions>();
            for (Inscriptions inscriptionsListNewInscriptionsToAttach : inscriptionsListNew) {
                inscriptionsListNewInscriptionsToAttach = em.getReference(inscriptionsListNewInscriptionsToAttach.getClass(), inscriptionsListNewInscriptionsToAttach.getId());
                attachedInscriptionsListNew.add(inscriptionsListNewInscriptionsToAttach);
            }
            inscriptionsListNew = attachedInscriptionsListNew;
            filieres.setInscriptionsList(inscriptionsListNew);
            List<Criteres> attachedCriteresListNew = new ArrayList<Criteres>();
            for (Criteres criteresListNewCriteresToAttach : criteresListNew) {
                criteresListNewCriteresToAttach = em.getReference(criteresListNewCriteresToAttach.getClass(), criteresListNewCriteresToAttach.getId());
                attachedCriteresListNew.add(criteresListNewCriteresToAttach);
            }
            criteresListNew = attachedCriteresListNew;
            filieres.setCriteresList(criteresListNew);
            List<FiliereCompatSeries> attachedFiliereCompatSeriesListNew = new ArrayList<FiliereCompatSeries>();
            for (FiliereCompatSeries filiereCompatSeriesListNewFiliereCompatSeriesToAttach : filiereCompatSeriesListNew) {
                filiereCompatSeriesListNewFiliereCompatSeriesToAttach = em.getReference(filiereCompatSeriesListNewFiliereCompatSeriesToAttach.getClass(), filiereCompatSeriesListNewFiliereCompatSeriesToAttach.getFiliereCompatSeriesPK());
                attachedFiliereCompatSeriesListNew.add(filiereCompatSeriesListNewFiliereCompatSeriesToAttach);
            }
            filiereCompatSeriesListNew = attachedFiliereCompatSeriesListNew;
            filieres.setFiliereCompatSeriesList(filiereCompatSeriesListNew);
            filieres = em.merge(filieres);
            for (CriteresAdmission criteresAdmissionListNewCriteresAdmission : criteresAdmissionListNew) {
                if (!criteresAdmissionListOld.contains(criteresAdmissionListNewCriteresAdmission)) {
                    Filieres oldFiliereOfCriteresAdmissionListNewCriteresAdmission = criteresAdmissionListNewCriteresAdmission.getFiliere();
                    criteresAdmissionListNewCriteresAdmission.setFiliere(filieres);
                    criteresAdmissionListNewCriteresAdmission = em.merge(criteresAdmissionListNewCriteresAdmission);
                    if (oldFiliereOfCriteresAdmissionListNewCriteresAdmission != null && !oldFiliereOfCriteresAdmissionListNewCriteresAdmission.equals(filieres)) {
                        oldFiliereOfCriteresAdmissionListNewCriteresAdmission.getCriteresAdmissionList().remove(criteresAdmissionListNewCriteresAdmission);
                        oldFiliereOfCriteresAdmissionListNewCriteresAdmission = em.merge(oldFiliereOfCriteresAdmissionListNewCriteresAdmission);
                    }
                }
            }
            for (CritereMatieres critereMatieresListOldCritereMatieres : critereMatieresListOld) {
                if (!critereMatieresListNew.contains(critereMatieresListOldCritereMatieres)) {
                    critereMatieresListOldCritereMatieres.setFiliereId(null);
                    critereMatieresListOldCritereMatieres = em.merge(critereMatieresListOldCritereMatieres);
                }
            }
            for (CritereMatieres critereMatieresListNewCritereMatieres : critereMatieresListNew) {
                if (!critereMatieresListOld.contains(critereMatieresListNewCritereMatieres)) {
                    Filieres oldFiliereIdOfCritereMatieresListNewCritereMatieres = critereMatieresListNewCritereMatieres.getFiliereId();
                    critereMatieresListNewCritereMatieres.setFiliereId(filieres);
                    critereMatieresListNewCritereMatieres = em.merge(critereMatieresListNewCritereMatieres);
                    if (oldFiliereIdOfCritereMatieresListNewCritereMatieres != null && !oldFiliereIdOfCritereMatieresListNewCritereMatieres.equals(filieres)) {
                        oldFiliereIdOfCritereMatieresListNewCritereMatieres.getCritereMatieresList().remove(critereMatieresListNewCritereMatieres);
                        oldFiliereIdOfCritereMatieresListNewCritereMatieres = em.merge(oldFiliereIdOfCritereMatieresListNewCritereMatieres);
                    }
                }
            }
            for (Inscriptions inscriptionsListOldInscriptions : inscriptionsListOld) {
                if (!inscriptionsListNew.contains(inscriptionsListOldInscriptions)) {
                    inscriptionsListOldInscriptions.setFiliereId(null);
                    inscriptionsListOldInscriptions = em.merge(inscriptionsListOldInscriptions);
                }
            }
            for (Inscriptions inscriptionsListNewInscriptions : inscriptionsListNew) {
                if (!inscriptionsListOld.contains(inscriptionsListNewInscriptions)) {
                    Filieres oldFiliereIdOfInscriptionsListNewInscriptions = inscriptionsListNewInscriptions.getFiliereId();
                    inscriptionsListNewInscriptions.setFiliereId(filieres);
                    inscriptionsListNewInscriptions = em.merge(inscriptionsListNewInscriptions);
                    if (oldFiliereIdOfInscriptionsListNewInscriptions != null && !oldFiliereIdOfInscriptionsListNewInscriptions.equals(filieres)) {
                        oldFiliereIdOfInscriptionsListNewInscriptions.getInscriptionsList().remove(inscriptionsListNewInscriptions);
                        oldFiliereIdOfInscriptionsListNewInscriptions = em.merge(oldFiliereIdOfInscriptionsListNewInscriptions);
                    }
                }
            }
            for (Criteres criteresListOldCriteres : criteresListOld) {
                if (!criteresListNew.contains(criteresListOldCriteres)) {
                    criteresListOldCriteres.setFiliereId(null);
                    criteresListOldCriteres = em.merge(criteresListOldCriteres);
                }
            }
            for (Criteres criteresListNewCriteres : criteresListNew) {
                if (!criteresListOld.contains(criteresListNewCriteres)) {
                    Filieres oldFiliereIdOfCriteresListNewCriteres = criteresListNewCriteres.getFiliereId();
                    criteresListNewCriteres.setFiliereId(filieres);
                    criteresListNewCriteres = em.merge(criteresListNewCriteres);
                    if (oldFiliereIdOfCriteresListNewCriteres != null && !oldFiliereIdOfCriteresListNewCriteres.equals(filieres)) {
                        oldFiliereIdOfCriteresListNewCriteres.getCriteresList().remove(criteresListNewCriteres);
                        oldFiliereIdOfCriteresListNewCriteres = em.merge(oldFiliereIdOfCriteresListNewCriteres);
                    }
                }
            }
            for (FiliereCompatSeries filiereCompatSeriesListNewFiliereCompatSeries : filiereCompatSeriesListNew) {
                if (!filiereCompatSeriesListOld.contains(filiereCompatSeriesListNewFiliereCompatSeries)) {
                    Filieres oldFilieresOfFiliereCompatSeriesListNewFiliereCompatSeries = filiereCompatSeriesListNewFiliereCompatSeries.getFilieres();
                    filiereCompatSeriesListNewFiliereCompatSeries.setFilieres(filieres);
                    filiereCompatSeriesListNewFiliereCompatSeries = em.merge(filiereCompatSeriesListNewFiliereCompatSeries);
                    if (oldFilieresOfFiliereCompatSeriesListNewFiliereCompatSeries != null && !oldFilieresOfFiliereCompatSeriesListNewFiliereCompatSeries.equals(filieres)) {
                        oldFilieresOfFiliereCompatSeriesListNewFiliereCompatSeries.getFiliereCompatSeriesList().remove(filiereCompatSeriesListNewFiliereCompatSeries);
                        oldFilieresOfFiliereCompatSeriesListNewFiliereCompatSeries = em.merge(oldFilieresOfFiliereCompatSeriesListNewFiliereCompatSeries);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = filieres.getId();
                if (findFilieres(id) == null) {
                    throw new NonexistentEntityException("The filieres with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Filieres filieres;
            try {
                filieres = em.getReference(Filieres.class, id);
                filieres.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The filieres with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<CriteresAdmission> criteresAdmissionListOrphanCheck = filieres.getCriteresAdmissionList();
            for (CriteresAdmission criteresAdmissionListOrphanCheckCriteresAdmission : criteresAdmissionListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Filieres (" + filieres + ") cannot be destroyed since the CriteresAdmission " + criteresAdmissionListOrphanCheckCriteresAdmission + " in its criteresAdmissionList field has a non-nullable filiere field.");
            }
            List<FiliereCompatSeries> filiereCompatSeriesListOrphanCheck = filieres.getFiliereCompatSeriesList();
            for (FiliereCompatSeries filiereCompatSeriesListOrphanCheckFiliereCompatSeries : filiereCompatSeriesListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Filieres (" + filieres + ") cannot be destroyed since the FiliereCompatSeries " + filiereCompatSeriesListOrphanCheckFiliereCompatSeries + " in its filiereCompatSeriesList field has a non-nullable filieres field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<CritereMatieres> critereMatieresList = filieres.getCritereMatieresList();
            for (CritereMatieres critereMatieresListCritereMatieres : critereMatieresList) {
                critereMatieresListCritereMatieres.setFiliereId(null);
                critereMatieresListCritereMatieres = em.merge(critereMatieresListCritereMatieres);
            }
            List<Inscriptions> inscriptionsList = filieres.getInscriptionsList();
            for (Inscriptions inscriptionsListInscriptions : inscriptionsList) {
                inscriptionsListInscriptions.setFiliereId(null);
                inscriptionsListInscriptions = em.merge(inscriptionsListInscriptions);
            }
            List<Criteres> criteresList = filieres.getCriteresList();
            for (Criteres criteresListCriteres : criteresList) {
                criteresListCriteres.setFiliereId(null);
                criteresListCriteres = em.merge(criteresListCriteres);
            }
            em.remove(filieres);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Filieres> findFilieresEntities() {
        return findFilieresEntities(true, -1, -1);
    }

    public List<Filieres> findFilieresEntities(int maxResults, int firstResult) {
        return findFilieresEntities(false, maxResults, firstResult);
    }

    private List<Filieres> findFilieresEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Filieres.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Filieres findFilieres(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Filieres.class, id);
        } finally {
            em.close();
        }
    }

    public int getFilieresCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Filieres> rt = cq.from(Filieres.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

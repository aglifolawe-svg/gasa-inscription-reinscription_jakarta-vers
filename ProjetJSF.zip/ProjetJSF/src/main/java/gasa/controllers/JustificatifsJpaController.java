/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasa.controllers;

import gasa.controllers.exceptions.NonexistentEntityException;
import gasa.controllers.exceptions.RollbackFailureException;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import gasaEntities.Inscriptions;
import gasaEntities.Justificatifs;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.transaction.UserTransaction;
import java.util.List;

/**
 *
 * @author folaw
 */
public class JustificatifsJpaController implements Serializable {

    public JustificatifsJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Justificatifs justificatifs) throws RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Inscriptions inscriptionId = justificatifs.getInscriptionId();
            if (inscriptionId != null) {
                inscriptionId = em.getReference(inscriptionId.getClass(), inscriptionId.getId());
                justificatifs.setInscriptionId(inscriptionId);
            }
            em.persist(justificatifs);
            if (inscriptionId != null) {
                inscriptionId.getJustificatifsList().add(justificatifs);
                inscriptionId = em.merge(inscriptionId);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Justificatifs justificatifs) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Justificatifs persistentJustificatifs = em.find(Justificatifs.class, justificatifs.getId());
            Inscriptions inscriptionIdOld = persistentJustificatifs.getInscriptionId();
            Inscriptions inscriptionIdNew = justificatifs.getInscriptionId();
            if (inscriptionIdNew != null) {
                inscriptionIdNew = em.getReference(inscriptionIdNew.getClass(), inscriptionIdNew.getId());
                justificatifs.setInscriptionId(inscriptionIdNew);
            }
            justificatifs = em.merge(justificatifs);
            if (inscriptionIdOld != null && !inscriptionIdOld.equals(inscriptionIdNew)) {
                inscriptionIdOld.getJustificatifsList().remove(justificatifs);
                inscriptionIdOld = em.merge(inscriptionIdOld);
            }
            if (inscriptionIdNew != null && !inscriptionIdNew.equals(inscriptionIdOld)) {
                inscriptionIdNew.getJustificatifsList().add(justificatifs);
                inscriptionIdNew = em.merge(inscriptionIdNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = justificatifs.getId();
                if (findJustificatifs(id) == null) {
                    throw new NonexistentEntityException("The justificatifs with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Justificatifs justificatifs;
            try {
                justificatifs = em.getReference(Justificatifs.class, id);
                justificatifs.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The justificatifs with id " + id + " no longer exists.", enfe);
            }
            Inscriptions inscriptionId = justificatifs.getInscriptionId();
            if (inscriptionId != null) {
                inscriptionId.getJustificatifsList().remove(justificatifs);
                inscriptionId = em.merge(inscriptionId);
            }
            em.remove(justificatifs);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Justificatifs> findJustificatifsEntities() {
        return findJustificatifsEntities(true, -1, -1);
    }

    public List<Justificatifs> findJustificatifsEntities(int maxResults, int firstResult) {
        return findJustificatifsEntities(false, maxResults, firstResult);
    }

    private List<Justificatifs> findJustificatifsEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Justificatifs.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Justificatifs findJustificatifs(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Justificatifs.class, id);
        } finally {
            em.close();
        }
    }

    public int getJustificatifsCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Justificatifs> rt = cq.from(Justificatifs.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

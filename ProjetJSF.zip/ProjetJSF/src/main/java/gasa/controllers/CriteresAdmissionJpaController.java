/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasa.controllers;

import gasa.controllers.exceptions.IllegalOrphanException;
import gasa.controllers.exceptions.NonexistentEntityException;
import gasa.controllers.exceptions.RollbackFailureException;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import gasaEntities.Filieres;
import gasaEntities.CritereMatieres;
import gasaEntities.CriteresAdmission;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.transaction.UserTransaction;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author folaw
 */
public class CriteresAdmissionJpaController implements Serializable {

    public CriteresAdmissionJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(CriteresAdmission criteresAdmission) throws RollbackFailureException, Exception {
        if (criteresAdmission.getCritereMatieresList() == null) {
            criteresAdmission.setCritereMatieresList(new ArrayList<CritereMatieres>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Filieres filiere = criteresAdmission.getFiliere();
            if (filiere != null) {
                filiere = em.getReference(filiere.getClass(), filiere.getId());
                criteresAdmission.setFiliere(filiere);
            }
            List<CritereMatieres> attachedCritereMatieresList = new ArrayList<CritereMatieres>();
            for (CritereMatieres critereMatieresListCritereMatieresToAttach : criteresAdmission.getCritereMatieresList()) {
                critereMatieresListCritereMatieresToAttach = em.getReference(critereMatieresListCritereMatieresToAttach.getClass(), critereMatieresListCritereMatieresToAttach.getId());
                attachedCritereMatieresList.add(critereMatieresListCritereMatieresToAttach);
            }
            criteresAdmission.setCritereMatieresList(attachedCritereMatieresList);
            em.persist(criteresAdmission);
            if (filiere != null) {
                filiere.getCriteresAdmissionList().add(criteresAdmission);
                filiere = em.merge(filiere);
            }
            for (CritereMatieres critereMatieresListCritereMatieres : criteresAdmission.getCritereMatieresList()) {
                CriteresAdmission oldCritereId1OfCritereMatieresListCritereMatieres = critereMatieresListCritereMatieres.getCritereId1();
                critereMatieresListCritereMatieres.setCritereId1(criteresAdmission);
                critereMatieresListCritereMatieres = em.merge(critereMatieresListCritereMatieres);
                if (oldCritereId1OfCritereMatieresListCritereMatieres != null) {
                    oldCritereId1OfCritereMatieresListCritereMatieres.getCritereMatieresList().remove(critereMatieresListCritereMatieres);
                    oldCritereId1OfCritereMatieresListCritereMatieres = em.merge(oldCritereId1OfCritereMatieresListCritereMatieres);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(CriteresAdmission criteresAdmission) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            CriteresAdmission persistentCriteresAdmission = em.find(CriteresAdmission.class, criteresAdmission.getId());
            Filieres filiereOld = persistentCriteresAdmission.getFiliere();
            Filieres filiereNew = criteresAdmission.getFiliere();
            List<CritereMatieres> critereMatieresListOld = persistentCriteresAdmission.getCritereMatieresList();
            List<CritereMatieres> critereMatieresListNew = criteresAdmission.getCritereMatieresList();
            List<String> illegalOrphanMessages = null;
            for (CritereMatieres critereMatieresListOldCritereMatieres : critereMatieresListOld) {
                if (!critereMatieresListNew.contains(critereMatieresListOldCritereMatieres)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain CritereMatieres " + critereMatieresListOldCritereMatieres + " since its critereId1 field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (filiereNew != null) {
                filiereNew = em.getReference(filiereNew.getClass(), filiereNew.getId());
                criteresAdmission.setFiliere(filiereNew);
            }
            List<CritereMatieres> attachedCritereMatieresListNew = new ArrayList<CritereMatieres>();
            for (CritereMatieres critereMatieresListNewCritereMatieresToAttach : critereMatieresListNew) {
                critereMatieresListNewCritereMatieresToAttach = em.getReference(critereMatieresListNewCritereMatieresToAttach.getClass(), critereMatieresListNewCritereMatieresToAttach.getId());
                attachedCritereMatieresListNew.add(critereMatieresListNewCritereMatieresToAttach);
            }
            critereMatieresListNew = attachedCritereMatieresListNew;
            criteresAdmission.setCritereMatieresList(critereMatieresListNew);
            criteresAdmission = em.merge(criteresAdmission);
            if (filiereOld != null && !filiereOld.equals(filiereNew)) {
                filiereOld.getCriteresAdmissionList().remove(criteresAdmission);
                filiereOld = em.merge(filiereOld);
            }
            if (filiereNew != null && !filiereNew.equals(filiereOld)) {
                filiereNew.getCriteresAdmissionList().add(criteresAdmission);
                filiereNew = em.merge(filiereNew);
            }
            for (CritereMatieres critereMatieresListNewCritereMatieres : critereMatieresListNew) {
                if (!critereMatieresListOld.contains(critereMatieresListNewCritereMatieres)) {
                    CriteresAdmission oldCritereId1OfCritereMatieresListNewCritereMatieres = critereMatieresListNewCritereMatieres.getCritereId1();
                    critereMatieresListNewCritereMatieres.setCritereId1(criteresAdmission);
                    critereMatieresListNewCritereMatieres = em.merge(critereMatieresListNewCritereMatieres);
                    if (oldCritereId1OfCritereMatieresListNewCritereMatieres != null && !oldCritereId1OfCritereMatieresListNewCritereMatieres.equals(criteresAdmission)) {
                        oldCritereId1OfCritereMatieresListNewCritereMatieres.getCritereMatieresList().remove(critereMatieresListNewCritereMatieres);
                        oldCritereId1OfCritereMatieresListNewCritereMatieres = em.merge(oldCritereId1OfCritereMatieresListNewCritereMatieres);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = criteresAdmission.getId();
                if (findCriteresAdmission(id) == null) {
                    throw new NonexistentEntityException("The criteresAdmission with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            CriteresAdmission criteresAdmission;
            try {
                criteresAdmission = em.getReference(CriteresAdmission.class, id);
                criteresAdmission.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The criteresAdmission with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<CritereMatieres> critereMatieresListOrphanCheck = criteresAdmission.getCritereMatieresList();
            for (CritereMatieres critereMatieresListOrphanCheckCritereMatieres : critereMatieresListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This CriteresAdmission (" + criteresAdmission + ") cannot be destroyed since the CritereMatieres " + critereMatieresListOrphanCheckCritereMatieres + " in its critereMatieresList field has a non-nullable critereId1 field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Filieres filiere = criteresAdmission.getFiliere();
            if (filiere != null) {
                filiere.getCriteresAdmissionList().remove(criteresAdmission);
                filiere = em.merge(filiere);
            }
            em.remove(criteresAdmission);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<CriteresAdmission> findCriteresAdmissionEntities() {
        return findCriteresAdmissionEntities(true, -1, -1);
    }

    public List<CriteresAdmission> findCriteresAdmissionEntities(int maxResults, int firstResult) {
        return findCriteresAdmissionEntities(false, maxResults, firstResult);
    }

    private List<CriteresAdmission> findCriteresAdmissionEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(CriteresAdmission.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public CriteresAdmission findCriteresAdmission(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(CriteresAdmission.class, id);
        } finally {
            em.close();
        }
    }

    public int getCriteresAdmissionCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<CriteresAdmission> rt = cq.from(CriteresAdmission.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

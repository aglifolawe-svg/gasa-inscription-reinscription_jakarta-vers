/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasa.controllers;

import gasa.controllers.exceptions.NonexistentEntityException;
import gasa.controllers.exceptions.PreexistingEntityException;
import gasa.controllers.exceptions.RollbackFailureException;
import gasaEntities.FiliereCompatSeries;
import gasaEntities.FiliereCompatSeriesPK;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import gasaEntities.Filieres;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.transaction.UserTransaction;
import java.util.List;

/**
 *
 * @author folaw
 */
public class FiliereCompatSeriesJpaController implements Serializable {

    public FiliereCompatSeriesJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(FiliereCompatSeries filiereCompatSeries) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (filiereCompatSeries.getFiliereCompatSeriesPK() == null) {
            filiereCompatSeries.setFiliereCompatSeriesPK(new FiliereCompatSeriesPK());
        }
        filiereCompatSeries.getFiliereCompatSeriesPK().setFiliereId(filiereCompatSeries.getFilieres().getId());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Filieres filieres = filiereCompatSeries.getFilieres();
            if (filieres != null) {
                filieres = em.getReference(filieres.getClass(), filieres.getId());
                filiereCompatSeries.setFilieres(filieres);
            }
            em.persist(filiereCompatSeries);
            if (filieres != null) {
                filieres.getFiliereCompatSeriesList().add(filiereCompatSeries);
                filieres = em.merge(filieres);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findFiliereCompatSeries(filiereCompatSeries.getFiliereCompatSeriesPK()) != null) {
                throw new PreexistingEntityException("FiliereCompatSeries " + filiereCompatSeries + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(FiliereCompatSeries filiereCompatSeries) throws NonexistentEntityException, RollbackFailureException, Exception {
        filiereCompatSeries.getFiliereCompatSeriesPK().setFiliereId(filiereCompatSeries.getFilieres().getId());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            FiliereCompatSeries persistentFiliereCompatSeries = em.find(FiliereCompatSeries.class, filiereCompatSeries.getFiliereCompatSeriesPK());
            Filieres filieresOld = persistentFiliereCompatSeries.getFilieres();
            Filieres filieresNew = filiereCompatSeries.getFilieres();
            if (filieresNew != null) {
                filieresNew = em.getReference(filieresNew.getClass(), filieresNew.getId());
                filiereCompatSeries.setFilieres(filieresNew);
            }
            filiereCompatSeries = em.merge(filiereCompatSeries);
            if (filieresOld != null && !filieresOld.equals(filieresNew)) {
                filieresOld.getFiliereCompatSeriesList().remove(filiereCompatSeries);
                filieresOld = em.merge(filieresOld);
            }
            if (filieresNew != null && !filieresNew.equals(filieresOld)) {
                filieresNew.getFiliereCompatSeriesList().add(filiereCompatSeries);
                filieresNew = em.merge(filieresNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                FiliereCompatSeriesPK id = filiereCompatSeries.getFiliereCompatSeriesPK();
                if (findFiliereCompatSeries(id) == null) {
                    throw new NonexistentEntityException("The filiereCompatSeries with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(FiliereCompatSeriesPK id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            FiliereCompatSeries filiereCompatSeries;
            try {
                filiereCompatSeries = em.getReference(FiliereCompatSeries.class, id);
                filiereCompatSeries.getFiliereCompatSeriesPK();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The filiereCompatSeries with id " + id + " no longer exists.", enfe);
            }
            Filieres filieres = filiereCompatSeries.getFilieres();
            if (filieres != null) {
                filieres.getFiliereCompatSeriesList().remove(filiereCompatSeries);
                filieres = em.merge(filieres);
            }
            em.remove(filiereCompatSeries);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<FiliereCompatSeries> findFiliereCompatSeriesEntities() {
        return findFiliereCompatSeriesEntities(true, -1, -1);
    }

    public List<FiliereCompatSeries> findFiliereCompatSeriesEntities(int maxResults, int firstResult) {
        return findFiliereCompatSeriesEntities(false, maxResults, firstResult);
    }

    private List<FiliereCompatSeries> findFiliereCompatSeriesEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(FiliereCompatSeries.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public FiliereCompatSeries findFiliereCompatSeries(FiliereCompatSeriesPK id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(FiliereCompatSeries.class, id);
        } finally {
            em.close();
        }
    }

    public int getFiliereCompatSeriesCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<FiliereCompatSeries> rt = cq.from(FiliereCompatSeries.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gasa.controllers;

import gasa.controllers.exceptions.NonexistentEntityException;
import gasa.controllers.exceptions.RollbackFailureException;
import gasaEntities.CritereMatieres;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import gasaEntities.Criteres;
import gasaEntities.CriteresAdmission;
import gasaEntities.Filieres;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.transaction.UserTransaction;
import java.util.List;

/**
 *
 * @author folaw
 */
public class CritereMatieresJpaController implements Serializable {

    public CritereMatieresJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(CritereMatieres critereMatieres) throws RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Criteres critereId = critereMatieres.getCritereId();
            if (critereId != null) {
                critereId = em.getReference(critereId.getClass(), critereId.getId());
                critereMatieres.setCritereId(critereId);
            }
            CriteresAdmission critereId1 = critereMatieres.getCritereId1();
            if (critereId1 != null) {
                critereId1 = em.getReference(critereId1.getClass(), critereId1.getId());
                critereMatieres.setCritereId1(critereId1);
            }
            Filieres filiereId = critereMatieres.getFiliereId();
            if (filiereId != null) {
                filiereId = em.getReference(filiereId.getClass(), filiereId.getId());
                critereMatieres.setFiliereId(filiereId);
            }
            em.persist(critereMatieres);
            if (critereId != null) {
                critereId.getCritereMatieresList().add(critereMatieres);
                critereId = em.merge(critereId);
            }
            if (critereId1 != null) {
                critereId1.getCritereMatieresList().add(critereMatieres);
                critereId1 = em.merge(critereId1);
            }
            if (filiereId != null) {
                filiereId.getCritereMatieresList().add(critereMatieres);
                filiereId = em.merge(filiereId);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(CritereMatieres critereMatieres) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            CritereMatieres persistentCritereMatieres = em.find(CritereMatieres.class, critereMatieres.getId());
            Criteres critereIdOld = persistentCritereMatieres.getCritereId();
            Criteres critereIdNew = critereMatieres.getCritereId();
            CriteresAdmission critereId1Old = persistentCritereMatieres.getCritereId1();
            CriteresAdmission critereId1New = critereMatieres.getCritereId1();
            Filieres filiereIdOld = persistentCritereMatieres.getFiliereId();
            Filieres filiereIdNew = critereMatieres.getFiliereId();
            if (critereIdNew != null) {
                critereIdNew = em.getReference(critereIdNew.getClass(), critereIdNew.getId());
                critereMatieres.setCritereId(critereIdNew);
            }
            if (critereId1New != null) {
                critereId1New = em.getReference(critereId1New.getClass(), critereId1New.getId());
                critereMatieres.setCritereId1(critereId1New);
            }
            if (filiereIdNew != null) {
                filiereIdNew = em.getReference(filiereIdNew.getClass(), filiereIdNew.getId());
                critereMatieres.setFiliereId(filiereIdNew);
            }
            critereMatieres = em.merge(critereMatieres);
            if (critereIdOld != null && !critereIdOld.equals(critereIdNew)) {
                critereIdOld.getCritereMatieresList().remove(critereMatieres);
                critereIdOld = em.merge(critereIdOld);
            }
            if (critereIdNew != null && !critereIdNew.equals(critereIdOld)) {
                critereIdNew.getCritereMatieresList().add(critereMatieres);
                critereIdNew = em.merge(critereIdNew);
            }
            if (critereId1Old != null && !critereId1Old.equals(critereId1New)) {
                critereId1Old.getCritereMatieresList().remove(critereMatieres);
                critereId1Old = em.merge(critereId1Old);
            }
            if (critereId1New != null && !critereId1New.equals(critereId1Old)) {
                critereId1New.getCritereMatieresList().add(critereMatieres);
                critereId1New = em.merge(critereId1New);
            }
            if (filiereIdOld != null && !filiereIdOld.equals(filiereIdNew)) {
                filiereIdOld.getCritereMatieresList().remove(critereMatieres);
                filiereIdOld = em.merge(filiereIdOld);
            }
            if (filiereIdNew != null && !filiereIdNew.equals(filiereIdOld)) {
                filiereIdNew.getCritereMatieresList().add(critereMatieres);
                filiereIdNew = em.merge(filiereIdNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = critereMatieres.getId();
                if (findCritereMatieres(id) == null) {
                    throw new NonexistentEntityException("The critereMatieres with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            CritereMatieres critereMatieres;
            try {
                critereMatieres = em.getReference(CritereMatieres.class, id);
                critereMatieres.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The critereMatieres with id " + id + " no longer exists.", enfe);
            }
            Criteres critereId = critereMatieres.getCritereId();
            if (critereId != null) {
                critereId.getCritereMatieresList().remove(critereMatieres);
                critereId = em.merge(critereId);
            }
            CriteresAdmission critereId1 = critereMatieres.getCritereId1();
            if (critereId1 != null) {
                critereId1.getCritereMatieresList().remove(critereMatieres);
                critereId1 = em.merge(critereId1);
            }
            Filieres filiereId = critereMatieres.getFiliereId();
            if (filiereId != null) {
                filiereId.getCritereMatieresList().remove(critereMatieres);
                filiereId = em.merge(filiereId);
            }
            em.remove(critereMatieres);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<CritereMatieres> findCritereMatieresEntities() {
        return findCritereMatieresEntities(true, -1, -1);
    }

    public List<CritereMatieres> findCritereMatieresEntities(int maxResults, int firstResult) {
        return findCritereMatieresEntities(false, maxResults, firstResult);
    }

    private List<CritereMatieres> findCritereMatieresEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(CritereMatieres.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public CritereMatieres findCritereMatieres(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(CritereMatieres.class, id);
        } finally {
            em.close();
        }
    }

    public int getCritereMatieresCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<CritereMatieres> rt = cq.from(CritereMatieres.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
